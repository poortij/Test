SALES_FIELD = {'CUST':'CUST',
               'SIS_NO':'SIS_NO',
               'CREDIT_CONDITION':'CREDIT_CONDITION',
               'INVOICE_NO':'INVOICE_NO',
               'PART_NO':'PART_NO',
               'INVOICE_STATUS_CD':'INVOICE_STATUS_CD',
               'METHOD_OF_SHIP':'METHOD_OF_SHIP',
               'EXTENDED_SELLING_PRICE':'EXTENDED_SELLING_PRICE',
               'PRICE':'PRICE',
               'SIS_QTY':'SIS_QTY',
               'Customer Code':'CUST',
               'Order Number':'SIS_NO',
               'Credit Condition':'CREDIT_CONDITION',
               'Invoice Number':'INVOICE_NO',
               'Part Number':'PART_NO',
               'Invoice Status':'INVOICE_STATUS_CD',
               'Shipment Method':'METHOD_OF_SHIP',
               'Selling Price':'EXTENDED_SELLING_PRICE',
               'Unit Price':'PRICE',
               'Order Quantity':'SIS_QTY'
               }

PARTS_FIELD = {'1':'1',
                'Part Number':'PART_NO',
               'PART_NO':'PART_NO',
               'COMMOD':'COMMOD',
               'Commodity Code':'COMMOD',
               'Commodity Category':'COMMOD_CAT',
               'COMMOD_CAT':'COMMOD_CAT',
               'Direct Ship Indicator':'DIRECT_SHIP_IND',
               'DIRECT_SHIP_IND':'DIRECT_SHIP_IND',
               'NOUN':'NOUN',
               'Part Name':'NOUN',
               'PART_CLASS':'PART_CLASS',
               'Part Class':'PART_CLASS',
               'UOM':'UOM',
               'Unit of Measure':'UOM',
               'CERTIFY_DT':'CERTIFY_DT',
               'Certification Date':'CERTIFY_DT',
               'AVG_UNIT_COST':'AVG_UNIT_COST',
               'Average Unit Cost':'AVG_UNIT_COST'
               }

DB_CONFIG = "db.conf"
DB_SERVER = "ovpd0138.vmpc1.cloud.boeing.com"
DB_PORT = "53625"
DB_NAME = "MSAD"
DB_USER = "MAS_SSPortal"
USER_NAME = "Kartik Dharia"
TEST_USER_NAME = "Kartik Dharia"
TEST_BEMSID = '1236'
TEST_USER_FIRST_NAME = 'Kartik'
TEST_USER_LAST_NAME = 'Dharia'
WITH_WSSO = False

query = """SELECT TOP 100 PART_NO,COMMOD,COMMOD_CAT,DIRECT_SHIP_IND,NOUN,PART_CLASS,UOM,CERTIFY_DT,AVG_UNIT_COST FROM ELABS_BGS_SSREPORT.PARTS"""
query1="""SELECT TOP 10 PART_NO,COMMOD,COMMOD_CAT,DIRECT_SHIP_IND FROM MMBI_VIEWS_ADCUR.PN_HEADER"""
query2="""SELECT TOP 30 SIS_NO,CUST,PART_NO,CREDIT_CONDITION,INVOICE_NO,INVOICE_STATUS_CD,METHOD_OF_SHIP 
            FROM MMBI_VIEWS_ADCUR.PN_SIS WHERE CUST LIKE'CA%' AND CUST IN('CAL','CVA','COI','CXA')"""
            
DB_FIELD_TO_DISPLAY_SALES="""SELECT ColumnName FROM DBC.Columns WHERE DatabaseName='MMBI_VIEWS_ADCUR' AND TableName='PN_SIS'; """
DB_FIELD_TO_DISPLAY_PARTS="""SELECT ColumnName FROM DBC.Columns WHERE DatabaseName='MMBI_VIEWS_ADCUR' AND TableName='PN_HEADER'; """


FIELDS_TO_DISPLAY_PARTS = "select Col_name, col_display_name from SSP_COL_MAP_SALES_NEW where Table_name = 'PN_HEADER' and expose_in_poc = 'Y' "

GROUP_BY_PARTS = "select Col_name, col_display_name from SSP_COL_MAP_SALES_NEW where Table_name = 'PN_HEADER' and GRP_BY = 'Y' "

SELECTION_CRITERIA_PARTS = "select Col_name, col_display_name from SSP_COL_MAP_SALES_NEW where Table_name = 'PN_HEADER' and Filterable = 'Y' "

FIELDS_TO_DISPLAY_SALES = "select Col_name, col_display_name from SSP_COL_MAP_SALES_NEW where Table_name = 'PN_SIS' and expose_in_poc = 'Y' "

GROUP_BY_SALES = "select Col_name, col_display_name from SSP_COL_MAP_SALES_NEW where Table_name = 'PN_SIS' and GRP_BY = 'Y' "

SELECTION_CRITERIA_SALES = "select Col_name, col_display_name from SSP_COL_MAP_SALES_NEW where Table_name = 'PN_SIS' and Filterable = 'Y' "

'''
create table SSP_CUSTOMER_LIST(
ID NUMBER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
USER_NAME VARCHAR2(200),
FILE_NAME VARCHAR2(200),
CUST_CODE VARCHAR2(200)
);
'''