jQuery(document).ready(function($) {
	
	/*$.ajax({
		url: '/fieldToDisplaySales',
		type: "GET",
		cache: false,
		async : false,
		success: function(result){
			var i = 0;
			$.each(result, function(obj) {
			     $('#search')
			         .append($("<option></option>")
			                    .attr("value",result[i])
			                    .text(result[i]));
			     i=i+1;
			});
		}//success close
	});//ajax close
	*/
});