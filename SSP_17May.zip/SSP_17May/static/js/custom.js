var result="";
var no = 1;
var noOfCond = [];

function loadval2fld(t) {
	var operatorValue = t.value;

	$("#value1").prop("disabled", false);
	if(operatorValue == "Between") {
		document.getElementById("value2Fld").style.display="block";
		document.getElementById("value2hdr").style.display="block";
		document.getElementById("spacehdr").style.display="none";
		document.getElementById("blankfld").style.display="none";		
	} else {
		document.getElementById("value2Fld").style.display="none";
		document.getElementById("value2hdr").style.display="none";
		document.getElementById("spacehdr").style.display="block";
		document.getElementById("blankfld").style.display="block";
	}
}

function loadOperatorFld() {
	$("#operator").prop("disabled", false);
}

function managecard(id){
	var expand = '';
	var collapse = '';
	
	if(id=='a1'){
		expand = document.getElementById(id).childNodes[3];
		collapse = document.getElementById(id).childNodes[5];
	} else {
		expand = document.getElementById(id).childNodes[1];
		collapse = document.getElementById(id).childNodes[3];	
	}
	if (expand.hidden==true) {
		expand.hidden=false;
		collapse.hidden = true;
	} else {
		expand.hidden=true;
		collapse.hidden = false;
	}  

}  

function formValidation() {
	var table=document.getElementById("tbl");
	var table_len=(table.rows.length)-1;
	var searchField = document.getElementById('search_to').options;
	
	if (table_len == 1 && $('#a2').attr('aria-expanded') == "true") { 	
		if ($('#field').val() != "select column" && $('#operator').val() != "select operator") {
			if (noOfCond.length == 0) {
				noOfCond.push(0)
			}
			$('#noOfConditions').val(noOfCond);
		}  else {
			$('#noOfConditions').val(noOfCond);
		}
 	} else if ($('#a2').attr('aria-expanded') == "true") {
 		$('#noOfConditions').val(noOfCond);
 	} else {
 		noOfCond.pop();
 		$('#noOfConditions').val(noOfCond);
 	}
	
	if ($('#a4').attr('aria-expanded') == "false") {
		document.getElementById('f2').value = 'Select File Type';
		document.getElementById('fileList').value = 'select file name';
	}
	
	if ($('#a5').attr('aria-expanded') == "false") {
		document.getElementById('groupby').value = 'select column';
		document.getElementById('aggr_func').value = 'select aggregate function';
	}
	return true;
}

function delete_row(no) {
	document.getElementById("row"+no+"").outerHTML="";
	
	if ($('#tbl tbody tr:first')[0] != $('#tbl tbody tr:last')[0]) {
		var td = $('#tbl tbody tr:first td:first-child')[0];
		var newtd = document.createElement("td"); 
		td.parentNode.replaceChild(newtd, td);
	} else {
		$('#tbl thead tr:first')[0].firstElementChild.remove();
		$('#tbl tbody tr:first td:first-child').remove();
	}
	
	$("#searchCriteria").val('no');
	var index = noOfCond.indexOf(no);
	if (index > -1) {
		noOfCond.splice(index, 1);
	}
}

function add_row(rowId) {
	var f1=$("#field option:selected" ).text();
	var fieldVal = document.getElementById("field").value;
	var op1=document.getElementById("operator").value;
	var v1=document.getElementById("value1").value;
	var v2=document.getElementById("value2").value;
	var and = (document.getElementById("AND") ? document.getElementById("AND").checked : false);
	var or = (document.getElementById("OR") ? document.getElementById("OR").checked : false);
	var table=document.getElementById("tbl");
	var table_len=(table.rows.length)-1;
	
	if (noOfCond.length == 0) {
		noOfCond.push(0)
	}
	
	var newRow = "<tr id='row" + table_len + "'>";
	
	if (table_len == 1) {
		newRow += "<td></td>";
	} else {
		if (and) {
			newRow += "<td><input type='text' value = 'AND' id='and" + table_len +"' name = 'options" + (table_len-1) + "' readonly>" + "</td>"
		} else {
			newRow += "<td><input type='text' value = 'OR' id='or" + table_len +"' name = 'options" + (table_len-1) + "' readonly>" + "</td>"
		} 
	}
	newRow += "<td><input type='text' value = '" + fieldVal + "' id='f" + table_len +"' name = 'field" + table_len + "' readonly>" + "</td>"
	+ "<td> <input type='text' value = '" + op1 + "' id='o" + table_len +"' name = 'operator" + table_len + "' readonly>" + "</td>"
	+ "<td><input type='text' value = '" + v1 + "' id='v" + table_len +"' name='value0_op" + table_len + "'>" + "</td>";
	
	if(op1 == "Between") {
		newRow +=  "<td><input type='text' value = '" + v2 + "' id='v" + (table_len) +"' name='value1_op" + table_len + "'>" + "</td>";
	} else {
		newRow += "<td></td>"
	}
	
	newRow += "<td><button type='button' class='btn btn-primary' onclick='delete_row("+table_len+")'> Delete</button></td></tr>";
	
	table.insertRow(table_len).outerHTML=newRow;
	document.getElementById("andorfld").style.display="block";
	document.getElementById("andorhdr").style.display="block";
	
	noOfCond.push(table_len);
}

function file_delete_row(num) {
	document.getElementById("file_row"+num+"").outerHTML="";
}

var num=1;
function file_add_row() {
	 var f2=document.getElementById("f2").value;
	 var c1=document.getElementById("c1").value;
	 
	 var table=document.getElementById("file_tbl");
	 var table_len=(table.rows.length)-1;
	 var row = table.insertRow(table_len).outerHTML="<tr id='file_row"+table_len+"'><td id='file_field"+table_len+"'><input type='text' name='file_field"+num+"'value='"+f2+"' id='file_field"+num+"'></td><td id='custList_row"+table_len+"'><input type='text' name='custList_row"+num+"'value='"+c1+"' id='custList_row"+num+"'></td><td><button type='button' class='btn btn-primary' onclick='file_delete_row("+table_len+")'> Delete </button></td></tr>";
 
	 num++;
}


jQuery(document).ready(function($) {
	//getCustList();
	//getPartList();
	
	$("#reset").click(function() {
		document.getElementById("salesForm").reset();
		document.getElementById("search_leftAll").click();
		var table = document.getElementById("result").DataTable;
		if(result){
			$("#result").DataTable().destroy();
			$("#result").empty();
			result = "";
		}
		
		var rowCount = document.getElementById('tbl').rows.length;
		
		rowCount= rowCount-1;
		
		for(i=1; i< rowCount ; i++) {
			document.getElementById("row"+i+"").outerHTML="";
		}
	});

	$("#reset1").click(function(){
		document.getElementById("partsForm").reset();
		document.getElementById("search_leftAll").click();
		var table = document.getElementById("result").DataTable;
		if(result){
			$("#result").DataTable().destroy();
			$("#result").empty();
			result = "";
		}
		
		var rowCount = document.getElementById('tbl').rows.length;
		
		rowCount= rowCount-1;
		
		for(i=1; i< rowCount ; i++) {
			document.getElementById("row"+i+"").outerHTML="";
		}
		alert("Reset Successful.")
	});
	
	$('#search').multiselect({
	    search: {
	        left: '<input type="text" name="q" class="form-control" placeholder="Search"/>',
	        right: '<input type="text" name="q" class="form-control" placeholder="Search" />'
	    },
	    sort : false,
	    fireSearch: function(value) {
	        return value.length > 0;
	    }
	});
	
	$("#downloadTemplate").click(function(){
		var xls_name = $("#file_name").val();
		window.location.href = "/downloadTemplate/"+xls_name;
	});
	
	$("#uploadExcel").click(function(){
		$(".custom-loader").show();
		var partsform = document.getElementById('partsForm');
		var salesform = document.getElementById('salesForm');
		var formData;

		if (partsform !== null) {
			formData = new FormData(partsform);
		} else {
			formData = new FormData(salesform);
		}
		
		$.ajax({
			url: '/UploadFile',
			type: "POST",
			cache: false,
			data: formData,
			contentType: false,
			processData: false,      
			success: function(result){
				if (result == "success"){
					 //toastr.success('File data uploaded successfully.');
					document.getElementById('fileDetailsField').style.display="none";
					document.getElementById('fileDetails').value = "";
					$("#successMessage").text('File data uploaded successfully');
					$('#success').removeClass('alert alert-danger');
					$('#success').addClass('alert alert-success');
					$('#success').removeClass('hide');
					setTimeout(function() {
						$('#success').addClass('hide');
					}, 15000);
				}
				if (result == "failed"){
					//alert("failed");
				
					//toastr.error('File upload failed');
					$("#successMessage").text("File upload failed");
					$('#success').removeClass('alert alert-success');
					$('#success').addClass('alert alert-danger');
					$('#success').removeClass('hide');
					setTimeout(function() {
						$('#success').addClass('hide');
					}, 15000);
				}
				if (result == "exists"){
					//toastr.warning('File name already exists. Please upload with new file name');
					$("#successMessage").text("File name already exists. Please upload with new file name");
					document.getElementById('fileDetailsField').style.display="none";
					document.getElementById('fileDetails').value = "";
					$('#success').removeClass('alert alert-success');
					$('#success').addClass('alert alert-danger');
					$('#success').removeClass('hide');
					
					setTimeout(function() {
						$('#success').addClass('hide');
					}, 15000);
				}
				$("#file").val("");
				document.getElementById('uploadExcel').disabled = true;
				$(".custom-loader").hide();
			},//success close
			error: function () {
				$(".custom-loader").hide();
				$("#failedMessage").text("Data upload failed");
				$('#failed').removeClass('hide');
				setTimeout(function() {
					$('#failed').addClass('hide');
				}, 10000);
			}
		});//ajax close
	});//click function close
	

	$("#f2").on('change',function(){
		var file_type = $('#f2').val();
		if (file_type == 'customer'){
			getCustList();
		} else if (file_type == 'parts'){
			getPartList();
		} else {
			$('#fileList').val('select file name');
		}
	});
	
	$('#file_name').on('change',function() {
		var team_name = $('#file_name').val();
		
		$('#file').val("");
		if (team_name == ''){
			document.getElementById('file').disabled = true;
			document.getElementById('uploadExcel').disabled = true;
			document.getElementById('downloadTemplate').disabled = true;
		}
		else{
			document.getElementById('file').disabled = false;
			document.getElementById('uploadExcel').disabled = true;
			document.getElementById('downloadTemplate').disabled = false;
		}
	});
	
	$('#file').on('change',function() {
		var fileName = $('#file').val();
		var ext = (fileName.match(/\.([^\.]+)$/)[1]).toLowerCase();
		
		if (ext != "xlsx" && ext!="xls"){
			alert("File type not allowed.");
			$('#file').val("");
			document.getElementById('uploadExcel').disabled = true;
			return false;
		}
		if(!fileName){
			document.getElementById('uploadExcel').disabled = true;
		}
		else{
			document.getElementById('uploadExcel').disabled = false;
			document.getElementById('fileDetailsField').style.display="block";
		}
	});//end file change()
	
	$("#searchField").hide();
	$("#salesSubmit").click(function(){		
		var validate = formValidation();
		
		if (validate) {
			var myOpts = document.getElementById('search_to').options;
	 		var text = "";
	 		var dy_columns = [];
	 		var table = document.getElementById("result").DataTable;
	 		var grp_by_field = document.getElementById('groupby').value;
	 		var aggr_func = document.getElementById('aggr_func').value;
	 		
			if(result){
				$("#result").DataTable().destroy();
				$("#result").empty();
				result = "";
			}
			document.getElementById("a6").childNodes[1].hidden=true;
			$('#failed').addClass('hide');
			document.getElementById("a6").childNodes[3].hidden=false;
			document.getElementById("btn2").disabled=false;
			document.getElementById("resultcard").hidden=false;			
	 		
	 		for (i=0 ; i<myOpts.length;i++){
	 			if (i == (myOpts.length -1)){
	 				text = text + myOpts[i]['text'];
	 				dy_columns[i] = {'title' : myOpts[i]['text'] };
	 			}
	 			else{
	 				text =text + myOpts[i]['text'] +",";
	 				dy_columns[i] = {'title' : myOpts[i]['text'] };
	 			}
	 		}
	 		
	 		if (grp_by_field != 'select column' && aggr_func != 'select aggregate function') {
	 			dy_columns.push({'title': aggr_func + '(' + grp_by_field + ')'});
	 		}
	 		
	 		$("#searchField").val(text);
	 		$('#img').show();
	 		$("#collapseFour").addClass('show');
	 		$("#result_processing").show();
	 		
	 		var form_name = 'sales';
			var form = document.getElementById('salesForm');
	 		var formData = new FormData(form);
	 		//show loader on click and remove after ajax call
	 		$.ajax({
 		   		 url: '/adhocQuery/'+form_name,
 		   		 type: "POST",
 		   		 cache: false,
 		   		 data: formData,
 		   		 contentType: false,
 		   	     processData: false,
 		   		 success: function(result_data){
 		   			$('#img').hide();
 		   			if (result_data['message'] == "success"){
	 		   			if (result){
	 		    			$('#result').DataTable().destroy();
	 		    			$('#result').empty();
	 		    		}
	 		   			
 		   				//datatable re-created with new values and headers
	 		   			result = $('#result').DataTable({
	 		   			dom: 'Bfrtip',
                        scrollX:true,
	 		   			destroy: true,
	 		   		    language: {
	 		   		        processing: "<img src='/static/images/loading.gif'>"
	 		   		    },
	 		   		    buttons: ['copy', 'csv', 'excel', 'pdf'],
	 		   		    processing: true,
	 		   		    data:result_data['data'],
		 		   		columns: dy_columns
	 		   			});//datatable end
 		   			}
 		   			if (result_data['message'] == "failed"){
					    $("#failedMessage").html('Please provide valid input');
					    $('#failed').removeClass('hide');
					    setTimeout(function() {
					       $('#failed').addClass('hide');
					    }, 10000);
 		 	        }
	 		   	}//success() close
	 		});//ajax close
		}
		
 	});// end sales click()

	
	$("#partsSubmit").click(function(){
	
		document.getElementById("a6").childNodes[1].hidden=true;
		
		document.getElementById("a6").childNodes[3].hidden=false;
		document.getElementById("btn2").disabled=false;
		document.getElementById("resultcard").hidden=false;
		var table = document.getElementById("result").DataTable;
		if(result){
			$("#result").DataTable().destroy();
			$("#result").empty();
			result = "";
		}
		$('#img').show();
		console.log('parts');
		var myOpts = document.getElementById('search_to').options;
 		var text = "";
 		var dy_columns = [];
 		for (i=0 ; i<myOpts.length;i++){
 			if (i == (myOpts.length -1)){
 				text = text + myOpts[i]['text'];
 				dy_columns[i] = {'title' : myOpts[i]['text'] };
 			}
 			else{
 				text =text + myOpts[i]['text'] +",";
 				dy_columns[i] = {'title' : myOpts[i]['text'] };
 			}
 		}
 		//console.log(dy_columns);
 		var value = $("#value_row1").val();
 		if (value){
 			$("#searchCriteria").val('yes');
 		}
 		else{
 			$("#searchCriteria").val('no');
 		}
 		$("#searchField").val(text);
		var form_name = 'parts';
		
		var form = document.getElementById('partsForm');
 		var formData = new FormData(form);
 		$("#collapseFour").addClass('show');
 		
 		$("#result_processing").show();
 		//show loader on click and remove after ajax call
 		$.ajax({
 		   		 url: '/adhocQuery/'+form_name,
 		   		 type: "POST",
 		   		 cache: false,
 		   		 data: formData,
 		   		 contentType: false,
 		   	     processData: false,
 		   		 success: function(result_data){
 		   			$('#img').hide();
 		   			if (result_data['message'] == "success"){
		 		   			if (result){
		 		    			$('#result').DataTable().destroy();
		 		    			$('#result').empty();
		 		    		}
		 		   			
	 		   				//datatable re-created with new values and headers
		 		   			result = $('#result').DataTable({
		 		   			dom: 'Bfrtip',
		 		   			destroy: true,
		 		   			scrollX:true,
		 		   			buttons: [ 'copy', 'csv', 'excel', 'pdf'],
		 		   		    language: {
		 		   		        processing: "<img src='/static/images/loading.gif'>"
		 		   		    },
		 		   		    processing: true,
		 		   		    data:result_data['data'],
			 		   		columns: dy_columns
		 		   			});//datatable end
 		   			}
	 		   		if (result_data['message'] == "failed"){
		 	        	  $("#failedMessage").html('Please provide valid input');
		  	         	  $('#failed').removeClass('hide');
		  	         	  setTimeout(function() {
		  		             $('#failed').addClass('hide');
		  		             }, 10000);
		 	        }
 		   		 }//success() close
 			});//ajax close
 	});// end sales click()
	
	$("#btn2").click(function() {
		$('#saveQueryMessage').addClass('hide');
		$("#SalesQueryName").val("");
		$("#SalesQueryDesc").val("");
		$('#salesSaveQuery').removeClass('hide');
	});
	// save query - sales
	$("#salesSaveQuery").click(function(){
			var validate = formValidation();
			
			if (validate) {
				var myOpts = document.getElementById('search_to').options;
		 		var text = "";
		 		var dy_columns = [];
		 		for (i=0 ; i<myOpts.length;i++){
		 			if (i == (myOpts.length -1)){
		 				text = text + myOpts[i]['text'];
		 				dy_columns[i] = {'title' : myOpts[i]['text'] };
		 			}
		 			else{
		 				text =text + myOpts[i]['text'] +",";
		 				dy_columns[i] = {'title' : myOpts[i]['text'] };
		 			}
		 		}
		 		
		 		$("#searchField").val(text);
				var form_name = 'sales';
		 		var form = document.getElementById('salesForm');
		 		var formData = new FormData(form);
		        var query_name = $("#SalesQueryName").val();
		        var query_desc = $("#SalesQueryDesc").val();
		 		formData.append('SalesQueryName', query_name);
		        formData.append('SalesQueryDesc', query_desc);
		 		//show loader on click and remove after ajax call
		 		$.ajax({
	 		   		 url: '/saveQuery/'+form_name,
	 		   		 type: "POST",
	 		   		 cache: false,
	 		   		 data: formData,
	 		   		 contentType: false,
	 		   	     processData: false,
	 		   		 success: function(result_data){
	 		   			if (result_data == "success"){
		 		   			$("#queryMessage").html('Save query Success');
		 		   			$('#saveQueryMessage').addClass('alert alert-success');
						    $('#saveQueryMessage').removeClass('hide');
						    $('#salesSaveQuery').addClass('hide')
	 		   			}
	 		   			if (result_data == "failed"){
		 		   			$("#queryMessage").html('Save query Failed');
		 		   			$('#saveQueryMessage').addClass('alert alert-danger');
						    $('#saveQueryMessage').removeClass('hide');
						    setTimeout(function() {
						       $('#saveQueryMessage').addClass('hide');
						    }, 10000);
	 		 	        }
		 		   	}//success() close
		 		});//ajax close
			}
	});

	$("#partsSaveQuery").click(function(){
			document.getElementById("a6").childNodes[1].hidden=true;
			
			document.getElementById("a6").childNodes[3].hidden=false;
			document.getElementById("btn2").disabled=false;
			document.getElementById("resultcard").hidden=false;
			var table = document.getElementById("result").DataTable;
			if(result){
				$("#result").DataTable().destroy();
				$("#result").empty();
				result = "";
			}
			$('#img').show();
			console.log('parts');
			var myOpts = document.getElementById('search_to').options;
	 		var text = "";
	 		var dy_columns = [];
	 		for (i=0 ; i<myOpts.length;i++){
	 			if (i == (myOpts.length -1)){
	 				text = text + myOpts[i]['text'];
	 				dy_columns[i] = {'title' : myOpts[i]['text'] };
	 			}
	 			else{
	 				text =text + myOpts[i]['text'] +",";
	 				dy_columns[i] = {'title' : myOpts[i]['text'] };
	 			}
	 		}
	 		//console.log(dy_columns);
	 		var value = $("#value_row1").val();
	 		if (value){
	 			$("#searchCriteria").val('yes');
	 		}
	 		else{
	 			$("#searchCriteria").val('no');
	 		}
	 		$("#searchField").val(text);
			var form_name = 'parts';
			var form = document.getElementById('partsForm');
	 		var formData = new FormData(form);
	 		$("#collapseFour").addClass('show');
	        var query_name = $("#PartsQueryName").val();
	        var query_desc = $("#PartsQueryDesc").val();
	 		formData.append('PartsQueryName', query_name);
	        formData.append('PartsQueryDesc', query_desc);
	 		$("#result_processing").show();
	 		//show loader on click and remove after ajax call
	 		$.ajax({
	 		   		 url: '/saveQuery/'+form_name,
	 		   		 type: "POST",
	 		   		 cache: false,
	 		   		 data: formData,
	 		   		 contentType: false,
	 		   	     processData: false,
	 		   		 success: function(result_data){
	 		   			$('#img').hide();
	 		   			if (result_data == "success"){
	                        $(".close").click();
	 		   			}
	 		   			if (result_data['message'] == "failed"){
						    $("#failedMessage").html('Save query failed');
						    $('#failed').removeClass('hide');
						    setTimeout(function() {
						       $('#failed').addClass('hide');
						    }, 10000);
	 		 	        }
		 		   	}//success() close
	 			});//ajax close
	});
	
	// Add options to the fields list and disable the operator
	// list
	$('#collapseOne').on("shown.bs.collapse", function() {
		$('table#tbl > tbody > tr').not(':last').remove();
		
		document.getElementById("andorfld").style.display="none";
		document.getElementById("andorhdr").style.display="none";
		document.getElementById("field").value = 'select column'
		document.getElementById("operator").value = 'select operator'
		document.getElementById("value1").value = ''
		document.getElementById("value2").value = ''
			
		$("#operator").prop("disabled", true);
		$("#value1").prop("disabled", true);
	});	
});//document close

function getCustList() {
	//refresh "file selection criteria" dropdown on runtime
	$.ajax({
		url: '/getCustList',
		type: "POST",
		cache: false,
		contentType: false,
		processData: false,
		async: false,
		success: function(result){
			//remove all values from "file selection criteria"
			$('#fileList').find('option').not(':first').remove();
			
			//add new file names in "file selection criteria"
				for(i=0;i<result.length;i++){
			     $('#fileList')
			        .append($("<option></option>")
			        .attr("value",result[i])
			        .text(result[i]));
				}//end for
			
		},//success close
		error: function () {

		}
	});//ajax close
}

function getPartList() {
	//refresh "file selection criteria" dropdown on runtime
	$.ajax({
		url: '/getPartList',
		type: "POST",
		cache: false,
		contentType: false,
		processData: false, 
		async: false,
		success: function(result){
			//remove all values from "file selection criteria"
			$('#fileList').find('option').not(':first').remove();
			
			//add new file names in "file selection criteria"
				for(i=0;i<result.length;i++){
			     $('#fileList')
			         .append($("<option></option>")
			         .attr("value",result[i])
			         .text(result[i]));
				}//end for
			
		},//success close
		error: function () {

		}
	});//ajax close
}
