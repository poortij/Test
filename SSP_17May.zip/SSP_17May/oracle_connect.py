from datetime import datetime
from cryptography.fernet import Fernet
import configparser
import cx_Oracle
import requests
import json
import requests
import base64
from collections import OrderedDict

from werkzeug.utils import secure_filename
from flask import abort, jsonify
from werkzeug.debug import get_current_traceback
import config

def get_db_pwd():
    """ read the dbconfig file and decrypt the db password"""
    dbconf = configparser.ConfigParser()
    inif = open(config.DB_CONFIG)
    dbconf.readfp(inif)
    key = dbconf.get("dbconf","key")
    pwd = dbconf.get("dbconf","pwd")
    cipher_suite = Fernet(str.encode(key, 'utf-8'))
    decoded = cipher_suite.decrypt(str.encode(pwd, 'utf-8'))

    return decoded.decode()
	
    
def get_con():
    dsnStr = cx_Oracle.makedsn(config.DB_SERVER, config.DB_PORT, config.DB_NAME)
    con = cx_Oracle.connect(user=config.DB_USER, password=get_db_pwd(), dsn=dsnStr)
    return con 

def insert_excel_data_to_db(list_of_dicts=None, file_type=None):
    """ This function reads data from uploaded excel file and do a bulk insert
    into db using executemany() command"""
    con = get_con()
    cur = con.cursor()
    # get the file object and parse it
    # create a list of dictionaries as the input to executemany()
    if file_type == 'customer':
        insert_query = 'INSERT INTO SSP_CUSTOMER_LIST (USER_NAME, FILE_NAME, CUST_CODE) \
        values (:USER_NAME,:FILE_NAME,:CUST_CODE)'
    elif file_type == 'parts':
        insert_query = 'INSERT INTO SSP_PART_LIST (USER_NAME, FILE_NAME, PART_NO) \
        values (:USER_NAME,:FILE_NAME,:PART_NO)'
    cur.execute("ALTER SESSION SET NLS_DATE_FORMAT = 'MM/DD/YYYY'")
    cur.prepare(insert_query)
    cur.executemany(None, list_of_dicts)
    con.commit()
    
def get_file_name_cust(user_name=None):
    result = []
    details = {'USER_NAME':user_name}
    # Returns unique file name from DB
    con = get_con()
    cur = con.cursor()
    select_query='select distinct(FILE_NAME) from SSP_CUSTOMER_LIST where USER_NAME=:USER_NAME'
    cur.execute(select_query,details)
    rowsData = cur.fetchall()
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result

def get_file_name_parts(user_name=None):
    result = []
    details = {'USER_NAME':user_name}
    # Returns unique file name from DB
    con = get_con()
    cur = con.cursor()
    select_query='select distinct(FILE_NAME) from SSP_PART_LIST where USER_NAME=:USER_NAME'
    cur.execute(select_query, details)
    rowsData = cur.fetchall()
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result
    
def get_cust_list(file_name,user_name):
    result = []
    file_details = {'FILE_NAME' : file_name,
                    'USER_NAME' : user_name}
    # Returns customer list from DB
    con = get_con()
    cur = con.cursor()
    select_query="select CUST_CODE from SSP_CUSTOMER_LIST where FILE_NAME=:FILE_NAME and USER_NAME=:USER_NAME"
    cur.execute(select_query, file_details)
    rowsData = cur.fetchall()
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result
    
def get_part_list(file_name, user_name):
    result = []
    file_details = {'FILE_NAME' : file_name,
                    'USER_NAME' : user_name}
    # Returns customer list from DB
    con = get_con()
    cur = con.cursor()
    select_query="select PART_NO from SSP_PART_LIST where FILE_NAME=:FILE_NAME and USER_NAME=:USER_NAME"
    cur.execute(select_query, file_details)
    rowsData = cur.fetchall()
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result

def check_user_file_name(user_name=None, file_name=None, file_type=None):
    result = []
    details = {'USER_NAME':user_name,
               'FILE_NAME':file_name}
    # Returns distinct available 
    con = get_con()
    cur = con.cursor()
    if file_type == 'customer':
        select_query='SELECT distinct(FILE_NAME) from SSP_CUSTOMER_LIST WHERE USER_NAME=:USER_NAME AND \
                    UPPER(FILE_NAME) = UPPER(:FILE_NAME)'
    elif file_type == 'parts':
        select_query='SELECT distinct(FILE_NAME) from SSP_PART_LIST WHERE USER_NAME=:USER_NAME AND \
                    UPPER(FILE_NAME) = UPPER(:FILE_NAME)'
    cur.execute(select_query, details)
    rowsData = cur.fetchall()
    
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result
    
def get_fields_to_display_parts():
    result = []
    # Returns distinct available 
    con = get_con()
    cur = con.cursor()
    select_query= config.FIELDS_TO_DISPLAY_PARTS
    cur.execute(select_query)
    rowsData = cur.fetchall()
    
    for row in rowsData:
        result.append(row)
    cur.close()
    con.close()
    return result

def get_group_by_parts():
    result = []
    # Returns distinct available 
    con = get_con()
    cur = con.cursor()
    select_query= config.GROUP_BY_PARTS
    cur.execute(select_query)
    rowsData = cur.fetchall()
    
    for row in rowsData:
        result.append(row)
    cur.close()
    con.close()
    return result

def get_selection_criteria_parts():
    result = []
    # Returns distinct available 
    con = get_con()
    cur = con.cursor()
    select_query= config.SELECTION_CRITERIA_PARTS
    cur.execute(select_query)
    rowsData = cur.fetchall()
    
    for row in rowsData:
        result.append(row)
    cur.close()
    con.close()
    return result

def get_fields_to_display_sales():
    result = []
    # Returns distinct available 
    con = get_con()
    cur = con.cursor()
    select_query= config.FIELDS_TO_DISPLAY_SALES
    cur.execute(select_query)
    rowsData = cur.fetchall()
    
    for row in rowsData:
        result.append(row)
    cur.close()
    con.close()
    return result

def get_selection_criteria_sales():
    result = []
    # Returns distinct available 
    con = get_con()
    cur = con.cursor()
    select_query= config.SELECTION_CRITERIA_SALES
    cur.execute(select_query)
    rowsData = cur.fetchall()
    
    for row in rowsData:
        result.append(row)
    cur.close()
    con.close()
    return result

def get_group_by_sales():
    result = []
    # Returns distinct available 
    con = get_con()
    cur = con.cursor()
    select_query= config.GROUP_BY_SALES
    cur.execute(select_query)
    rowsData = cur.fetchall()
    
    for row in rowsData:
        result.append(row)
    cur.close()
    con.close()
    return result

def track_user_details(data, session):
    query_details = {
                     'BEMSID' : int(session['bemsId']),
                     'FIRST_NAME' : config.TEST_USER_FIRST_NAME,
                     'LAST_NAME' : config.TEST_USER_LAST_NAME,
                     'PAGE' : (data['path'])[1:],
                     'DEFAULT_VALUE' : 1
                     }
    if config.WITH_WSSO:
        query_details = {
                         'BEMSID' : int(session['bemsId']),
                         'FIRST_NAME' : ((session['userName'].split(','))[1]).strip(),
                         'LAST_NAME' : ((session['userName'].split(','))[0]).strip(),
                         'PAGE' : (data['path'])[1:],
                         'DEFAULT_VALUE' : 1
                         }
    merge_query = " MERGE INTO SSP_TRACK_USAGE D \
                    USING (SELECT :BEMSID as BEMSID, trunc(sysdate) as LOGGED_IN_DATE, :PAGE as PAGE FROM dual) S \
                    ON ( D.PAGE = S.PAGE and D.BEMSID = S.BEMSID and D.LOGGED_IN_DATE = S.LOGGED_IN_DATE) \
                    WHEN MATCHED THEN UPDATE SET D.PAGE_COUNT = D.PAGE_COUNT + 1 \
                    WHEN NOT MATCHED THEN INSERT (BEMSID, FIRST_NAME, LAST_NAME, LOGGED_IN_DATE, PAGE, PAGE_COUNT) \
                    VALUES (:BEMSID, :FIRST_NAME, :LAST_NAME, trunc(sysdate), :PAGE, :DEFAULT_VALUE)"
    
    con = get_con()
    cur = con.cursor()
    cur.execute(merge_query, query_details)
    con.commit()
    
def save_query_text(query_data):
    """Save the search query executed by user"""
    insert_query = 'INSERT INTO SSP_QUERY_LIST (BEMSID, QUERY_NAME, QUERY_DESC, QUERY, QUERY_TYPE) \
    values (:BEMSID,:QUERY_NAME,:QUERY_DESC, :QUERY,:QUERY_TYPE)'
    con = get_con()
    cur = con.cursor()
    cur.execute(insert_query, query_data)
    con.commit()