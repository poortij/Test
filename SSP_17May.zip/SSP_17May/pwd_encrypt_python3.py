from cryptography.fernet import Fernet
import getpass
import configparser

pwd_text = getpass.getpass(prompt='Enter the password: ')

key = Fernet.generate_key()
cipher_suite = Fernet(key)
encoded_text = cipher_suite.encrypt(str.encode(pwd_text, 'utf-8'))

config = configparser.RawConfigParser()

config.add_section('dbconf')
config.set('dbconf', 'key', key.decode("utf-8"))
config.set('dbconf', 'pwd', encoded_text.decode("utf-8"))
with open('db.conf', 'w') as configfile:
    config.write(configfile)
