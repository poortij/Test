
#get-aduser –identity "AR106035" -Server corp | ForEach-Object {Add-ADGroupMember -Identity "MI-DEVAPPS-EAARCHITECT-CM2NT" -Server "mitchell" -Members $_}



