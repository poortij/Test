﻿#$Addresses = Get-Content "C:\Users\SV105835\Desktop\msdn\idees.txt"
param(
[string] $email
)
#foreach ($address in $Addresses){
    # Note you will need to check for servers "MITCHELL" and "CORP"
	Write-Host "trying to find $email"
	#$email = "shahreen.veedu@mitchell.com"
    $testUser_corp = get-ADUser -Server 'corp' -Filter "EmailAddress -eq '${email}'" -Properties * | Select-Object -Property SAMAccountName,EmailAddress,Enabled | Format-Table -AutoSize
	
    $testUser_mitchell = get-ADUser -Server 'mitchell' -Filter "EmailAddress -eq '${email}'" -Properties * | Select-Object -Property SAMAccountName,EmailAddress,Enabled | Format-Table -AutoSize
    
    if ($($testUser_corp.Length) -gt 0){
        Write-Host "$email exists" -ForegroundColor Green
        
    }
    elseif ($($testuser_mitchell.Length) -gt 0){
        Write-Host "$email exists" 
    }
    else{
	Write-Host "$email dont exists" -ForegroundColor Red
	#add-content "log.txt" "user ${email} does not exist in ${Domain}"
	}
#}
