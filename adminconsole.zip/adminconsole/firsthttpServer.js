var http = require("http");
var fs = require("fs");
var url = require("url");
var express = require("express");
var bodyParser= require("body-parser");
const shell = require ("node-powershell");
var ActiveDirectory = require("activedirectory2");
var sql = require("mssql/msnodesqlv8");
require("msnodesqlv8");
var app = express();
app.use(express.static("public"));
app.use(bodyParser.json());       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));
var globalUser;
var ad_config = { url: 'ldap://corpdc4.corp.int:389',
             baseDN: 'dc=corp,dc=int',
             username: 'prodartifact_svc',
             password: 'F*t*r3!slands_F451' }
            var ad = new ActiveDirectory(ad_config);
var db_config = {
                driver: "msnodesqlv8",
                server: "PSQL05P\\SPARXEAPROD1",
                database: "Production",
                options: {
                trustedConnection: true,
                useUTC: true
              }
            }
            /*connectionString: 'Driver={SQL Server Native Client 10.0};Server={2JBBK72-E7450\\SHOPSTREAM};Database={ShopMgtDemo};Trusted_Connection={yes}',*/
function getUserInfo(mit_id){
  var id=mit_id.substring(4);
  ad.findUser(id, function(err, user) {
    //var id=mit_id.substring(4);
  if (err) {
    console.log('ERROR: ' +JSON.stringify(err));
    return;
  }
  if (! user) {
    console.log('User ' + mit_id + ' not found.');
    }
  else {
    console.log(user);
    var info={"firstName":"shahreen","lastName":"veedu"};
    console.log(user["givenName"]+" is "+user["description"] +" at Mitchell. ");
    //res.end(JSON.stringify(user));
    console.log("found "+ JSON.stringify(info));
    return JSON.stringify(info);
    }
  });
}
/*****************************************************************************/

/*********************** /search_user: Query active directory for the user********************/
app.post('/search_user', function (req, res) {
  var mitch_id = req.body.mitch_id;
  console.log(mitch_id);
  //res.send(globalUser["displayName"]+" is "+globalUser["description"] +" at Mitchell. ");
  if(mitch_id.length==0){
    res.send("Enter a value for Mitchell Id");
    return;
  }
  ad.findUser(mitch_id, function(err, user) {
  if (err) {
    console.log('ERROR: ' +JSON.stringify(err));
    return;
  }
  if (!user) {
    console.log('User ' + mitch_id + ' not found.');
  //  res.send("Sorry, Cant find User ");

    }
  else {
    console.log(user);
    //res.send(user["displayName"]+" is "+user["description"] +" at Mitchell. ");
    res.end(JSON.stringify(user));
    }
  });
})
/***********************End app.post /search_user*******************************/

/*********************** /grant_EA: Grant access to EA*******************************/
app.post('/grant_EA', function (req, res) {
  var mit_id = req.body.mitchell_id;
  var groupOption= req.body.group;
  console.log("this group I got "+ groupOption);
  var id=mit_id.substring(5);
  if(id.trim().length==0){
    res.end("Invalid ID");
    return;
  }
  var psScript = "get-aduser -identity \""+id+"\" -Server corp | ForEach-Object {Add-ADGroupMember -Identity \"MI-DEVAPPS-EAARCHITECT-CM2NT\" -Server \"mitchell\" -Members $_}";
  console.log("psScript" +psScript);
    ad.findUser(id, function(err, user) {
      if (err) {
        console.log('ERROR trying to query AD: ' +JSON.stringify(err));
        return;
      }
      else{
        if(!user){
          console.log("user cannot be found at mitchell");
          res.end("user cannot be found at mitchell");
          return;
        }
        else{
        //  console.log("user found at mitchell"+JSON.stringify(user));
          console.log("user found at mitchell");
  sql.connect(db_config, err => {
      // ... error checks
  	if(err){
  		console.log("Error connecting to the Database : "+err);
      response.end("Error connecting to the EA Database");
  	}
      // Query
      var request = new sql.Request();
      request.query('SELECT * FROM t_secuser where UserLogin='+'\''+mit_id+'\'', (err1, q_result) => {
  		if(err1){
  			console.log("Something gone wrong with SQL query : "+err1);
        response.end("Something gone wrong with SQL query");
  		}
      else {
      if (q_result.recordsets[0].length==0){
        console.log("User does not have an EA license yet");

       console.log("user:"+user["givenName"]+" "+user["sn"]);
      //  res.end("user info found"+JSON.stringify(user));
      //  console.log("user:"+user);
      //stored procedure
        new sql.Request()
      .input('domainUser',sql.VarChar(32),mit_id)
      .input('firstName',sql.VarChar(50),user["givenName"])
      .input('lastName',sql.VarChar(50),user["sn"])
      .input('groupName',sql.VarChar(32),groupOption)
      .execute('s_addUser', (err3, resultq) => {
        if(err3){
          console.log(err3);
        }
        else{
          console.log("User successfully added");
          let ps = new shell({
            executionPolicy: 'Bypass',
            noProfile: true
          });

          ps.addCommand(psScript)
          ps.invoke()
          .then(output => {
            console.log(output);
          })
          .catch(err => {
            console.log(err);
            ps.dispose();
});
      }
      sql.close();
    })
      }
      else{
        console.log("RESULT : "+JSON.stringify(q_result));
        console.log(q_result.recordsets[0].length);
        sql.close();
        res.end("user already entered in EA Database");
      }
      //res.end(JSON.stringify(result));
    }
  }) //end sqlRequest
    })//end sqlconnect
  }
}
  });//end findUser
})



/***********************End app.get /grant_EA*****************************************/
/************* /delete_EA: remove access to EA and delete entry from DB*********/
app.post('/delete_EA', function (req, res){
  var mit_id=req.body.mitchell_id;
  sql.connect(db_config, err => {
      // ... error checks
  	if(err){
  		console.log("Error connecting to the Database : "+err);
  	}
      // Query
      new sql.Request().query('SELECT * FROM t_secuser where UserLogin='+'\''+req.body.mitchell_id+'\'', (err1, result) => {
  		if(err1){
  			console.log("Something gone wrong with query : "+err1);
          res.end(err1);
  		}
      else {
        if (result.length==0){
          console.log("User not found");
          res.end("NOT FOUND");
        }
        else{
          console.log("User is found : "+JSON.stringify(result));
          //res.end(JSON.stringify(result));
          new sql.Request()
          .input('domainUser',sql.VarChar(32),mit_id)
          .execute('s_dropUser', (err3, resultq) => {
            if(err3){
              console.log(err3);
              res.end(err3);
            }
            else{
              console.log("Done");
              res.end("OK");
            }
          })
        }
      }
    }) //end sql.Request
}) //ens sqlConnect
})
/*************************End app.post /delete_EA*************************************/

app.get('/index.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "index.htm" );
   //res.sendFile( __dirname + "/css/" + "main.css" );
})

var server = app.listen(9000, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})
