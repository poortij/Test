from PIL import Image
#if above python 3.0 then install PILOW and then import PIL else directly install PIL
import pytesseract 
 #please install tesseract exe and install Pytesseract
 #basic code for reading data from image 

pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files (x86)/Tesseract-OCR/tesseract.exe'
tessdata_dir_config = '--tessdata-dir "C:/Program Files (x86)/Tesseract-OCR"'

im = Image.open('fake.png')
im.save("fake-600.png", dpi=(600,600))  #used for pixeling the image 
print(im)

width, height = im.size
print "Dimensions:", im.size, "Total pixels:", width * height


text = pytesseract.image_to_string(im, lang='eng',config= tessdata_dir_config)

print(text)

