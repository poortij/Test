from PIL import Image
im = Image.open('fake.png')
pixelMap = im.load()

img = Image.new( im.mode, im.size)
pixelsNew_fake = img.load()
for i in range(img.size[0]):
    for j in range(img.size[1]):
        if 205 in pixelMap[i,j]:
            pixelMap[i,j] = (0,0,0,255)
        else:
            pixelsNew_fake[i,j] = pixelMap[i,j]
img.show()

