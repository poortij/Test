import json
import pandas as pd
from pymongo import MongoClient
client = MongoClient


db = client['PMA_Stage']
collection = db.collection_name
data = pd.DataFrame(list(collection.find()))






