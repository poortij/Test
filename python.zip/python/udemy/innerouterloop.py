menu=[]
menu.append(['poorti','jain','raja'])
menu.append(['pradeep','gera'])
# use of inner,outer loop
for name in menu:
    if not 'jain'in  name:
        print(list(name)) # print a  list [pradeep,gera]
for values in name:
    print(values)  # pradeep,gera separately not in a list format
    
    
    
string='poorti'
for char in string:
    print(char)# p o o r t i
    
char2=iter(string)
print(char2)# prints nothing
print(next(char2))# print p
print(next(char2))# prints o
len(string)



names=['poo','jain','raja']
length=len(names)
iterator=iter(names)
for i in names:
    print(next(iterator))

odd=range(1,20,2) # odd numbers
print(odd)
even=range(0,10,2)
print(even)# even numbers

string='poorti'
print(string.index('o'))



print('=' * 50)


r=range(0,100,4)
print(r)

another=r[::5]
for j in another:
    print(j)
    
print('=' * 50)
#doubt updating tuple
schools='pp','aa','cc'
print(schools)
schools=schools[0],'ba',schools[2]
print(schools)

#use of tuple over list
print('=' * 50)
name,city,year=schools
print(name)
print(city)
print(year)

list1=['yo','yo','honey']
name,city,year=list1
print(name)
print(city)
print(year)

name,city=schools
print(name)
print(city)

list1=['yo','yo','honey']
name,city=list1
print(name)
print(city)



    
    
    