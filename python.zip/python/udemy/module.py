class A:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def values(self):
        print("name and age is"+self.name,self.age)
class B(A):
    def __init__(self,name,age,surname):
        super().__init__(name,age)
        self.surname=surname
        
    def values(self):
        return super().values()+self.surname
    
b=B('poorti',23,'jain')
print(b.values())
        
        
        
