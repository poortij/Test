#!/boeing/sw/ecfd/bin/python2.7
"""Poll Scheduler is mainly used to pick the data from sched collection and initialize poller for each and every entry in 
the sched collection.
"""
__author__ = "Sreevatsa Beleyur Devappa"
__copyright__ = ""
__credits__ = ["Sreevatsa Beleyur Devappa , Venkata Harish Nagamangalam,Ritesh Kumar Srivastava, Neeharika Pittu"]
__license__ = ""
__version__ = "1.0"
__maintainer__ = "Sreevatsa Beleyur Devappa"
__email__ = "sreevatsa.b@hcl.com"
__status__ = "Code Generator"
__lastupdatedon__= "08/11/2014" #dd/mm/yyyy

import time
import traceback
from DatabaseWrapper import eCFDdb
from EcfdConfig import EcfdConfig
import threading
from BottleAppLogger import BottleAppLogger
import json  
from Poller import Poller  
from datetime import datetime    

class ThreadEcfd(threading.Thread):
    """Contains all the necessary methods to perform the ThreadEcfd class.Picks the data from sched collection and initialize 
    poller for each and every entry in the sched collection."""
    def __init__(self, sched_id, transaction_id, stepname, pbsid, sync_async,process_type,caseId, BottleLog):
        """Initializer for the ThreadEcfd class.
        Args:
             sched_id:Object id of the document for which polling is to be done.
             transaction_id:Object id of the document for which the polling is to be done,
             action:Respective name of the step for which the polling is to be done,
             pbsid:pbsid value for which polling is to be done
             sync_async:whether the step is synchronous or asynchronous and has result or not.
        """
        threading.Thread.__init__(self)
        self.sched_id = sched_id
        self.transaction_id = transaction_id
        self.stepname = stepname
        self.pbsid = pbsid
        self.process_type=process_type
        self.caseId=caseId
        self.sync_async = sync_async
        self.BottleLog = BottleLog
    
    def run(self):
        """Initializes the poller for the polling procedure.
        Returns:
            Returns the poller error in case of failure condition,
        """
        try:
            self.BottleLog.logger.info("%s:Initializing the poller"%(self.transaction_id))
            poller = Poller(self.sched_id, self.transaction_id, self.stepname, self.pbsid, self.sync_async,self.process_type,self.caseId)
            poller.poll()
            if poller.error!=None:
                print (poller.error)
        except:
            self.BottleLog.logger.error('Error in checking the status of case id %s'%(self.transaction_id))
        

class PollScheduler(threading.Thread):
    """Contains all the necessary methods to perform the PollScheduler class."""
    def __init__(self):
        """Initializer for the PollScheduler class."""
        self.config_data = EcfdConfig()
        self.BottleLog = BottleAppLogger('PollScheduler')
        self.db = eCFDdb()
        self.db.connect(self.config_data.DatabaseName)
        self.username = self.config_data.scheduler_username    
        self.BottleLog.logger.debug('ThreadedScheduler initialized with username %s'%(self.username))
    
        
    def check(self): 
        """Threading of polling starts here.when once the thread has started if the difference between the last poll time and 
        present poll time is greater than poll limit,that respective values will be moved to thread again."""   
        while 1:
               try:
                   self.db.get_datastore(self.config_data.eCFD_Sched_Collection)
                   if self.db.db_error==None:
                       if self.db.db_output!='[]':
                           for sched in json.loads(self.db.db_output):
                                try:
                                    if sched['first_poll'] != 'Yes':
                                        time_format = "%Y-%m-%d %H:%M:%S.%f"
                                        t1 = datetime.strptime(sched['last_poll_time'], time_format)
                                        t2 = datetime.now()
                                        time_elapsed = (t2-t1).seconds
                                        if time_elapsed <= int(sched["poll"]):
                                            continue
                                except:
                                    pass        
                                for i in range(len(sched['pbsid'])):
                                    t = ThreadEcfd( sched['_id'], sched['transaction_id'], sched['stepname'],sched['pbsid'][i],
                                                    sched['sync_async'],sched["process_type"],sched["caseId"], self.BottleLog)
                                    t.start()
                                    t.join()
                       else:
                           print ("Documents does not exist in Sched")
                   else:
                       print ("DB error==", self.db.db_error)
               except:
                   self.BottleLog.logger.error('Error in ThreadedScheduler - %s'%(traceback.format_exc().splitlines()[-3:]))
                   continue
               time.sleep(120)

if __name__=='__main__':
    PollScheduler().check()            
            
                
