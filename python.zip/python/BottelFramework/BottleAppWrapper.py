#!/boeing/sw/ecfd/bin/python2.7

"""BottleAppWrapper is the main entry point for the eCFD integration layer.This will instantiate an application object which 
has several web services embedded in the object. The web services include the SSH authentication ,Database CRUD services,
Launching different solvers, Data analysis and more...
"""

__author__ = "Sreevatsa Beleyur Devappa"
__copyright__ = ""
__credits__ = ["Sreevatsa Beleyur Devappa , Venkata Harish Nagamangalam,Ritesh Kumar Srivastava, Neeharika Pittu"]
__license__ = ""
__version__ = "1.0"
__maintainer__ = "Sreevatsa Beleyur Devappa"
__email__ = "sreevatsa.b@hcl.com"
__status__ = "Code Generator"
__lastupdatedon__= "08/11/2014" #dd/mm/yyyy

import json
import os
import shutil
import traceback
from bottle import Bottle, run, route, request, response, abort,BaseRequest
from functools import partial
from JsonHelper import jsonify
from EcfdConfig import EcfdConfig
from BottleAppLogger import BottleAppLogger
from DatabaseWrapper import eCFDdb
from ImportUtility import ImportGridOrConf
from Abort_Plans import Abort_Plans
from Retriever import Retriever
from Executor import Executor
from Launcher import  Launcher
from DataMapper import DataMapper
from AlgorithmicTasks import ComputeAtmoTable
from UtilityTools import UtilityTools
config_data = EcfdConfig()
template_script_path = config_data.templatescript_path
import sys
sys.path.append(template_script_path)
import template
from template import Template
from EcfdCaller import EcfdCaller
from AlgorithmicTasks import FlightConditionMatrix
import copy  
import subprocess
from subprocess import Popen,PIPE,STDOUT          

BaseRequest.MEMFILE_MAX = 8096 * 8096

class BottleAppWrapper:
    
    def get_error_handler(self):
        """Customized errors"""
        return {
            500: partial(self.error, message="Internal Server Error."),
            404: partial(self.error, message="Document Not Found."),
            501: partial(self.error, message="Not Implemented."),
            405: partial(self.error, message="Method Not Allowed."),
            403: partial(self.error, message="Forbidden."),
            400: self.error,
        }

    def error(self, error, message=None):
        """Returns the error response."""
        return jsonify({"error": error.status_code,
                        "message": error.body or message})

    def after_request(self):
        """A bottle hook for json responses."""
        response["content_type"] = "application/json"
        methods = 'PUT, PATCH, GET, POST, DELETE, OPTIONS'
        headers = 'Origin, Accept, Content-Type, X-Requested-With, X-CSRF-Token'
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = methods
        response.headers['Access-Control-Allow-Headers'] = headers

    def get_bottle_app(self):
        """Returns bottle instance"""
        self.app = Bottle()
        #self.dispatch_views()
        self.app.hook('after_request')(self.after_request)
        self.app.error_handler = self.get_error_handler()       
        return self.app


#db = eCFDdb()
config_data = EcfdConfig()
BottleLog = BottleAppLogger('BottleAppWrapper')
BottleLog.logger.info('starting bottle app wrapper')
app = BottleAppWrapper().get_bottle_app()
BottleLog.logger.info('bottle app wrapper started')


@app.route('/ecfd/buildNumbers', method=["GET","POST","OPTIONS"])
def hello():
    """Returns the current version of the code deployed and the current template version.
        Example:
            http://ecfd-devtest.cs.boeing.com:58181/cg_python_dev/ecfd/buildNumbers    
    """
    try:
        print('try',request.json)
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        print(json.loads(request.json))
    #return "Hello User Welcome to Code Generator! version is %s \n template version is %s"%(config_data.version, template.__version__)
    return jsonify({"Message":"Success", "Result": {"cg_python":config_data.version,"template":template.__version__}, "Description":"Success", "Code":"PYT100" })

@app.route('/ecfd/<dbName>/cleanDatabase')
def cleanup_database(dbName):
    """Cleans the respective database.
        Args:
            DbName:Name of the respective database to be deleted.
        Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/cleanDatabase
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        db.cleanup_database(dbName)
        if db.db_error==None:
            BottleLog.logger.info('Cleaned up %s database'%(dbName))
            response.status = 200
            #return jsonify({dbName :"cleaned successfully"})
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Success", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            #return jsonify({dbName :"clean database failed"})
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
        "Description":"We are unable to process your request due to a system error. Please contact support.", "Code":"PYT228" })

@app.route('/ecfd/<dbName>/<collection>/cleanCollection')
def cleanup_collection(dbName, collection):
    """Cleans/Drops the respective collection.
        Args:
            DbName:Name of the respective database in which the collection to be deleted is present .
            collection:Name of the collection to be deleted.
        Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/cleanCollection
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        db.cleanup_collection(collection)
        if db.db_error==None:
            BottleLog.logger.info('Cleaned up %s collection in %s database'%(collection, dbName))
            response.status = 200
            desc_out=db.error_lookup("Utility",db.code)
            #return jsonify({collection :"cleaned successfully"})
            return jsonify({"Message":"Success", "Result": {}, 
                        "Description": desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            #return jsonify({dbName :"clean collection failed"})
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description": desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT263" })
    
@app.route('/ecfd/<dbName>/<collection>/createCollection')
def create_collection(dbName, collection):
    """Creates the collection by picking the respective json from the DB_Jsons folder.
        Args:
            DbName:Name of the respective database in which the collection to has to be created.
            collection:Name of the collection to be created.
        Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/createCollection
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        db.create_collection(collection)
        if db.db_error==None:
            BottleLog.logger.info('Created %s collection in %s database'%(collection, dbName))
            response.status = 200
            desc_out=db.error_lookup("Utility",db.code)
            #return jsonify({""+collection+" Document" :"inserted successfully"})
            return jsonify({"Message":"Success", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            desc_out=db.error_lookup("Utility",db.code)
            #return jsonify({dbName :"create "+collection+" collection failed!!" })
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description": "We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT264" })                        

@app.route('/ecfd/<dbName>/<collection>/<type>/createNewCollection', method=['OPTIONS','POST','GET'])
def createcollection_new(dbName, collection , type):
    """Creates the collection by picking the respective json from the DB_Jsons folder or by storing the data provided.
        Args:
            DbName:Name of the respective database in which the collection to has to be created.
            collection:Name of the collection to be created.
            Type:If the value is 0 it picks the respective json from the DB_Jsons folder,if the value is 1 it stores
                the data provided in the created collection.
        Url Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/0/createNewCollection
        Input Example:
            data=json data to be added.
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for createcollection_new service is %s" %(data))
        db.cleanup_collection(collection)
        db.create_collection_new(collection, type, data)
        if db.db_error==None:
            BottleLog.logger.info('Created %s collection in %s database'%(collection, dbName))
            response.status = 200
            if type==0:
                #return jsonify({""+collection+" Document" :"inserted successfully"})
                desc_out=db.error_lookup("Utility", db.code)
                return jsonify({"Message":"Success", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":db.code})
            else:
                desc_out=db.error_lookup("Utility", db.code)
                # return jsonify({"success":"Collection created","doc_id":db.db_output,"collectionName":collection})
                return jsonify({"Message":"Success", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":db.code })    
        else:
            desc_out=db.error_lookup("Utility", db.code)
            response.status = 200
            BottleLog.logger.error(db.db_error)
            #return jsonify({"collectionName" :collection, "error": db.db_error })
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code })

    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT265" })


@app.route('/ecfd/<dbName>/<collection>/get/<mongoid>')
def get(dbName, collection, mongoid):
    """Returns the respective data based on the given collection name and mongo_id.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
            mongoid:ObjectId of the respective json to be returned.
        Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/get/5434ff54cd8fc203acaccb31
    """
    try:
        BottleLog.logger.info('Getting data from collection - %s'%(collection))
        db = eCFDdb()
        db.connect(dbName)
        db.get(collection, mongoid)
        BottleLog.logger.info("Requested input for get service is %s" %(mongoid))  
        if db.db_error==None:
            if db.db_output==None:
                BottleLog.logger.error('No data')
                #return jsonify({"error":"No data retrieved!"})
                desc_out=db.error_lookup("Utility", "PYT226")
                return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT226" })
            else:
                response.status = 200                
                BottleLog.logger.info('received data from db')
                desc_out=db.error_lookup("Utility",db.code)               
                return jsonify({"Message":"Success", "Result": json.loads(db.db_output),
                                 "Description":desc_out["UIDescription"], "Code":db.code})
                #return db.db_output
        else:
            desc_out=db.error_lookup("Utility",db.code)
            response.status = 200
            BottleLog.logger.error(db.db_error)
            #return jsonify({"error":db.db_error})
            return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code })
    except:
        
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT266" })
    
@app.route('/ecfd/<dbName>/<collection>/getData')
def get_dataall(dbName, collection):
    """Returns the entire json documents present in that respective collection.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/getData
    """
    try:
        BottleLog.logger.info('Getting data from collection - %s'%(collection))
        db = eCFDdb()
        db.connect(dbName)
        db.get_datastore(collection)  
        if db.db_error==None:
            if db.db_output==None:
                BottleLog.logger.error('No data')
                #return jsonify({"error":"No data retrieved!"})
                desc_out=db.error_lookup("Utility", "PYT226")
                return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT226" })
            else:
                response.status = 200
                BottleLog.logger.info('received data from db')
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": json.loads(db.db_output),
                                 "Description":desc_out["UIDescription"], "Code":db.code })
                #return db.db_output
        else:
            response.status = 200
            #return jsonify({"error":db.db_error})
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])        
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT267"})
    
@app.route('/ecfd/<dbName>/<collection>/getids', method=['OPTIONS','POST','GET'])
def get_ids(dbName, collection):
    """Returns the ObjectIds of all the json documents present in that respective collection.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/getids
    """
    try:
        BottleLog.logger.info('Getting data from collection - %s'%(collection))
        db = eCFDdb()
        db.connect(dbName)
        if request.method == "POST":
            data=request.json
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')
                desc_out=db.error_lookup("Utility","PYT227")
                return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })   
            else:
                db.get_ids(collection,data)  
                if db.db_error==None:
                    if db.db_output==None:
                        BottleLog.logger.error('No data')
                        #return jsonify({"error":"No data retrieved!"})
                        desc_out=db.error_lookup("Utility", "PYT226")
                        return jsonify({"Message":"Error", "Result": {}, 
                                "Description":desc_out["UIDescription"], "Code":"PYT226" })
                    else:
                        response.status = 200
                        BottleLog.logger.info('received data from db')
                        desc_out=db.error_lookup("Utility",db.code)
                        return jsonify({"Message":"Success", "Result":db.db_output,
                                         "Description":desc_out["UIDescription"], "Code":db.code })
                        #return jsonify({"ids":db.db_output})
                else:
                    response.status = 200
                    BottleLog.logger.error(db.db_error)
                    #return jsonify({"error":db.db_error})
                    desc_out=db.error_lookup("Utility",db.code)
                    return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code })
                
        elif request.method == "GET":
            db.get_ids(collection)  
            if db.db_error==None:
                if db.db_output==None:
                    BottleLog.logger.error('No data')
                    #return jsonify({"error":"No data retrieved!"})
                    desc_out=db.error_lookup("Utility", "PYT226")
                    return jsonify({"Message":"Error", "Result": {}, 
                            "Description":desc_out["UIDescription"], "Code":"PYT226" })
                else:
                    response.status = 200
                    BottleLog.logger.info('received data from db')
                    desc_out=db.error_lookup("Utility",db.code)
                    return jsonify({"Message":"Success", "Result":{"ids":db.db_output},
                                     "Description":desc_out["UIDescription"], "Code":db.code })
                    #return jsonify({"ids":db.db_output})
            else:
                response.status = 200
                BottleLog.logger.error(db.db_error)
                #return jsonify({"error":db.db_error})
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code })    
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT268" })
    
@app.route('/ecfd/<dbName>/<collection>/storeData', method=['OPTIONS','POST'])
def store_data(dbName, collection):
    """Stores the input bare json i.e publish.json/ transaction.json/Master.json  in that respective collection.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Url Example:
            http:// 10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/storeData
        Input Example:
            data=json data to be added.
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for store_data service is %s" %(data))
        BottleLog.logger.info('Storing data in collection - %s'%(collection))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            if collection.lower() == "auditlog":
                db.store_auditdata(collection, data)
            else:
                db.store_data(collection, data)
            if db.db_error==None:
                BottleLog.logger.info('received data from db and stored it successfully')
                response.status = 202
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": {'doc_id': db.db_output}, 
                                "Description":desc_out["UIDescription"], "Code":db.code })
                #return jsonify({'success' : 'request accepted','doc_id': db.db_output})
            else:
                response.status = 200
                #return jsonify({"error":db.db_error})
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT269" })


@app.route('/ecfd/<dbName>/<collection>/updatePartData', method=['OPTIONS','POST'])
def update_partdata(dbName, collection):
    """Updates the json based the ObjectId and the update data(i.e the path of the field and the value of
    the filed to be updated) in the respective collection.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Url Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/updatePartData 
        Input Example:
            data={'_id':'541af513cd8fc225dc102748','updatedata': {'mydata.complex.a.b':'22'}}
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for update_partdata service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            BottleLog.logger.info('Storing data in collection - %s for id %s'%(collection, data['_id']))
            db.update_partdata(collection, data)
            if db.db_error==None:
                response.status = 202
                BottleLog.logger.info('recieved data from db and updated it successfully')
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code })
                #return jsonify({'success' : 'request accepted'})
            else:
                response.status = 200
                #return jsonify({"error":db.db_error})
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT270" })
        
@app.route('/ecfd/<dbName>/<collection>/updatewithquery', method=['OPTIONS','POST'])
def update_with_query(dbName, collection):
    """Updates the json based on the query,update path and data  provided with the (i.e the path of the field and the value of
    the filed to be updated) in the respective collection.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Url Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/updatewithquery 
        Input Example:            
            data={"_id":"55ed2736dc16ed0314078b47","query":{"AnalyseProcess.id":2632},"update":{"AnalyseProcess.$.Name":"AeroDB","AnalyseProcess.$.Status":""}}
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for update_partdata service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            BottleLog.logger.info('Storing data in collection - %s for id %s'%(collection, data['_id']))
            db.update_with_query(collection, data)
            if db.db_error==None:
                response.status = 202
                BottleLog.logger.info('recieved data from db and updated it successfully')
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code })
                #return jsonify({'success' : 'request accepted'})
            else:
                response.status = 200
                #return jsonify({"error":db.db_error})
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT271" })
        
@app.route('/ecfd/<dbName>/<collection>/updatePartDataOnId', method=['OPTIONS','POST'])
def update_partdataonid(dbName, collection):
    """"Updates particular blocks like AppJson,Runs,Status and Notes block in the transaction collection
        of database.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Url Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/updatePartDataOnId 
        Input Example:
            data={'_id':'541af513cd8fc225dc102748','id' : '2188','block':'AppJson','stepname':'GridConnectivity',
                  'status_details':'InProgress'}
        """            
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for update_partdataonid service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            process_type=data["process_type"]
            if "caseId" in data.keys():
                caseId=data["caseId"]
                if caseId != None and caseId != "" and caseId != "null":
                    caseId=int(caseId)
                db.update_partdata_onid(collection, data,process_type,caseId)
            else:
                db.update_partdata_onid(collection, data,process_type)
            if db.db_error==None:
                response.status = 202
                BottleLog.logger.info('recieved data from db and updated it successfully')
                #return jsonify({'success' : 'request accepted'})
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code})
            else:
                response.status = 200
                #return jsonify({"error":db.db_error})
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT272" })

@app.route('/ecfd/<dbName>/<collection>/updateData', method=['OPTIONS','POST'])
def update_data(dbName, collection):
    """Updates the json based the ObjectId and the update data(i.e the json object to be updated)
    in the respective collection.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Url Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/updateData 
        Input Example:
            data={'_id':'541af513cd8fc225dc102748','updatedata': {'mydata.complex.a.b':'22'}}        
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for update_data service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            BottleLog.logger.info('Storing data in collection - %s for %s'%(collection, data['id']))
            query = {}
            query['_id'] = data['id']
            db.update_data(collection, query, data['udata'])
            if db.db_error==None:
                response.status = 202
                BottleLog.logger.info('recieved data from db and updated it successfully')
                #return jsonify({'success' : 'request accepted'})
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code})
            else:
                response.status = 200
                #return jsonify({"error":db.db_error})
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT273" })
    
@app.route('/ecfd/<dbName>/<collection>/query/<single_multiple>', method=['OPTIONS','POST'])
def query_data(dbName, collection, single_multiple):
    """Queries in respective collection based on either ObjectId or query and returns the output as list.    
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
            single_multiple:if single it queries for single query or it searches for multiple queries.            
        URL Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/publish/query/single        
        Input Example:            
          query='_id:'541fde8ccd8fc224a44c3405','mydata.complex.b':'23'            
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        query = request.json
        BottleLog.logger.info("Requested input for query_data service is %s" %(query))
        if not query:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:    
            db.query_data(collection, query, single_multiple)
            if db.db_error==None:
                if db.db_output==None:
                    BottleLog.logger.error('No data')
                    #return jsonify({"error":"No data retrieved!"})
                    desc_out=db.error_lookup("Utility","PYT226")
                    return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT226" })
                else:
                    BottleLog.logger.debug('Getting data from collection - %s for query - %s'%(collection, query))
                    response.status = 200
                    #return db.db_output
                    desc_out=db.error_lookup("Utility",db.code)
                    return jsonify({"Message":"Success", "Result": json.loads(db.db_output), 
                                    "Description":desc_out["UIDescription"], "Code":db.code})
            else:
                response.status = 200
                #return jsonify({"error":db.db_error})
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"],"Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT274" })
        
    
@app.route('/ecfd/<dbName>/<collection>/search', method=['OPTIONS','POST','GET'])
def search_data(dbName, collection):
    try:
        data = request.json
        if request.method == 'POST':
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')
                return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"No data received!", "Code":"PYT200" })
            else:
                db = eCFDdb()
                db.connect(dbName)
                result = db.searchTransaction(collection, data)
                if result == "{\"searchResult\": []}":
                    BottleLog.logger.error('No Search results retrieved')
                    #abort(400, 'No data received')
                    return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"No Search results retrieved!", "Code":"PYT200" })
                BottleLog.logger.info('Search results received successfully')
                #return result
                return jsonify({"Message":"Success", "Result": json.loads(result) , "Description":"Success", "Code":"PYT100" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":traceback.format_exc().splitlines()[-1], "Code":"PYT200" })

@app.route('/ecfd/<dbName>/<collection>/ImportGridConf', method=['OPTIONS','POST','GET'])
def import_grid_conf(dbName,collection):
    """Imports the grid data into master collection based on input data.
       Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
       URL Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/master/ ImportVolgrid
       Input Example:
            data=volgrid.import.extract.json file
    """
    #fh = open('DB_Jsons/volgrid.import.extract.json')
#     fh = open('DB_Jsons/surfgrid.extract.json')
#     masterData = json.load(fh)
#     fh.close()
    data = request.json
    BottleLog.logger.info("Requested input for import_grid_conf service is %s" %(data))
    #The following line is used for unit test
    #masterData = data['data'] #json.loads(data)
    #BottleLog.logger.debug(data)
    #masterData = json.loads(data)
    masterData = data
    db = eCFDdb()
    db.connect(dbName)
    try:
        entitytype = None
        if masterData['import'][0]['import'][0]['import']['EntityType'] == "VolumeGrid":
            entitytype = "volumegriddata"
        elif masterData['import'][0]['import'][0]['import']['EntityType'] == "SurfaceGrid":
            entitytype = "surfacegriddata"
        elif masterData['import'][0]['import'][0]['import']['EntityType'] == "Configuration":
            entitytype = "configurationdata"
        else:
            BottleLog.logger.error("Unknown entity type")
            #return jsonify({"success":"Unknown entity type"})
            desc_out=db.error_lookup("Utility","PYT224")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT224" })           
            
        BottleLog.logger.info('Trying to Import the '+entitytype+' ')
        importgridconf = ImportGridOrConf(masterData,collection)
        data = importgridconf.import_grid_or_conf(entitytype)
        BottleLog.logger.debug(data)
        if data == 1:
            BottleLog.logger.info('The '+entitytype+' already exists')
            #return jsonify({"success":"The "+entitytype+" which you are trying to import already Exists"})
            desc_out=db.error_lookup("Utility",importgridconf.code)
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":importgridconf.code})
        if data!=False:
            #result = db.get_grids(collection,"volumegrid")
            result = db.get_grids(collection, entitytype.split("data")[0])
            BottleLog.logger.info(result)
            BottleLog.logger.debug(result)
            for i in range(len(result)):
                if entitytype in result[i]:
                    result = result[i]
            gridconf = result[entitytype]
            grid_conf_data = []
            for i in range(len(gridconf)):
                gridconf[i] = json.dumps(gridconf[i])
                gridconf[i] = json.loads(gridconf[i])
                grid_conf_data.append(gridconf[i])
            #updatedb = db.update_volgrids(collection,data,volgrid_data)
            updatedb = db.update_grid_or_conf(collection, entitytype, data, grid_conf_data)
            BottleLog.logger.info('Successfully Imported the '+entitytype+'')
            #return updatedb
            desc_out=db.error_lookup("Utility",importgridconf.code)
            return jsonify({"Message":"Success", "Result": json.loads(updatedb), 
                            "Description":desc_out["UIDescription"], "Code":importgridconf.code })
        else:
            BottleLog.logger.error('Failed to Import the '+entitytype+'')
            #return jsonify({"success":"Failed to Import "+entitytype+" "})
            desc_out=db.error_lookup("Utility",importgridconf.code)
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":importgridconf.code })
            
    except:
        BottleLog.logger.error('Failed to Import the data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
        #return jsonify({"success":"Failed to Import data"})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT275" })

@app.route('/ecfd/<dbName>/<collection>/Getgrids',method=['OPTIONS','POST','GET'])
def get_grids(dbName,collection):
    """Returns the values of name,URL,Description,ReynoldsNumber,VehicleModel,VehicleSubModel,Date,Person 
    of the respective grids based on the name of the grid.If the respective URL value is present in deleted
    objects block it will not pass the respective all the above values of that grid in the output.
       Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
       URL Example:
            http://10.138.41.56:58181/ecfd_repo_test_cg/ecfd/ecfddbcg/master/ Getgrids
       Input Example:
            data={"entity" :"volumegrid"}  
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        #data={"entity":"configuration"}
        data=request.json
        BottleLog.logger.info("Requested input for get_grids service is %s" %(data))
        grid_type= data["entity"].lower()        
        bemsid = data["bemsid"]
        owner_check = True
        if data["isadmin"].lower() == "true":
            owner_check = False 
        db.get_grids(collection,grid_type)       
        if db.db_error == None:
            if db.db_output==None:
                    BottleLog.logger.error('No data')
                    #return jsonify({"error":"No data retrieved!"})
                    desc_out=db.error_lookup("Utility","PYT226")
                    return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT226" })
            else:
                result = db.db_output[0]                
                grid_conf_data = result[grid_type+"data"]
                if owner_check:
                    grid_conf_filtered = []
                    for i in range(len(grid_conf_data)):
                        if grid_conf_data[i].has_key("Owner"): 
                            if grid_conf_data[i]["Owner"] == bemsid:
                                grid_conf_filtered.append(grid_conf_data[i])
                        else:
                            grid_conf_filtered.append(grid_conf_data[i])
                    grid_conf_data = grid_conf_filtered                
                #volgrid_data = result['volumegriddata']
                grids_conf = []
                for i in range(len(grid_conf_data)):
                    op={}
                    op["Name"] = grid_conf_data[i]["Name"]
                    op["URL"] = grid_conf_data[i]["URL"]
                    #op["Description"] = grid_conf_data[i]["Description"]
                    op["ReynoldsNumber"] = grid_conf_data[i]["ReynoldsNumber"]
                    op["VehicleModel"] = grid_conf_data[i]["VehicleModel"]
                    op["VehicleSubModel"] = grid_conf_data[i]["VehicleSubModel"]
                    op["Date"] = grid_conf_data[i]["Date"]
                    op["Person"] = grid_conf_data[i]["Person"]
                    try:
                        list_keys = grid_conf_data[i].keys()
                        op_key = [each for each in list_keys if "description" in each.lower()]
                        op["Description"] = grid_conf_data[i][op_key[0]]
                    except:
                        op["Description"] = ""
                    grids_conf.append(op)
                BottleLog.logger.info('retrieved volume grid data from master_plan collection')
                #return jsonify({data:gridsconf_avbl})
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result":{grid_type:grids_conf},
                                 "Description":desc_out["UIDescription"], "Code":db.code})
        else:
            response.status = 200
            #return jsonify({"error":db.db_error})
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT276" })

'''
Deprecated old code
        
@app.route('/ecfd/<dbName>/<collection>/ImportVolgrid', method=['OPTIONS','POST','GET'])
def import_volgrid(dbName,collection):
    """Imports the grid data into master collection based on input data.
       Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
       URL Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/master/ ImportVolgrid
       Input Example:
            data=volgrid.import.extract.json file
    """
    #fh = open('DB_Jsons/volgrid.import.extract.json')
    #masterData = json.load(fh)
    #fh.close()
    data = request.json
    #The following line is used for unit test
    #masterData = data['data'] #json.loads(data)
    BottleLog.logger.debug(data)
    #masterData = json.loads(data)
    masterData = data
    db = eCFDdb()
    db.connect(dbName)
    try:
        if masterData['import'][0]['import'][0]['import']['EntityType'] == "VolumeGrid":
            BottleLog.logger.info('Trying to Import the Volumegrid')
            importvol = ImportVolGrid(masterData)
            data = importvol.importvolgrid()
            BottleLog.logger.debug(data)
            if data == 1:
                BottleLog.logger.info('The volumegrid already exists')
                return jsonify({"success":"The volumegrid which you are trying to import already Exists"})
            if data!=False:
                result = db.get_grids(collection,"volumegrid")
                BottleLog.logger.info(result)
                BottleLog.logger.debug(result)
                for i in range(len(result)):
                    if 'volumegriddata' in result[i]:
                        result = result[i]
                volgrids = result['volumegriddata']
                volgrid_data = []
                for i in range(len(volgrids)):
                    volgrids[i] = json.dumps(volgrids[i])
                    volgrids[i] = json.loads(volgrids[i])
                    volgrid_data.append(volgrids[i])
                updatedb = db.update_volgrids(collection,data,volgrid_data)
                BottleLog.logger.info('Successfully Imported the Volumegrids')
                return updatedb
            else:
                BottleLog.logger.error('Failed to Import the Volumegrid')
                return jsonify({"success":"Failed to Import Volume Grid"})
            
        elif masterData['import'][0]['import'][0]['import']['EntityType'] == "SurfaceGrid":
            BottleLog.logger.info('Trying to Import the SurfaceGrid')
            importsurf = ImportSurfGrid(masterData)
            data = importsurf.importsurfgrid()
            if data == 1:
                BottleLog.logger.info('The surface grid already exists')
                return jsonify({"success":"The Surface Grid which you are trying to import already Exists"})
            if data!=False:
                result = db.get_grids(collection,"surfacegrid")
                for i in range(len(result)):
                    if 'surfacegriddata' in result[i]:
                        result = result[i]
                surfdetails = result['surfacegriddata']
                surface_data = []
                for i in range(len(surfdetails)):
                    surfdetails[i] = json.dumps(surfdetails[i])
                    surfdetails[i] = json.loads(surfdetails[i])
                    surface_data.append(surfdetails[i])
                updatedb = db.update_surfacegrids(collection,data,surface_data)
                BottleLog.logger.info('Successfully Imported the Surface Grid')
                return updatedb
            else:
                BottleLog.logger.error('Failed to Import the Surface Grid')
                return jsonify({"success":"Failed to Import Surface Grid"})

        elif masterData['import'][0]['import'][0]['import']['EntityType'] == "Configuration":
            BottleLog.logger.info('Trying to Import the Configuration')
            importconf = ImportConfiguration(masterData)
            data = importconf.importconfig()
            if data == 1:
                BottleLog.logger.info('The Configuration already exists')
                return jsonify({"success":"The Configuration which you are trying to import already Exists"})
            if data!=False:
                result = db.get_grids(collection,"configuration")
                for i in range(len(result)):
                    if 'configdetails' in result[i]:
                        result = result[i]
                confdetails = result['configdetails']
                config_data = []
                for i in range(len(confdetails)):
                    confdetails[i] = json.dumps(confdetails[i])
                    confdetails[i] = json.loads(confdetails[i])
                    config_data.append(confdetails[i])
                updatedb = db.update_conf_details(collection,data,config_data)
                BottleLog.logger.info('Successfully Imported the Configuration')
                return updatedb
            else:
                BottleLog.logger.error('Failed to Import the Configuration')
                return jsonify({"success":"Failed to Import Configuration"})
        else:
            BottleLog.logger.error('Failed to Import as Entity type is not matching')
            return jsonify({"success":"Failed to Import as Entity type is not matching"})
            
    except:
        BottleLog.logger.error('Failed to Import the data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
        return jsonify({"success":"Failed to Import data"})
        
@app.route('/ecfd/<dbName>/<collection>/Getgrids',method=['OPTIONS','POST','GET'])
def get_grids(dbName,collection):
    """Returns the values of name,URL,Description,ReynoldsNumber,VehicleModel,VehicleSubModel,Date,Person 
    of the respective grids based on the name of the grid.If the respective URL value is present in deleted
    objects block it will not pass the respective all the above values of that grid in the output.
       Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
       URL Example:
            http://10.138.41.56:58181/ecfd_repo_test_cg/ecfd/ecfddbcg/master/ Getgrids
       Input Example:
            data={"entity" :"volumegrid"}  
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        #data={"entity":"configuration"}
        data=request.json
        data= data["entity"]
        data=data.lower()
        db.get_grids(collection,data)
        deleted_obj = db.get_deleted_objects(collection)
        volgrids_avbl = []
        if db.db_error == None:
            if db.db_output==None:
                    BottleLog.logger.error('No data')
                    return jsonify({"error":"No data retrieved!"})
            else:
                result = db.db_output
                for i in range(len(result)):
                    result = result[i]
                if data =="volumegrid" or data == "surfacegrid":
                    volgrid_data = result[data+"data"]
                    #volgrid_data = result['volumegriddata']
                    volgrids = []
                    for i in range(len(volgrid_data)):
                        op={}
                        op["Name"]=volgrid_data[i]["Name"]
                        op["URL"]=volgrid_data[i]["URL"]
                        op["Description"]=volgrid_data[i]["Description"]
                        op["ReynoldsNumber"]=volgrid_data[i]["ReynoldsNumber"]
                        op["VehicleModel"]=volgrid_data[i]["VehicleModel"]
                        op["VehicleSubModel"]=volgrid_data[i]["VehicleSubModel"]
                        op["Date"]=volgrid_data[i]["Date"]
                        op["Person"]=volgrid_data[i]["Person"]
                        volgrids.append(op)
                    for i in range(len(deleted_obj)):
                        if 'deletedObjects' in deleted_obj[i]:
                            deleted_obj = deleted_obj[i]
                    if len(deleted_obj) == 1:
                        return jsonify({data :volgrids})
                    else:
                        deleted_objs = deleted_obj['deletedObjects']
                        deleted_objs = json.dumps(deleted_objs)
                        for i in range(len(volgrids)):
                            if volgrids[i]["URL"] in deleted_objs:
                                pass
                            else:
                                volgrids_avbl.append(volgrids[i])
                                
                elif data =="configuration":
                    output=[]   
                    grids = result["configdetails"]
                    for each in grids:
                            op={}
                            op["scale"]=each["scale"]
                            op["configname"]=each["configname"]
                            op["configpath"]=each["configpath"]
                            op["description"]=each["description"]
                            try:
                                op["Person"]=each["Person"]
                            except:
                                op["Person"] = ""    
                            output.append(op)
                    for i in range(len(deleted_obj)):
                        if 'deletedObjects' in deleted_obj[i]:
                            deleted_obj = deleted_obj[i]
                    if len(deleted_obj) == 1:
                        return jsonify({data :output})
                    else:
                        deleted_objs = deleted_obj['deletedObjects']
                        deleted_objs = json.dumps(deleted_objs)
                        for i in range(len(output)):
                            if output[i]["configpath"] in deleted_objs:
                                pass
                            else:
                                volgrids_avbl.append(output[i])                  
                BottleLog.logger.info('retrieved volume grid data from master collection')
                return jsonify({data:volgrids_avbl})
        else:
            response.status = 400
            return jsonify({"error":db.db_error})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 400
        return jsonify({"error" :traceback.format_exc().splitlines()[-1]})

'''
@app.route('/ecfd/<dbName>/<collection>/DeleteObject', method=['OPTIONS','POST','GET'])
def delete_object(dbName,collection):
    """Marks the respective grid as softdelete by adding the url of that grid in deletedObjects block based 
    on the inputs in master collection.
       Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
       URL Example:
            http://10.138.41.56:58181/ecfd_repo_test_cg/ecfd/ecfddbcg/master/ DeleteObject
       Input Example:
            data=:{"url" : ["/acct/jeb9140/eCFD/prototype/777wb_0015_1/SurfaceGrid"],"obj" :"surfacegrid"}   
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        #url = ["/acct/jeb9140/eCFD/prototype/777wb_0015_1/SurfaceGrid"]
        #obj = "surfacegrid"
        data = request.json
        BottleLog.logger.info("Requested input for delete_object service is %s" %(data))
        url = data['url']
        obj = data['obj']
        result = db.delete_obj(collection,url,obj)
        #return result
        if db.db_error == None:
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Success", "Result": json.loads(result), "Description":desc_out["UIDescription"], "Code":db.code})
        else:
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT277" })  
    
    
@app.route('/ecfd/<dbName>/<collection>/DeleteId', method=['OPTIONS','POST'])
def delete_id(dbName,collection):
    """Removes the respective json document based on the ObjecId provided from the particular collection.
       Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
       URL Example:
            http://10.138.41.56:58181/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/ DeleteId
       Input Example:
            data={'transaction_id':"547d96a68058590037c639bf"}   
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for delete_id service is %s" %(data))
        trans_id = data['transaction_id']
        db.remove_collection(collection, trans_id)
        if db.db_error == None:
            response.status = 200
            #return jsonify({"success" :"id %s has been deleted from %s collection"%(trans_id, collection)})
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Success", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code})
        else:
            response.status = 200
            #return jsonify({"error":db.db_error})
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code})            
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT278" }) 
    
@app.route('/ecfd/<dbName>/<collection>/GetVolgrid')
def get_volgrids(dbName,collection):
    """Returns the available volume grid,exculding the deletedObjects from the master collection.
       Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
       URL Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/master/GetVolgrid
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        result = db.get_volgrids(collection)
        if db.db_error == None:
            if db.db_output==None:
                BottleLog.logger.error('No data')
                #return jsonify({"error":"No data retrieved!"})
                desc_out=db.error_lookup("Utility","PYT226")
                return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT226" })
            
            else:    
                volgrids_avbl = []
                for i in range(len(result)):
                    if 'volumegriddata' in result[i]:
                        result = result[i]
                        volgrids = result['volumegriddata']
                        volgrids_avbl.append(volgrids)
                        
                        BottleLog.logger.info('retrieved volume grid data from %s collection'%(collection))
                        #return jsonify({"volumegriddata":volgrids_avbl})
                        desc_out=db.error_lookup("Utility",db.code)
                        return jsonify({"Message":"Success", "Result": {"volumegriddata":volgrids_avbl},
                                         "Description":desc_out["UIDescription"], "Code":db.code})
        else:
            response.status = 200
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code})        
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT279" })  
    
@app.route('/ecfd/<dbName>/<collection>/GetRefinedgrids', method=['OPTIONS','POST'])
def get_refined_grids(dbName,collection):
    """Returns the available volume grid,exculding the deletedObjects based on the filed provided from the 
    master collection.
       Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.
       URL Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/master/GetRefinedgrids
       Input Example:
           data={'entity':'volumegrid','URL':'777wb-VolumeGrids1.cgns','ReynoldsNumber':'40.E6'}
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        #data={'entity':'surfacegrid','process_name':"AeroDB","URL":"777-200ER-Wing-Body-Nacelle-Uns-SurfGrid123_test.cgns"}
        BottleLog.logger.info("Requested input for get_refined_grids service is %s" %(data))
        volgrids_avbl = []
        db.get_refined_grids(collection, data)
        if db.db_error == None:
            if db.db_output==None:
                BottleLog.logger.error('No data')
                #return jsonify({"error":"No data retrieved!"})
                desc_out=db.error_lookup("Utility","PYT226")
                return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT226" })
            else:
                volgrids = db.db_output
                #volgrids_avbl.append(volgrids)
                response.status = 200
                    #return jsonify({data["entity"]:volgrids_avbl})
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": {data["entity"]:volgrids}, 
                                    "Description":desc_out["UIDescription"], "Code":db.code})
                
        else:
            response.status = 200
            BottleLog.logger.error(db.db_error)
            #return jsonify({"error":db.db_error})
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT280" })

@app.route('/ecfd/<dbName>/<collection>/getprocessdata', method=['OPTIONS','POST'])
def get_process_data(dbName, collection):
    """Returns the values of planname,program,prosess,HPCHost and HPCUserId.And also returns the MetaData
    information like whether the plan has to be cloned,transferred or hidden  from transaction collection.
       Args:
         DbName:Name of the respective database in which the collection is located.
         collection:Name of the collection.
       URL Example:
         http:// 10.138.41.56/ecfd_repo_test_cg/ecfd/ecfdbcg/transaction/getprocessdata 
       Input Example:
        data={"processid":1234,"stepname":"GridConnectivity"}
     """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for get_process_data service is %s" %(data))
        db.getprocessdata(collection, data)
        if db.db_error==None:
            BottleLog.logger.info('getting process data from collection %s'%(collection))
            response.status = 200
            #return jsonify(db.db_output)
            desc_out=db.error_lookup("Utility",db.code)
            if db.db_output == []:
                descrp = "No analyze processes are yet created for this plan."
                return jsonify({"Message":"Success", "Result": db.db_output, "Description":descrp, "Code":db.code})
            else:
                return jsonify({"Message":"Success", "Result": db.db_output, "Description":desc_out["UIDescription"], "Code":db.code})
        else:
            response.status = 200
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility",db.code)
            #return jsonify({dbName :"getting process details failed!!", "error": db.db_error })
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT281" })
    
@app.route('/ecfd/launch', method=['OPTIONS','POST',"GET"])    
def launch():
    """Launches the respective step based on the transaction id,stepname and display variable, and returns the respective error 
    and output variables.    
    URL Example:
        http:// 10.138.41.56/ecfd_repo_test_cg/ecfd/launch
    Input Example:
        data={'transaction_id':'553900f236246c2bb0c26b5f','action':'GridConnectivity','display':'0'} 
    """
  
    try:
        db = eCFDdb()
        db.connect(config_data.DatabaseName)   
        data = request.json    
        BottleLog.logger.info("Requested input for launch service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {},"Description": 'No data received', "Code":"PYT227" })
        else:
            transaction_id = data['transaction_id']
            action = data['action']
            display=data['display']
            process_type=data["process_type"]            
            if "rgs_server" in data.keys():
                rgs_server=data["rgs_server"]
                pbs_jobid=data["pbs_jobid"]
                if "caseId" in data.keys():
                    caseId=data["caseId"]
                    if caseId != None and caseId != "" and caseId != "null":
                        caseId =int(caseId)
                    obj = Executor(transaction_id, action,process_type,display=display,caseId=caseId,rgs_server=rgs_server,pbs_jobid=pbs_jobid)
                else:
                    obj = Executor(transaction_id, action,process_type,display=display,rgs_server=rgs_server,pbs_jobid=pbs_jobid)
            else:
                if "caseId" in data.keys():
                    caseId=data["caseId"]
                    if caseId != None and caseId != "" and caseId != "null":
                        caseId =int(caseId)
                    obj = Executor(transaction_id, action,process_type,display=display,caseId=caseId)
                else:
                    obj = Executor(transaction_id, action,process_type,display=display)            
            obj.execute() 
            if obj.error == None:
                response.status = 202
                #return jsonify({"success":obj.output, "sync_type":obj.sync_async})
                desc_out=db.error_lookup("Utility",obj.code)
                return jsonify({"Message":"Success", "Result": {"success":obj.output, "sync_type":obj.sync_async}, "Description":desc_out["UIDescription"], "Code":obj.code })
            else:
                response.status = 200
                #return jsonify({"error":obj.error})
                BottleLog.logger.error(obj.error)
                if "rgs_server" in data.keys():
                    if obj.code == "PYT205":
                        error_message  = "Attempt to make ssh connection with the specified rgs server is failed."
                        return jsonify({"Message":"Error", "Result": {},"Description": error_message+str(obj.error), "Code":obj.code })
                    else:    
                        desc_out=db.error_lookup("Utility",obj.code)
                        return jsonify({"Message":"Error", "Result": {},"Description":desc_out, "Code":obj.code })
                else:
                    desc_out=db.error_lookup("Utility",obj.code)
                    return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":obj.code })
    except:     
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT282" })


@app.route('/ecfd/launchtest/<trans_id>/<action1>/<display>', method=['OPTIONS','POST','GET'])    
def launch_test(trans_id, action1,display):
        """Launches the respective step based on the transaction id,stepname and display variable, and returns the respective error 
        and output variables.
        Args:
            transaction_id:Object id of the document for which the step has to be launched.
            action:Respective name of the step that has to be launched.
            display:
        URL Example:
            http:// 10.138.41.56/ecfd_repo_test_cg/ecfd/launchtest/553900f236246c2bb0c26b5f/GridConnectivity/0 
        """ 
        db = eCFDdb()
        db.connect(config_data.DatabaseName) 
        transaction_id = trans_id
        action = action1
        display=display
        obj = Executor(transaction_id, action,display)
        obj.execute() 
        if obj.error == None:
            response.status = 202
            #return jsonify({"success":obj.output})
            desc_out=db.error_lookup("Utility",obj.code)
            return jsonify({"Message":"Success", "Result": obj.output, "Description":desc_out["UIDescription"], "Code":obj.code })
        else:
            response.status = 200
            #return jsonify({"error":obj.error})
            desc_out=db.error_lookup("Utility",obj.code)
            BottleLog.logger.error(obj.error)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":obj.code })
            
        
@app.route('/ecfd/<dbName>/<collection>/retrieve', method=['OPTIONS','POST','GET'])            
def retrieve(dbName, collection):
    """Retrieves the respective block values based on the inputs provided along with the transaction id and step name.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    URL Example:
        http:// 10.138.41.56/ecfd_repo_test_cg/ecfd/ecfdbcg/transaction/retrieve
    Input Example:
        data={"transaction_id":"55ae1a3ab1e2856e3ff1d721","action":"ViewBCAssignment","block":["Runs"],"latest":"True"}  
    """
    try:
        data = request.json 
        db = eCFDdb()
        db.connect(dbName)
        BottleLog.logger.info("Requested input for retrieve service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":"PYT227" })
        else:
            #data = {}
            #data['transaction_id'] = '545329db350ba1d86c42ca16'
            #data['action'] = 'GridConnectivity'
            #data['block'] = ['AppJson', 'AppJson_id']
            if data['action'] == "Analyze":
                db = eCFDdb()
                db.connect(dbName)
                query = {'_id': data['transaction_id']}
                projection = {'Process.PublishId':1}
                db.query_withproj(collection, query, projection)
                if db.db_error==None:
                    pub_id = db.db_output[0]['Process']['PublishId']
                    db.get(config_data.eCFD_Publish_Collection, pub_id)                               
                    if db.db_error==None:
                        res = json.loads(db.db_output)
                        tpl = Template("publish")
                        tpl.json_restore(res)
                        datablock = tpl.get_data_block("publish","publish")
                        tasklist = datablock.get_value("TaskList")
                        for i in range(len(tasklist)):
                            tasklist_entity=tasklist[i]['EntityType']['Value']
                            if tasklist_entity.lower() == 'solution':
                                data['action'] = tasklist[i]['Name']['Value']
                    else:
                        #return jsonify({"error":"error in getting data from publish"})
                        BottleLog.logger.error(db.db_error)
                        desc_out=db.error_lookup("Utility",db.code)
                        return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":db.code })
                else:        
                    #return jsonify({"error":"publish id not available for transaction"})
                    BottleLog.logger.error(db.db_error)
                    desc_out=db.error_lookup("Utility",db.code)
                    return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":db.code })
            if "caseId" in data.keys():
                if data["caseId"] != None and data["caseId"] != "" and data["caseId"] != "null":
                    data["caseId"] =int(data["caseId"])  
                if "condId" in data.keys() and data["condId"] != "": 
                    retrieve_obj = Retriever(data['transaction_id'], data['action'],data["process_type"], collection, conditionMatrixId= int(data["condId"]),caseId=data["caseId"])
                else:
                    retrieve_obj = Retriever(data['transaction_id'], data['action'],data["process_type"], collection,caseId=data["caseId"])
            else:
                if "condId" in data.keys() and data["condId"] != "": 
                    retrieve_obj = Retriever(data['transaction_id'], data['action'],data["process_type"], collection,conditionMatrixId= int(data["condId"]))
                else:
                    retrieve_obj = Retriever(data['transaction_id'], data['action'],data["process_type"], collection)
            if "pbsid" in data.keys():
                post_pbsid = data["pbsid"]
                if post_pbsid == "":
                    post_pbsid = None 
                if "latest" in data.keys():
                    post_latest = data["latest"]
                    if str(post_latest).lower() == "true":
                        retrieve_obj.retrieve_caller(data['block'], post_pbsid, latest=True)
                    else:
                        retrieve_obj.retrieve_caller(data['block'], post_pbsid)    
                else:        
                    retrieve_obj.retrieve_caller(data['block'], post_pbsid)
                
            elif "latest" in data.keys():
                if data['latest']=="True" or data['latest']=="true" or data['latest']=="TRUE" or data['latest']==True:
                    retrieve_obj.retrieve_caller(data['block'],latest=True)
                else:
                    retrieve_obj.retrieve_caller(data['block'],latest=False)
                
            else:
                retrieve_obj.retrieve_caller(data['block'])            
            if retrieve_obj.retriever_error==None:
                result = []
                for each in data['block']:
                    output_dict = {}
                    output_dict[each] = retrieve_obj.req_out_json[each]
                    result.append(output_dict)
                #return jsonify({"Result":result})
                desc_out=db.error_lookup("Utility",retrieve_obj.code)
                return jsonify({"Message":"Success", "Result":(result), "Description":desc_out['UIDescription'], "Code":retrieve_obj.code })    
            else:
                error = retrieve_obj.retriever_error
                BottleLog.logger.error(error)
                #return jsonify({"error":error})
                desc_out=db.error_lookup("Utility",retrieve_obj.code)
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":retrieve_obj.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT283" })       
                   
                   
@app.route('/ecfd/<dbName>/<collection>/successtest', method=['OPTIONS','POST'])
def success_test(dbName, collection):    
    return jsonify({'success' : 'request accepted'})    
                
@app.route('/ecfd/<dbName>/<collection>/errortest', method=['OPTIONS','POST'])
def error_test(dbName, collection):    
    return jsonify({'error' : 'error encountered'})

@app.route('/ecfd/<dbName>/<collection>/getstepnames', method=['OPTIONS','POST'])
def getstepnames(dbName, collection):
    """Returns the step details data like StepNumber,ScreenType,EntityType and UserActionRequired from publish collection
    using transaction id.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/getstepnames
    Input Example:
        data={"transaction_id":"553900f236246c2bb0c26b55"}
    """ 
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for getstepnames service is %s" %(data))
#         db.get_content_of_case(collection,data['transaction_id'],"Process","PublishId")
#         publish_id = db.db_output
        if "caseId" in data.keys():
            if data["caseId"] != None and data["caseId"] != "" and data["caseId"] != "null":
                data["caseId"] =int(data["caseId"])    
            retrieve_obj = Retriever(data['transaction_id'], None ,data["process_type"], collection,caseId=data["caseId"])
        else:
            retrieve_obj = Retriever(data['transaction_id'], None ,data["process_type"], collection)
        retrieve_obj.get_step_details()
        if retrieve_obj.retriever_error == None:
            response.status = 200
            #return jsonify(retrieve_obj.retriever_output)
            desc_out=db.error_lookup("Utility",retrieve_obj.code)
            return jsonify({"Message":"Success", "Result": (retrieve_obj.retriever_output), 
                            "Description":desc_out["UIDescription"], "Code":retrieve_obj.code })    
        else:
            response.status = 200
            BottleLog.logger.error(retrieve_obj.retriever_error)
            desc_out=db.error_lookup("Utility",retrieve_obj.code)
            #return jsonify({"error": retrieve_obj.retriever_error})
            return jsonify({"Message":"Error", "Result": {},"Description": desc_out["UIDescription"], "Code":retrieve_obj.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT284" })

@app.route('/ecfd/<dbName>/<collection>/getcontent', method=['OPTIONS','POST'])
def get_content_of_case(dbName, collection):
    """"Returns the specific content of the document in the respective collection based on the given arguments.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/getcontent
    Input Example:
        data={"_id":["545c9740e4b03a95b6a3d1fc", "545c8435dc16ed580e274738" ,"545c8e683cd332b29f202fab"],
              "query" : [ "Process.Name", "Process.PublishId","Process.id"]}    
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for get_content_of_case service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {},"Description": desc_out["UIDescription"], "Code":"PYT227" })
        else:
            output = []
            for j in range(len(data['_id'])):
                output_dict = {}
                for i in range(len(data['query'])):
                    vals = data['query'][i].split('.')
                    vals = tuple(vals)
                    db.get_content_of_case(collection,data['_id'][j],*vals)
                    if db.db_error==None:
                        response.status = 200
                        output_dict[data['query'][i]] = db.db_output
                    else:
                        db.db_error=None
                        output_dict[data['query'][i]] = ""
                output.append(output_dict)
            #return jsonify(output)
            desc_out=db.error_lookup("Utility","PYT100")
            return jsonify({"Message":"Success", "Result": (output), "Description":desc_out["UIDescription"], "Code":"PYT100"})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT285" })
        
@app.route('/ecfd/<dbName>/<collection>/getcontentblock', method=['OPTIONS','POST'])
def get_content_of_block(dbName, collection):
    """"Returns the specific content of the document in the respective collection based on the given arguments.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/getcontentblock
    Input Example:
        Input:{"_id":"55ed2736dc16ed0314078a47","block":["AnalyseProcess"],"fields":["Name","CurrentStep"],"condition":{}}
        Input:{"_id":"55ed2736dc16ed0314078a47","block":["ExecuteProcess"],"fields":["Name","CurrentStep"],"condition":{}}
        Input:{"_id":"55ed2736dc16ed0314078a47","block":["AnalyseProcess"],"fields":["Name","CurrentStep"],"condition":{"id":123}}
        Input:{"_id":"55ed2736dc16ed0314078a47","block":["ExecuteProcess","Steps"],"fields":["Name","Param"],"condition":{}}    
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for get_content_of_case service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {},"Description": desc_out["UIDescription"], "Code":"PYT227" })
        else:            
            db.get_content_of_block(collection,data)
            if db.db_error==None:
                response.status = 200
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": (db.db_output), "Description":desc_out["UIDescription"], "Code":"PYT100"})
                
            else:
                response.status = 200
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result": {},"Description": desc_out['UIDescription'],"Code":db.code })
            #return jsonify(output)

    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT286" })

@app.route('/ecfd/<dbName>/<collection>/querywithproj', method=['OPTIONS','POST'])
def query_with_proj(dbName, collection):
    """Queries in respective collection based on either ObjectId or query and returns the output as list.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/ querywithproj
    Input Example:
        data={"query" :{"Process.Steps.Name":"GridConnectivity","_id":""},'projection':'Process.Steps.$'}       
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for query_with_proj service is %s" %(data)) 
        #data = {}
        #data ['_id'] = "546098622714bc719de0d7ea"
        #data['query'] = ["Basic"]
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":"PYT227" })
        else:
            output = {}
            query = data['query']
            for i in range(len(data['projection'])):
                projection = {}
                projection[data['projection'][i]] = 1
                db.query_withproj(collection, query, projection)
                if db.db_error==None:
                    response.status = 200
                    output[data['projection'][i]] = db.db_output
                else:
                    response.status = 200
                    #return {"error":db.db_error}
                    BottleLog.logger.error(db.db_error)
                    desc_out=db.error_lookup("Utility",db.code)
                    return jsonify({"Message":"Error", "Result": {},"Description": desc_out['UIDescription'],"Code":db.code })
            #return jsonify(output)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Success", "Result": (output), "Description":desc_out['UIDescription'], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT287" })

@app.route("/ecfd/<dbName>/<collection>/<url:re:.+>/get/<caseId>")
def getcontent_detail_ofcase(dbName, collection, caseId, url):
    """"Returns the specific content of the document in the respective collection based on the Url.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
        caseId:ObjectId of the json document
        url:Path of the content
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/Process/Steps/0/Param/AppJson/
              get/545c8e683cd332b29f202fab
    """
    try:
        url_sp =  url.split('/')
        url_sp_tuple = tuple(url_sp)  
        db = eCFDdb()
        db.connect(dbName)
        db.get_content_of_case(collection, caseId, *url_sp_tuple)
        if db.db_error==None:
            response.status = 200
            #return jsonify(db.db_output)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Success", "Result": (db.db_output), 
                            "Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            desc_out=db.error_lookup("Utility",db.code)
            BottleLog.logger.error(db.db_error)
            #return {"error":db.db_error}
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"],"Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT288" })

@app.route('/ecfd/dodatamap', method=['OPTIONS','POST'])    
def do_data_map():
    """Performs the datamap functionality related to eCFD project.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/dodatamap
    Input Example:
        data={'transaction_id':"547d96a68058590037c639bf",'action':"GridConnectivity"}
    """
    try:
        data = request.json
        BottleLog.logger.info("Requested input for doDataMap service is %s" %(data)) 
        #data = {}
        #data['transaction_id'] = "547d96a68058590037c639bf"
        #data['action'] = "GridConnectivity"
        db = eCFDdb()
        db.connect(config_data.DatabaseName) 
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            transaction_id = data['transaction_id']
            action = data['action']
            requiredjson=data["requiredjson"]
            process_type=data["process_type"]
            if "caseId" in data.keys():
                if data["caseId"] != None and data["caseId"] != "" and data["caseId"] != "null":
                    data["caseId"] =int(data["caseId"])    
                obj = DataMapper(transaction_id, action,requiredjson,process_type,caseId=data["caseId"])
            else:
                obj = DataMapper(transaction_id, action,requiredjson,process_type)
            op = obj.perform_data_map()
            if op == "No DataMap available":
                response.status = 200
                desc_out=db.error_lookup("Utility","PYT102")
                return jsonify({"Message":"Success", "Result": {},"Description":desc_out["UIDescription"],"Code":"PYT102" })
            if obj.map_notfound == None:
                if obj.error == None: 
                    print ("Output===", obj.output)
                    response.status = 202
                    #return jsonify({"success":obj.output})
                    desc_out=db.error_lookup("Utility","PYT100")
                    return jsonify({"Message":"Success", "Result": obj.output, "Description":desc_out["UIDescription"], "Code":"PYT100" })
                else:    
                    print("Error===",obj.error)
                    response.status = 200
                    #return jsonify({"error":obj.error})
                    BottleLog.logger.error(obj.error)
                    desc_out=db.error_lookup("Utility","PYT235")
                    #error=str(desc_out["UIDescription"])+","+str(obj.error)
                    error=str(obj.error)
                    return jsonify({"Message":"Error", "Result": {},"Description":error ,"Code":"PYT235" })
            else:
                response.status = 200
                desc_out=db.error_lookup("Utility","PYT102")
                return jsonify({"Message":"Success", "Result": {},"Description":desc_out["UIDescription"],"Code":"PYT102" })                
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT289" })

@app.route("/ecfd/<dbName>/<collection>/searchPlan",method=['OPTIONS','POST'])
def search_plan(dbName,collection):
    """ Returns the values of program,planName,process,planId,transaction_id,Version and Current owner,And 
        also returns the MetaData information like whether the plan has to be cloned,transferred or hidden from transaction
        collection based on the inputs provided.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/searchPlan
    Input Example:
        data={"Program":None,"PlanName":None,"Tags":["test"],"Process":None,"CurrentOwner":None}    
    """
    try:
        data = request.json
        BottleLog.logger.info("Requested input for search_plan service is %s" %(data))
        #data = {}
        #data = {"program":"777X","planName":"","tags":["test"],"process":"","owner":""}
        db = eCFDdb()
        db.connect(dbName)
        db.search_plan(collection,data)
        if db.db_error==None:
            response.status = 200
            #return jsonify({"success":db.db_output})
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Success", "Result":(db.db_output),"Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            #return jsonify({"error":db.db_error})
            desc_out=db.error_lookup("Utility",db.code)
            BottleLog.logger.error(db.db_error)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"],"Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT290" })

@app.route('/ecfd/ComputeAtmoTable', method=['OPTIONS','POST'])
def compute_atmotable():
    """Generates and returns temperature,pressure,density,reynolds value based on the inputs given by user.  
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ ComputeAtmoTable
    Input Example:
        data={"transaction_id":"547d96a68058590037c639bf","altitude":"40000","mach":[0.86,0.84],"tblval":"BCA",
             "nmlfile":"polarday"}   
    """
    try:
        data = request.json
        db = eCFDdb()
        db.connect(config_data.DatabaseName)
        BottleLog.logger.info("Requested input for compute_atmotable service is %s" %(data))
        if request.method == 'POST':
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')\
                desc_out=db.error_lookup("Utility","PYT227")
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":"PYT227" })
            else:
                success_output = []
                failure_output = []
                transaction_id = data['transaction_id']
                for each_input in data["input"]:
                    altitude = each_input['Altitude']
                    mach = each_input['mach']
                    tblval = each_input['tblval']
                    #nmlfile = data['nmlfile']
                    RowId = each_input["RowId"]
                    compute = ComputeAtmoTable(transaction_id,altitude,mach,tblval)
                    if compute.compute().has_key("success"):
                        temp_output = compute.compute()
                        temp_output.update({"RowId":RowId})
                        success_output.append(temp_output)
                    else:
                        temp_output = compute.compute()
                        temp_output.update({"RowId":RowId})
                        failure_output.append(temp_output)
                #return compute.compute()                
                if success_output!=[] and failure_output == []:
                    response.status = 200 
                    desc_out=db.error_lookup("Utility",compute.code)
                    return jsonify({"Message":"Success", "Result": {"output":success_output},
                                 "Description":desc_out['UIDescription'], "Code":compute.code })
                elif success_output!=[] and failure_output != []:
                    response.status = 200
                    #desc_out=db.error_lookup("Utility",compute.code)
                    return jsonify({"Message":"Warning", "Result": {},
                                 "Description":"Some of the computations are failure", "Code":"PYT300"})
                elif success_output ==[] and failure_output != []:
                    response.status = 200
                    desc_out=db.error_lookup("Utility",compute.code)
                    return jsonify({"Message":"Error", "Result": {},
                                 "Description":desc_out['UIDescription'], "Code":compute.code })
                elif success_output ==[] and failure_output == []:
                    response.status = 200
                    #desc_out=db.error_lookup("Utility",compute.code)
                    return jsonify({"Message":"Success", "Result": {},
                                 "Description":"No results are computed.", "Code":"PYT100"})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT291" })

@app.route('/ecfd/launchxterm', method=['OPTIONS','POST'])
def launch_xterm():
    """Funtion to Launch Xterm.This will take the Bare xterm.json object from db.And pass that json to Runtask with
    a display variable which will launch XWindow.
    Example:
        http://ecfd-devtest.cs.boeing.com:58181/cg_python_dev/ecfd/launchxterm    
    """
    try:
        data = request.json
        db = eCFDdb()
        db.connect(config_data.DatabaseName)
        BottleLog.logger.info("Requested input for LaunchXterm service is %s" %(data))
        if request.method == 'POST':
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')
                desc_out=db.error_lookup("Utility","PYT227")
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":"PYT227" })
            else:
                username = data['username']
                rundir = data['rundir']
                display = data['display']
                hpcserver = data['hpcserver']
                bemsid = data['bemsid']
                BottleLog.logger.debug("username is %s rundir is %s display is %s hpc server %s bemsid %s"%(username, rundir, display, hpcserver, bemsid))
                launch = UtilityTools(username, bemsid, rundir, display, hpcserver)
                res = launch.LaunchXterm()
                response.status = 200    
                #return res
                if res.has_key("success"):
                    desc_out=db.error_lookup("Utility",launch.code)
                    return jsonify({"Message":"Success", "Result": res, "Description":desc_out['UIDescription'], "Code":launch.code })
                else:
                    desc_out=db.error_lookup("Utility",launch.code)
                    return jsonify({"Message":"Error", "Result": res, "Description":desc_out['UIDescription'], "Code":launch.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT292" })        

@app.route('/ecfd/launcheditor', method=['OPTIONS','POST'])
def launch_editor():
    """Funtion to Launch Editor.This will take the Bare editor.json object from db.And update the filename in 
    the editor.json And pass that json to Runtask with a display variable which will launch XWindow.
    Example:
        http://ecfd-devtest.cs.boeing.com:58181/cg_python_dev/ecfd/launcheditor    
    """
    try:
        data = request.json
        db = eCFDdb()
        db.connect(config_data.DatabaseName)
        BottleLog.logger.info("Requested input for LaunchEditor service is %s" %(data))
        if request.method == 'POST':
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')
                desc_out=db.error_lookup("Utility","PYT227")
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":"PYT227" })
            else:
                username = data['username']
                rundir = data['rundir']
                display = data['display']
                filename1 = data['filename1']
                path = data['path']
                cmd = data['cmd']
                hpcserver = data['hpcserver']
                bemsid = data['bemsid']
                launch = UtilityTools(username, bemsid, rundir, display, hpcserver, filename1, None, path, cmd)
                res = launch.LaunchEditor()
                response.status = 200    
                #return res
                if res.has_key("success"):
                    desc_out=db.error_lookup("Utility",launch.code)
                    return jsonify({"Message":"Success", "Result": res, "Description":desc_out['UIDescription'], "Code":launch.code })
                else:
                    desc_out=db.error_lookup("Utility",launch.code)
                    return jsonify({"Message":"Error", "Result": res, "Description":desc_out['UIDescription'], "Code":launch.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT293" })    

@app.route('/ecfd/launchxxdiff', method=['OPTIONS','POST'])
def launch_xdiff():
    """Funtion to Launch xxdiff.This will take the Bare xxdiff.json object from db.And update the filenames in the 
    xxdiff.json And pass that json to Runtask with a display variable which will launch XWindow.
    Example:
        http://ecfd-devtest.cs.boeing.com:58181/cg_python_dev/ecfd/launchxxdiff
    """
    try:
        data = request.json
        db = eCFDdb()
        db.connect(config_data.DatabaseName)
        BottleLog.logger.info("Requested input for LaunchXxdiff service is %s" %(data))
        if request.method == 'POST':
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')
                desc_out=db.error_lookup("Utility","PYT227")
                return jsonify({"Message":"Error", "Result": {},"Description": desc_out['UIDescription'], "Code":"PYT227" })
            else:
                username = data['username']
                rundir = data['rundir']
                display = data['display']
                filename1 = data['filename1']
                filename2 = data['filename2']
                hpcserver = data['hpcserver']
                bemsid = data['bemsid']
                launch = UtilityTools(username, bemsid, rundir, display, hpcserver, filename1, filename2)
                res =  launch.LaunchXxdiff()
                response.status = 200    
                #return res
                if res.has_key("success"):
                    desc_out=db.error_lookup("Utility",launch.code)
                    return jsonify({"Message":"Success", "Result": res, "Description":desc_out['UIDescription'], "Code":launch.code })
                else:
                    desc_out=db.error_lookup("Utility",launch.code)
                    return jsonify({"Message":"Error", "Result": res, "Description":desc_out['UIDescription'], "Code":launch.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT294" })      

@app.route("/ecfd/<dbName>/getcollections",method=['OPTIONS','GET'])
def get_collection_names(dbName):
    """Returns all the collection names of the respective database.
    Args:
        DbName:Name of the respective database in which the collection is located.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/getcollections
    """    
    try:
        db = eCFDdb()
        db.connect(dbName)
        db.get_collection_names()
        if db.db_error==None:
            BottleLog.logger.info('Collections in %s database'%(dbName))
            response.status = 200
            #return jsonify(db.db_output)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Success", "Result": (db.db_output), 
                            "Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility",db.code)
            #return jsonify({dbName :db.db_error})
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT295" })

@app.route('/ecfd/launchConvergance', method=['OPTIONS','POST'])
def launch_convergance():
    """Funtion to Launch Convergance.This will pass bareOverplot json to Runtask with a display variable which
    will launch XWindow based on inputs like transaction_id and display variable.
    Example:
        http://ecfd-devtest.cs.boeing.com:58181/cg_python_dev/ecfd/launchConvergance
    """
    try:
        data = request.json
        BottleLog.logger.info("Requested input for launch_convergance service is %s" %(data))
        db = eCFDdb()
        db.connect(config_data.DatabaseName)
        if request.method == 'POST':
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')
                desc_out=db.error_lookup("Utility","PYT227")
                return jsonify({"Message":"Error", "Result": {},"Description": desc_out["UIDescription"], "Code":"PYT227" })
            else:
                transaction_id = data['transaction_id']
                display = data['display']
                username = ""
                hpcserver = ""
                bemsid = ""
                rundir = ""
                db.get_content_of_case(config_data.eCFD_Transaction_Collection, transaction_id, "Basic")
                if db.db_error == None :
                    for each in db.db_output:
                        if each["Name"] == "HPCHost":
                            hpcserver = each["Value"][0]
                        elif each["Name"] == "HPCUserId":
                            username = each["Value"][0]
                        elif each["Name"] == "RunDir" :
                            rundir = each["Value"][0]
                db.get_content_of_case(config_data.eCFD_Transaction_Collection, transaction_id, "MetaData", "CurrentOwner")
                if db.db_error == None :
                    bemsid = db.db_output
                #Rundir should be taken from corresponding run and send it
                #rundir = data['rundir']
                BottleLog.logger.debug("transaction_id from ui %s"%(transaction_id))
                BottleLog.logger.debug("username is %s, hpc is %s, bemsid is %s"%(username, hpcserver, bemsid))
                launch = UtilityTools(username, bemsid, rundir, display, hpcserver)
                res = launch.LaunchConvergence()
                response.status = 200    
                BottleLog.logger.debug('result after convergence is : %s'%(res))
                #return res
                if res.has_key("success"):
                    desc_out=db.error_lookup("Utility",launch.code)
                    return jsonify({"Message":"Success", "Result": res, "Description":desc_out['UIDescription'], "Code":launch.code })
                else:
                    desc_out=db.error_lookup("Utility",launch.code)
                    return jsonify({"Message":"Error", "Result": res, "Description":desc_out['UIDescription'], "Code":launch.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT296" })

@app.route('/ecfd/sshauthentication', method=["POST","OPTIONS"])
def sshauthenticate():
    """Function to provide ssh authentication based on bemsid and username.
    Example:
        http://ecfd-devtest.cs.boeing.com:58181/cg_python_dev/ecfd/sshauthentication
    """
    try:
        if request.method == 'POST':
            data = request.json
            BottleLog.logger.info("Requested input for sshauthenticate service is %s" %(data))
            db = eCFDdb()
            db.connect(config_data.DatabaseName)
            BottleLog.logger.debug('calling ssh authentication with username - %s'%(data['username']))
            username = data['username']
            rundir = data['rundir']
            hpcname = data['hpcname']
            display = data['display']
            bemsid = data['bemsid']
            BottleLog.logger.debug('username is %s rundir is %s hpcname is %s display_var is %s'%(username, rundir, hpcname, display))
            query = {"Template.0":"xterm"}
            db.query_data(config_data.eCFD_Utility_Collection, query, 'single')
            req_json=json.loads(db.db_output)
            tpl = Template("xterm")
            tpl.json_restore(req_json)
            json_after_ser=tpl.json_serialize()
            auth = EcfdCaller(username, bemsid, json_after_ser, rundir, hpcname,None, display)
            print('authentication completed')
            BottleLog.logger.info('authentication completed')
            if auth.result=="TRUE":
                print('Authentication Successful!')
                BottleLog.logger.info('Authentication Successful!')
                #return jsonify({'success':'Connected to server!','response':''})
                desc_out=db.error_lookup("Utility","PYT100")
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":"PYT100" })
            else:
                print('Authentication Failed!')
                BottleLog.logger.error('Authentication Failed!')
                desc_out=db.error_lookup("Utility","PYT236")
                #return jsonify({"error": "%s with return code %s"%(auth.error,auth.code)})
                return jsonify({"Message":"Error", "Result": {}, 
                        "Description": desc_out["UIDescription"], "Code":"PYT236" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        #return jsonify({'error':'Got exception.Authentication Failed!'})        
        return jsonify({"Message":"Error", "Result": {},
                         "Description":"We are unable to process your request due to a system error. Please contact support.", 
                         "Code":"PYT297" })
    
@app.route('/ecfd/<dbName>/<collection>/generate_flight_condition', method=['OPTIONS','GET','POST'])
def generate_flight_condition(dbName, collection):
    """Generates the ConditionMatrix block based on the flow condition parameters in the transaction
    collection.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/generate_flight_condition
    Input Example:
        data={"transaction_id":"55ed2736dc16ed0314078a46","inputDict":{"Altitude":["1","2","3"],"Reynolds":["4"],"Mach":["5","6"]}}       
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for generate_flight_condition service is %s" %(data))
        transaction_id = data['transaction_id']
        inputDict=data["inputDict"]
        f = FlightConditionMatrix(inputDict)
        cond_matrix = f.generate()
        inputDict_keys=inputDict.keys()
        matrix_array=[]        
        for i in range(len(cond_matrix)):
            matrix_dict={}
            for j in range(len(inputDict_keys)):
                matrix_dict[inputDict_keys[j]] = cond_matrix [i] [j]
            matrix_dict["IsRunEnabled"]=True
            matrix_dict["ConditionMatrixId"]=int(i)
            matrix_array.append(matrix_dict)
        data_to_update = {}    
        data_to_update["_id"] = transaction_id
        data_to_update["updatedata"] = {"ConditionMatrix": matrix_array}    
        db.update_partdata(collection, data_to_update, upsert=False)
        BottleLog.logger.debug("%s:successfully calculated condition matrix is %s"%(data['transaction_id'],matrix_array))            
        desc_out=db.error_lookup("Utility",db.code)
        return jsonify({"Message":"Success", "Result": ({"ConditionMatrix":matrix_array}), 
                        "Description":desc_out["UIDescription"], "Code":db.code })       
                            
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT298" })

@app.route('/ecfd/<dbName>/<collection>/delete', method=['OPTIONS','POST','GET'])
def delete_process(dbName,collection):
    """Deletes the documents from the provided collection based on the ObjectIds provided and marks as softDelete 
    in the respective publish documents in publish collection based on the process_type.if process_type is blank("")
    it will only delete all the documents provided and it will not mark any softdelete.
       
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/delete
    Input Example:
        data={"transaction_id":["54990b306c92220e4d81e7d7","551b7d47299f731c10d3e0b4"],"process_type":"ExecuteProcess/AnalyseProcess/''"}    
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for delete_process service is %s" %(data))
        #data={'transaction_id':[]}
        if len(data['transaction_id'])>0:
            result = db.delete_process(collection, data)
            if result !={}:
                #return result             
                x=[i for i in result.values() if 'error' in i.lower()]
                if x!=[]:
                    if len(x) == len(result.values()):
                        desc_out=db.error_lookup("Utility","PYT203")
                        return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT203" })
                    else:
                        desc_out=db.error_lookup("Utility","PYT300")
                        return jsonify({"Message":"Warning", "Result": result, "Description":desc_out["UIDescription"], "Code":"PYT300" })
#                 for k,v in result.iteritems():
#                     print v
#                     if 'error' in v.lower():
#                         return jsonify({"Message":"Warning", "Result": result, "Description":"Success", "Code":"PYT300" })
                else:
                    desc_out=db.error_lookup("Utility","PYT100")
                    return jsonify({"Message":"Success", "Result": result, "Description":desc_out["UIDescription"], "Code":"PYT100" })
            else:
                response.status = 200
                desc_out=db.error_lookup("Utility","PYT226")
                #return jsonify({"error" :"Error in deletion"})
                return jsonify({"Message":"Error", "Result": {},"Description": desc_out["UIDescription"], "Code":"PYT226" })
        else:            
            response.status = 200
            desc_out=db.error_lookup("Utility","PYT227")
            #return jsonify({"error" :"Transaction id not found"})
            return jsonify({"Message":"Error", "Result": {},"Description": desc_out["UIDescription"], "Code":"PYT227" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description": "We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT299" })
    
    
@app.route('/ecfd/get_dictionary_keys', method=['OPTIONS','GET'])
def generate_dictionary():
    """Returns the userinput.json.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/get_dictionary_keys
    """
    try:
        f = open('DB_Jsons/userinput.json','r')
        data = json.load(f)
        #return jsonify(data)
        return jsonify({"Message":"Success", "Result": data, "Description":"Success", "Code":"PYT100" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":traceback.format_exc().splitlines()[-1], "Code":"PYT301" })
        
@app.route('/ecfd/<dbName>/<collection>/searchjson', method=['OPTIONS','POST','GET'])
def search_json(dbName, collection):  
    """Returns values of respective jsons,Created_by,Published_on based on the ProcessName,version and respective
    json names provided.Also it returns Publish_id if the respective json is publish Json from publish collection.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/searchjson
    Input Example:
        data={"process_name":"AeroDB","version":"Local2.1",'stepname':'GridConnectivity','desc':'','required_json':[]}    
    """  
    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested input for search_json service is %s" %(data))
        #data = {}
        #data ={"process_name":"AeroDB123","version":"","stepname":"","desc":'',"required_json":[]} 
        db.search_json(data)
        if db.db_error==None:
            response.status = 200
            #return jsonify({"success":db.db_output})
            desc_out=db.error_lookup("Utility","PYT100")
            return jsonify({"Message":"Success", "Result": db.db_output,
                             "Description":desc_out["UIDescription"], "Code":"PYT100" })
        else:
            response.status = 200
            #return jsonify({"error":db.db_error})
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility","PYT200")
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT200" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT302" })
    

@app.route('/ecfd/<dbName>/<collection>/clonepublish', method=['OPTIONS','POST','GET'])
def clone_publish(dbName, collection):
    """Clones the input publish json provided.It clones and stores all the associated jsons in the WorkInProgress
    collection and stores the publish json in publish collection.In case of any error it removes all the associated jsons in
    the WorkInProgress collection.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/publish/clonepublish
    Input Example:
        data={"publish_id":"55827d9ddc16ed0ca7e492a8"}     
    """    
    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested input for clone_publish service is %s" %(data))
        #data = {}
        #data ={"publish_id":"55827d9ddc16ed0ca7e492a8"}  
        db.clone_publish(data)
        if db.db_error==None:
            response.status = 200
            #return jsonify(db.db_output)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Success", "Result": (db.db_output), 
                            "Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            #return jsonify({"error":db.db_error})
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility",db.code)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT303" })

@app.route('/ecfd/<dbName>/<collection>/create_app_json', method=['OPTIONS','GET','POST'])
def create_app_json(dbName, collection):
    """Creates the AppJson Blocks in the transaction collection based on the number of ConditionMatrix blocks for
    solver steps.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/create_app_json
    Input Example:
        data={"transaction_id":"55ed2736dc16ed0314078a46"}  
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for create_app_json service is %s" %(data))
        count = 0
        err_step="" 
        mongoid_list=[]       
        transaction_id = data['transaction_id']
        db.get_content_of_case(collection, transaction_id, 'ConditionMatrix')
        if db.db_error==None:
            matrix_data = db.db_output
            retrieve_obj = Retriever(data['transaction_id'], None,'ExecuteProcess', collection)
            retrieve_obj.get_step_details()
            if retrieve_obj.retriever_error == None:
                step_data = retrieve_obj.retriever_output
                for i in range(len(step_data)):
                    if step_data[i]["EntityType"].lower() == "solution":
                        count = 1
                        step_name = step_data[i]["stepname"]
                        step_num = i
                        db.get_content_of_case(collection, transaction_id, 'ExecuteProcess', 'Steps', step_num, 'Param', 'AppJson')
                        if db.db_error==None:
                            app_json_data = db.db_output[0]
                            output_data = []
                            for j in range(len(matrix_data)):
                                obj = copy.deepcopy(app_json_data)
                                ref_mongo_id = app_json_data["MongoRefId"]
                                existing_id = app_json_data["id"]
                                obj["ConditionMatrixId"] = matrix_data[j]["ConditionMatrixId"]
                                if j>0 and output_data != []:
                                    db.get(collection,ref_mongo_id)
                                    if db.db_error == None:
                                            if db.db_output != "" and db.db_output != None and db.db_output != "null":
                                                data=json.loads(db.db_output)
                                                del data["_id"]                    
                                                db.store_data(collection,data)
                                                if db.db_error == None: 
                                                    new_mongo_id=jsonify(db.db_output).strip('"')
                                                    mongoid_list.append(new_mongo_id)
                                                else:
                                                    response.status = 200
                                                    BottleLog.logger.error("error in db - %s"%(db.db_error))
                                                    err_step=err_step+step_name
                                                    for a in range(len(mongoid_list)):
                                                        db.remove_collection(collection, mongoid_list[a])  
                                                    break
                                            else:
                                                err_step=err_step+step_name
                                                for a in range(len(mongoid_list)):
                                                    db.remove_collection(collection, mongoid_list[a])
                                                break                                                        

                                    else:
                                        response.status = 200                                            
                                        err_step=err_step+step_name                                            
                                        BottleLog.logger.error("error in db - %s"%(db.db_error))
                                        break

                                    obj["MongoRefId"] = new_mongo_id
                                    obj["id"] = existing_id + j
                                output_data.append(obj)

                                    
                            data = {}
                            data["_id"] = transaction_id
                            data["stepname"] = step_name
                            data["block"] = "AppJson"
                            if output_data != []:
                                data["status_details"] = output_data
                                db.update_partdata_onid(collection, data,'ExecuteProcess')
                                BottleLog.logger.info("%s:App Jsons created Successfully"%(data['_id']))
                                response.status = 200
                                #return jsonify({"success":"App Jsons created Successfully"})
                            else:
                                desc_out=db.error_lookup("Utility","PYT100")
                                BottleLog.logger.info("No runs available to create app jsons")
                                return jsonify({"Message":"Success", "Result": "No runs available to create app jsons", 
                                        "Description":desc_out["UIDescription"], "Code":"PYT100"})                                

                        else:
                            response.status = 200
                            desc_out=db.error_lookup("Utility","PYT243")
                            BottleLog.logger.error("error in db - %s"%(db.db_error))    
                            #return jsonify({"error" :db.db_error})
                            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT243" })  
                if db.db_error == None and err_step == "" : 
                    if count !=1:
                        response.status = 200
                        BottleLog.logger.info("%s:There is no solver step available for this plan"%(data['transaction_id']))
                        #return jsonify({"success" :"There is no solver step available for this plan"})
                        desc_out=db.error_lookup("Utility","PYT101")
                        return jsonify({"Message":"Success", "Result": {},
                                    "Description": desc_out["UIDescription"], "Code":"PYT101" })  
                    else:                        
                        desc_out=db.error_lookup("Utility",db.code)
                        return jsonify({"Message":"Success", "Result": "App Jsons created Successfully", 
                                "Description":desc_out["UIDescription"], "Code":db.code })
                else:
                    response.status = 200
                    desc_out=db.error_lookup("Utility","PYT252")
                    BottleLog.logger.error("error in db - %s"%(db.db_error))    
                    #return jsonify({"error" :db.db_error})
                    error=desc_out["UIDescription"]+"for"+err_step+"Step(s)"
                    return jsonify({"Message":"Error", "Result": {},"Description":error, "Code":"PYT252" })                         
            else:
                response.status = 200
                desc_out=db.error_lookup("Utility","PYT234")
                BottleLog.logger.error("error in db - %s"%(retrieve_obj.retriever_error))   
                #return jsonify({"error" :retrieve_obj.retriever_error})
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT234" })                        
        else:
            response.status = 200
            desc_out=db.error_lookup("Utility","PYT238")
            BottleLog.logger.error("error in db - %s"%(db.db_error)) 
            #return jsonify({dbName :"getting condition matrix failed!!", "error": db.db_error })
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT238" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT304" })

@app.route('/ecfd/<dbName>/<collection>/insertnotesdata', method=['OPTIONS','POST','GET'])
def insert_notedata(dbName, collection):
    """Updates the Notes block in MetaData section of transaction collection ,based on the input provided.
    It also genrates and updates id/NoteNumber in Notes block of transaction collection.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/insertnotesdata
    Input Example:
        data={"transaction_id":"553df51c36246c1fe96977ce",
            "data":{ "Author" : "test12345", "Note": "","NoteNumber" : "","TimeStamp" : "","Type":" ","id" : " "}}    
    """    
    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested input for insert_notedata service is %s" %(data))
        #data = {}
        #data ={"transaction_id":"553de17684586370edca64cf","data":{ "Author" : "test1234", "Note": "","NoteNumber" : "","TimeStamp" : "","Type":" ","id" : " "}}
        db.insert_notesdata(data)
        if db.db_error==None:
            response.status = 200
            desc_out=db.error_lookup("Utility",db.code)
            #return jsonify({'success' :"Note Inserted Successfully"})
            return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            #return jsonify({"error":db.db_error})
            desc_out=db.error_lookup("Utility",db.code)
            BottleLog.logger.error(db.db_error)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT305" })    
    
@app.route('/ecfd/<dbName>/<collection>/deletepartdata', method=['OPTIONS','POST','GET'])
def delete_partdata(dbName, collection):
    """Deletes the particular block from an array of blocks,based on any field of that particular block
    and the path of that block from respective collection.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/deletepartdata
    Input Example:
        data={"transaction_id":"553df51c36246c1fe96977ce",
            "segment":"MetaData.Notes","selectioncriteria":{"id":[1,2]}}
    """    
    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested input for delete_partdata service is %s" %(data))
        #data = {}
        #data ={"transaction_id":"553de17684586370edca64cf","segment":"MetaData.Notes","selectioncriteria":{"Author":["test12","test123","test"]}}
        db.delete_partdata(collection,data)
        if db.db_error==None:
            response.status = 200
            for k,v in db.db_output.iteritems():
                if "error" in v.lower():
                    desc_out=db.error_lookup("Utility","PYT300")
                    return jsonify({"Message":"Warning", "Result": db.db_output, "Description":desc_out["UIDescription"], "Code":"PYT300" })
            #return jsonify({"success" :db.db_output})
            desc_out=db.error_lookup("Utility","PYT100")
            return jsonify({"Message":"Success", "Result": db.db_output, "Description":desc_out["UIDescription"], "Code":"PYT100" })
        else:
            response.status = 200
            BottleLog.logger.error(db.db_error)
            #return jsonify({"error":db.db_error})
            desc_out=db.error_lookup("Utility","PYT203")
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT203" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT306" }) 
        
@app.route('/ecfd/<dbName>/<collection>/gettransdata', method=['OPTIONS','POST'])
def get_trans_data(dbName, collection):
    """Retrieves records from transaction collection between two timestamps.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/transaction/gettransdata
    Input Example:
        data={"start_time":"2015-05-13T12:38:03.540000","end_time":"2015-05-13T17:13:28.516000"}    
    """    
    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested input for get_trans_data service is %s" %(data))
        start_time = data["start_time"]
        end_time = data["end_time"]
        db.retrieve_records(collection, start_time, end_time)
        if db.db_error==None:
            response.status = 200
            print db.db_output
            desc_out=db.error_lookup("Utility",db.code)
            #return jsonify({'success' : 'data retrieved','data': db.db_output})
            return jsonify({"Message":"Success", "Result": db.db_output, "Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200
            #return jsonify({"error":db.db_error})
            desc_out=db.error_lookup("Utility",db.code)
            BottleLog.logger.error(db.db_error)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT307" })

@app.route('/ecfd/sendmail', method=['OPTIONS','POST','GET'])
def sendmail():
    try:
        data = request.json
        db = eCFDdb()
        db.connect(config_data.DatabaseName) 
        BottleLog.logger.info("Requested input for sendmail service is %s" %(data))
        BottleLog.logger.info("Data : %s"%data)
        #data = {"to":"riteshkumar.s@hcl.com","subject":"Ritesh Subject new","body":"message-body","cc":"pittu.n@hcl.com"}
        if config_data.CanSendEmail:            
            if data.has_key("cc"):
                process = Popen(['mail', '-s', data["subject"], data["to"],'-c', data["cc"]],stdin=PIPE,stdout=PIPE, stderr=STDOUT)
            else:
                process = Popen(['mail', '-s', data["subject"], data["to"]],stdin=PIPE,stdout=PIPE, stderr=STDOUT)            
            
            out, err = process.communicate(data["body"])
            if err == None:
                desc_out=db.error_lookup("Utility","PYT100")
                BottleLog.logger.info("SendEmail service out is : %s"%out)
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":"PYT100" })        
            else:
                desc_out=db.error_lookup("Utility","PYT251")                
                BottleLog.logger.info("SendEmail service err is : %s"%err)
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT251" })
        else:
            desc_out=db.error_lookup("Utility","PYT104") 
            BottleLog.logger.info("SendEmail service err is : Kindly Set CanSendEmail to true in ecfdconfig.py")
            return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":"PYT104" })

    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])        
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT308" })

@app.route('/ecfd/<dbName>/<collection>/persistProcessNestedJsons', method=['OPTIONS','GET','POST'])    
def persist_processnestedjsons(dbName, collection):
    """Function used to store the input datamap json in the publish json based on the inputs like process name,
    process version,process step and step name.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/publish/persistdatamap
    Input Example:
        data={"process_name":"AeroDB_Overflow_Process","process_version":"0.1","stepname":"GetVolumeGrid",
             "datamapjson": {"test":"mydatamap"},"field":"DataMapJSON","process_type":"ExecuteStep"} 
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested input for persist_datamap service is %s" %(data))
        datamap_json = data['datamapjson']
        process_name = data['process_name']
        process_version = data['process_version']
        stepname = data['stepname']
        field_to_update = data['field']
        #datamap_json = {"myjson":"forexample"}
        #stepname = "LaunchSetUp"
        
        db.store_data(config_data.eCFD_Publish_Collection, datamap_json)
        if db.db_error == None:
            datamap_mongo_id = db.db_output
            print(datamap_mongo_id) 
            query = {'$and': [{'Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Name.Value': process_name } , 
                          {'Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Version.Value': process_version },
                           {'Template.3.State':{ "$type": 10 }} ]
                }
            db.query_data(collection, query, 'single')
            if db.db_error==None:
                if db.db_output==None:
                    BottleLog.logger.error('No data')
                    desc_out=db.error_lookup("Utility","PYT226")
                    #return jsonify({"error":"No data retrieved!"})
                    return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT226" })
                else:
                    publish_id = json.loads(db.db_output)["_id"]
                    BottleLog.logger.debug('Getting data from collection - %s for query - %s'%(collection, query))
                    tpl=Template("publish")
                    tpl.json_restore(json.loads(db.db_output))
                    datablock=tpl.get_data_block("publish","publish")
                    BottleLog.logger.debug('Getting Process block using template class')
                    Process = datablock.get_value("Process")                    
                    BottleLog.logger.debug('Getting tasklist block based on %s Phase Name'%(data['process_type']))
                    #changes as per new publish json structure                     
                    for each in Process:
                        if each.has_key(data['process_type']):
                            tasklist=each[data['process_type']]["Value"][0]
                            if tasklist == []:
                                pattern_block = each[data['process_type']]["Value"][1]["Pattern"]
                                each[data['process_type']]["Value"][0] = [pattern_block]
                                tasklist=each[data['process_type']]["Value"][0]
                                
                            break
                        else:
                            continue        
                    
                    for i in range(len(tasklist)):
                        if data["process_type"] == "PlanStep":
                            tasklist[i]["ProcessStep"][field_to_update]['Value']=str(datamap_mongo_id)
                        else:
                            if str(tasklist[i]["ProcessStep"]['Name']['Value']) == stepname:                            
                                tasklist[i]["ProcessStep"][field_to_update]['Value']=str(datamap_mongo_id)
                                break
                        
                    datablock.set_value("Process",Process)
                    tpl.put_data_block("publish",datablock)    
                    updated_publish = tpl.json_serialize()
                    db.update_data(collection, {'_id':publish_id}, updated_publish) 
                    #return jsonify({"success": "Successfully persisted datamap"})
                    desc_out=db.error_lookup("Utility","PYT100")
                    return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":"PYT100" })
            else:
                response.status = 200
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility","PYT241")
                #return jsonify({"error":db.db_error})
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":"PYT241" })
        else:
            response.status = 200
            BottleLog.logger.error(db.db_error)
            desc_out=db.error_lookup("Utility","PYT245")
            #return jsonify({"error":db.db_error})
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code": "PYT245" })
        
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT309" })
    
@app.route('/ecfd/get_username/<bemsid>',method=['OPTIONS','GET','POST'])
def get_username(bemsid):
    """Returns the blues information for the respective bemsid provided.
    Args:
        bemsid:bemsid of the user        
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/get_username/2615858    
    """
    try:
        db = eCFDdb()
        db.connect(config_data.DatabaseName) 
        BottleLog.logger.info("Requested input for get_username service is %s" %(bemsid))
        p = subprocess.Popen(['/boeing/sw/ecfd/bin/blues', '-b', bemsid],
                             shell=False,
                             stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
        out, err = p.communicate()
        code = p.returncode
        if code == 0:
            bluesinfo = dict([tuple([x.strip() for x in line.split(":",1)])
                              for line in out.split("\n")
                              if ":" in line])
            outputjson = {}
            BottleLog.logger.info("Blues info is %s" %(bluesinfo))
            outputjson["NT_Username"] = bluesinfo["Preferred UID"]
            outputjson["Name"] = bluesinfo["Name"]
            if bluesinfo.has_key("StableAddress"):
                outputjson["Email Id"] = bluesinfo["StableAddress"]
                outputjson["StableMailId"] = "True"
            else:
                outputjson["Email Id"] = bluesinfo["External Email"]
                outputjson["StableMailId"] = "False"
            outputjson["Person Type"] = bluesinfo["PersonType"]
            if bluesinfo.has_key("U.S. Status"):
                outputjson["US Status"] = bluesinfo["U.S. Status"]
            #return jsonify(outputjson)
            desc_out=db.error_lookup("Utility","PYT100")            
            return jsonify({"Message":"Success", "Result": (outputjson), "Description":desc_out["UIDescription"], "Code":"PYT100" })
        else:
            #return jsonify({"error":"error in execution return code is %s, error is %s"%(code, err)})
            BottleLog.logger.error("error in execution return code is %s, error is %s"%(code, err))
            desc_out=db.error_lookup("Utility","PYT246")
            return jsonify({"Message":"Error", "Result": {}, "Description":desc_out["UIDescription"], "Code":"PYT246" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 400        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT310" })        
    
@app.route('/ecfd/<dbName>/<collection>/error_lookup', method=['OPTIONS','GET','POST'])
def error_lookup(dbName, collection):
    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested input for error_lookup service is %s" %(data))
        error_code = data["error_code"]
        output=db.error_lookup(collection, error_code)
        if output.has_key("error"):
            return jsonify({"Message":"Error", "Result": {},"Description":output["error"], "Code":"PYT200" })
        else:
            #return jsonify({"success":db.db_output}) 
            return jsonify({"Message":"Success", "Result": output, "Description":"Success", "Code":error_code })                        

    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":traceback.format_exc().splitlines()[-1], "Code":"PYT200" })    
        
@app.route('/ecfd/getenvconfig',method=['OPTIONS','GET'])
def getenvconfig():
    """Returns the config data in the json format.
    Url Example:
        http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/getenvconfig    
    """
    try:
        db = eCFDdb()
        db.connect(config_data.DatabaseName) 
        obj=EcfdConfig()       
        configdata=vars(obj)
        output=[]
        for name,value in configdata.iteritems():
            output.append({"Name":name,"Value":value})
        desc_out=db.error_lookup("Utility","PYT100")         
        return {"Message":"Success","Result":{"Python":{"ConfigDetails":output}},"Description":desc_out["UIDescription"], "Code":"PYT100"}    
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200        
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})  
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT311" }) 

@app.route('/ecfd/<dbName>/<collection>/UpdateUserPreference', method=['OPTIONS','POST'])
def update_user_pref(dbName, collection):
    """Updates the utility json based on the user bemsid and if bemsid is not there new record will be inserterd
    in the respective collection.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Url Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/utility/UpdateUserRole 
        Input Example:
            data={"bemsid":1234,"UserRole":"Lead Engineer"}        
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for UpdateUserPreference service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"No data received!", "Code":"PYT200" })
        else:
            BottleLog.logger.info('Updating data in collection - %s for %s'%(collection, data['bemsid']))                        
            db.update_user_preference(collection,data)
            desc_out=db.error_lookup("Utility","PYT100")               
            if db.db_error==None:
                response.status = 202
                BottleLog.logger.info('recieved data from db and updated it successfully')
                #return jsonify({'success' : 'request accepted'})
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code })
            else:
                response.status = 200
                BottleLog.logger.error(db.db_error)
                #return jsonify({"error":db.db_error})
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT312" })
        
@app.route('/ecfd/<dbName>/<collection>/PushObjects', method=['OPTIONS','POST'])
def push_object_to_document(dbName, collection):
    """Push objects to document based on the _id and block provided in the respective collection.
        Args:
            DbName:Name of the respective database in which the collection is located.
            collection:Name of the collection.            
        Url Example:
            http://10.138.41.56/ecfd_repo_test_cg/ecfd/ecfddbcg/transaction/PushObjects 
        Input Example:            
            data={"_id":"55ed2736dc16ed0314078a47","block":"AnalyseProcess","pushdata":{"Name":"ritesh","Mob":9811967975}}
    """
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for push_object_to_document service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            BottleLog.logger.info('pushing data in collection - %s for id %s'%(collection, data['_id']))
            db.push_object_to_document(collection, data) 
            if db.db_error==None:
                response.status = 202
                BottleLog.logger.info('recieved data from db and updated it successfully')
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code })
                #return jsonify({'success' : 'request accepted'})
            else:
                response.status = 200                
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT313" }) 

@app.route('/ecfd/<dbName>/<collection>/updatejsons', method=['OPTIONS','POST'])
def update_jsons(dbName, collection):
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for update_jsons service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            BottleLog.logger.info('updating jsons in collection - %s for id %s'%(collection, data["transaction_id"]))
            db.update_jsons(collection, data) 
            if db.db_error != None: 
                response.status = 200
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code })

            else:
                response.status = 200
                desc_out=db.error_lookup("Utility","PYT100")
                #return jsonify({"error" :"Error in deletion"})
                return jsonify({"Message":"Success", "Result": {},"Description": desc_out["UIDescription"], "Code":"PYT100" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT314" })
        
@app.route('/ecfd/<dbName>/<collection>/deleteprocessblocks', method=['OPTIONS','POST'])
def delete_processblocks(dbName, collection):
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for deleteprocessblocks service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else:
            BottleLog.logger.info('updating jsons in collection - %s for id %s'%(collection, data["transaction_id"]))
            launch = Launcher(data["transaction_id"],None,None,None,None)
            launch.delete_processblocks(data)
            if launch.launcher_error != None: 
                response.status = 200
                desc_out=db.error_lookup("Utility",launch.code)
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":launch.code })

            else:
                response.status = 200
                desc_out=db.error_lookup("Utility","PYT100")
                #return jsonify({"error" :"Error in deletion"})
                return jsonify({"Message":"Success", "Result": {},"Description": desc_out["UIDescription"], "Code":"PYT100" })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT315" })  
        

@app.route('/ecfd/<dbName>/<collection>/abortPlan', method=['OPTIONS','POST'])
def abortPlan(dbName, collection):
    try:
        db = eCFDdb()
        db.connect(dbName)
        data = request.json
        BottleLog.logger.info("Requested input for abortPlan service is %s" %(data))
        if not data:
            BottleLog.logger.error('No data')
            #abort(400, 'No data received')
            desc_out=db.error_lookup("Utility","PYT227")
            return jsonify({"Message":"Error", "Result": {}, 
                        "Description":desc_out["UIDescription"], "Code":"PYT227" })
        else: 
            output_dict={}
            failure_caseid = ""
            success_caseid = ""
            partial_caseid = ""
            aborted_caseid = ""
            completed_caseid =""
            output_dict["AbortResponse"] =[]
            if data.has_key("plansList"):
                for each_plandata in data["plansList"]:
                    abort = Abort_Plans(each_plandata["transactionid"],each_plandata["stepname"],process_type=data["process_type"],caseId=int(each_plandata["caseid"]))  
                    abort.abort_plans()
                    if abort.abort_output.has_key("Success") and not abort.abort_output.has_key("Failure"):
                        if not abort.abort_output.has_key("AlreadyCompleted") :
                            if success_caseid == "":
                                success_caseid = success_caseid +str(each_plandata["caseid"])+"(Aborted jobs with job ids :"+ str(abort.abort_output["Success"]) +")"
                            else:                                                
                                success_caseid = success_caseid +"," +str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"]) +")"
                            output_plandata = output_dict["AbortResponse"]
                            output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                                "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Aborted"}])
                        else:
                            if partial_caseid == "":
                                partial_caseid = partial_caseid +str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"]) \
                                + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                
                            else:
                                partial_caseid = partial_caseid +","+ str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"] )\
                                + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                                            
                            output_plandata = output_dict["AbortResponse"]
                            output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                                "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Aborted"}])
                        
                    elif abort.abort_output.has_key("Success") and abort.abort_output.has_key("Failure"):
                        if not abort.abort_output.has_key("AlreadyCompleted") :
                            if partial_caseid == "":
                                partial_caseid = partial_caseid +str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) \
                                +",Aborted jobs with job ids :"+ str(abort.abort_output["Success"]) +")"
                            else:
                                partial_caseid = partial_caseid +","+ str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"] )\
                                +",Aborted jobs with job ids :"+ str(abort.abort_output["Success"]) +")"                     
                            output_plandata = output_dict["AbortResponse"]
                            output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                                "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Failed to Abort"}])  
                        else:
                            if partial_caseid == "":
                                partial_caseid = partial_caseid +str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"]) \
                                +",failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"])\
                                + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                
                            else:
                                partial_caseid = partial_caseid +","+ str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"] ) \
                                +",failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) \
                                + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                                            
                            output_plandata = output_dict["AbortResponse"]
                            output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                                "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Failed to Abort"}])
                            
                        
                    elif abort.abort_output.has_key("Failure") and not abort.abort_output.has_key("Success") :
                        if not abort.abort_output.has_key("AlreadyCompleted") :
                            if failure_caseid == "":
                                failure_caseid = failure_caseid + str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) +")"
                            else:
                                failure_caseid = failure_caseid+"," + str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) +")"
                            output_plandata = output_dict["AbortResponse"]
                            output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                            "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Failed to Abort"}])  
                        else:
                            if partial_caseid == "":
                                partial_caseid = partial_caseid +str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) \
                                + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                
                            else:
                                partial_caseid = partial_caseid +","+ str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"] )\
                                + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                                            
                            output_plandata = output_dict["AbortResponse"]
                            output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                                "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Failed to Abort"}])

                            
                        
                    elif abort.abort_output.has_key("AlreadyAborted"):
                        if aborted_caseid == "":
                            aborted_caseid = aborted_caseid +str(each_plandata["caseid"])
                        else:                                                
                            aborted_caseid = aborted_caseid +"," +str(each_plandata["caseid"])
                        output_plandata = output_dict["AbortResponse"]
                        output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                            "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Aborted"}])
                        
                    elif abort.abort_output.has_key("AlreadyCompleted"):
                        if completed_caseid == "":
                            completed_caseid = completed_caseid +str(each_plandata["caseid"])+"(Because jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"have been completed in hpc.)"
                        else:                                                
                            completed_caseid = completed_caseid +"," +str(each_plandata["caseid"])+"(Because jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"have been completed in hpc.)"
                        output_plandata = output_dict["AbortResponse"]
                        output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                            "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Completed"}])                                                
                               

            elif data.has_key("pbsidsList"):
                each_plandata = data["pbsidsList"]
                abort = Abort_Plans(each_plandata["transactionid"],each_plandata["stepname"],process_type=data["process_type"],caseId=int(each_plandata["caseid"]))
                abort.abort_plans(each_plandata["pbsids"])
                if abort.abort_output.has_key("Success") and not abort.abort_output.has_key("Failure"):
                    if not abort.abort_output.has_key("AlreadyCompleted") :
                        if success_caseid == "":
                            success_caseid = success_caseid +str(each_plandata["caseid"])+"(Aborted jobs with job ids :"+ str(abort.abort_output["Success"]) +")"
                        else:                                                
                            success_caseid = success_caseid +"," +str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"]) +")"
                        output_plandata = output_dict["AbortResponse"]
                        output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                            "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Aborted"}])
                    else:
                        if partial_caseid == "":
                            partial_caseid = partial_caseid +str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"]) \
                            + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                            
                        else:
                            partial_caseid = partial_caseid +","+ str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"] ) \
                            + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                                        
                        output_plandata = output_dict["AbortResponse"]
                        output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                            "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Aborted"}])
                    
                elif abort.abort_output.has_key("Success") and abort.abort_output.has_key("Failure"):
                    if not abort.abort_output.has_key("AlreadyCompleted") :
                        if partial_caseid == "":
                            partial_caseid = partial_caseid +str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) \
                            +",Aborted jobs with job ids :"+ str(abort.abort_output["Success"]) +")"
                        else:
                            partial_caseid = partial_caseid +","+ str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"] ) \
                            +",Aborted jobs with job ids :"+ str(abort.abort_output["Success"]) +")"                     
                        output_plandata = output_dict["AbortResponse"]
                        output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                            "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Failed to Abort"}])  
                    else:
                        if partial_caseid == "":
                            partial_caseid = partial_caseid +str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"])\
                            +",failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) \
                            + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                            
                        else:
                            partial_caseid = partial_caseid +","+ str(each_plandata["caseid"])+"(Aborted jobs with job ids:"+ str(abort.abort_output["Success"] )\
                            +",failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) \
                            + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                                        
                        output_plandata = output_dict["AbortResponse"]
                        output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                            "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Failed to Abort"}])
                        
                    
                elif abort.abort_output.has_key("Failure") and not abort.abort_output.has_key("Success") :
                    if not abort.abort_output.has_key("AlreadyCompleted") :
                        if failure_caseid == "":
                            failure_caseid = failure_caseid + str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) +")"
                        else:
                            failure_caseid = failure_caseid+"," + str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"]) +")"
                        output_plandata = output_dict["AbortResponse"]
                        output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                        "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Failed to Abort"}])  
                    else:
                        if partial_caseid == "":
                            partial_caseid = partial_caseid +str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"])\
                            + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                            
                        else:
                            partial_caseid = partial_caseid +","+ str(each_plandata["caseid"])+"(failed to abort these jobs with jobids:"+ str(abort.abort_output["Failure"] )\
                            + ",Couldn't abort the jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"because job(s) is completed in hpc.)"
                                                        
                        output_plandata = output_dict["AbortResponse"]
                        output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                            "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Failed to Abort"}])

                        
                    
                elif abort.abort_output.has_key("AlreadyAborted"):
                    if aborted_caseid == "":
                        aborted_caseid = aborted_caseid +str(each_plandata["caseid"])
                    else:                                                
                        aborted_caseid = aborted_caseid +"," +str(each_plandata["caseid"])
                    output_plandata = output_dict["AbortResponse"]
                    output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                        "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Aborted"}])
                    
                elif abort.abort_output.has_key("AlreadyCompleted"):
                    if completed_caseid == "":
                        completed_caseid = completed_caseid +str(each_plandata["caseid"])+"(Because jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"have been completed in hpc.)"
                    else:                                                
                        completed_caseid = completed_caseid +"," +str(each_plandata["caseid"])+"(Because jobs with jobid(s): "+ str(abort.abort_output["AlreadyCompleted"]) +"have been completed in hpc.)"
                    output_plandata = output_dict["AbortResponse"]
                    output_plandata.append([{"transactionid":each_plandata["transactionid"],"stepname":each_plandata["stepname"],\
                                        "process_type":data["process_type"],"caseid":each_plandata["caseid"],"stepstatus":"Completed"}]) 
                                      
            response.status = 200
            if success_caseid != "" and failure_caseid != "" and partial_caseid != "":
                descrp = "Succesfully aborted jobs for the following plans:" + success_caseid+".Failed to abort jobs for the following plans:"+failure_caseid+"."+\
                        "Abort was partially successful for these plan:" + partial_caseid +"." 
                if aborted_caseid != "":
                    descrp = descrp +"Already aborted the following plans:" + aborted_caseid + "."
                if completed_caseid != "":
                    descrp = descrp +"The following plans are completed already in hpc:" + completed_caseid + "."               
                return jsonify({"Message":"Warning", "Result": output_dict ,"Description":descrp, "Code":"PYT300" })
            
            elif success_caseid != "" and failure_caseid != "" and partial_caseid == "":
                descrp = "Succesfully aborted jobs for the following plans:" + success_caseid+".Failed to abort jobs for the following plans:"+failure_caseid+"."   
                if aborted_caseid != "":
                    descrp = descrp +"Already aborted the following plans:" + aborted_caseid + "."   
                if completed_caseid != "":
                    descrp = descrp +"The following plans are completed already in hpc:" + completed_caseid + "."              
                return jsonify({"Message":"Warning", "Result": output_dict ,"Description":descrp, "Code":"PYT300" })   
            
            elif success_caseid != "" and failure_caseid == "" and partial_caseid != "":
                descrp = "Succesfully aborted jobs for the following plans:" + success_caseid+".Abort was partially successful for these plan:"+partial_caseid+"."  
                if aborted_caseid != "":
                    descrp = descrp +"Already aborted the following plans:" + aborted_caseid + "."      
                if completed_caseid != "":
                    descrp = descrp +"The following plans are completed already in hpc:" + completed_caseid + "."                              
                return jsonify({"Message":"Warning", "Result": output_dict ,"Description":descrp, "Code":"PYT300" })  
            
            elif success_caseid == "" and failure_caseid != "" and partial_caseid != "":
                descrp = "Failed to abort jobs for the following plans:" + failure_caseid+".Abort was partially successful for these plan:"+partial_caseid+"."  
                if aborted_caseid != "":
                    descrp = descrp +"Already aborted the following plans:" + aborted_caseid + "."     
                if completed_caseid != "":
                    descrp = descrp +"The following plans are completed already in hpc:" + completed_caseid + "."           
                return jsonify({"Message":"Error", "Result": output_dict ,"Description":descrp, "Code":"PYT320" })        
                                            
            elif success_caseid == "" and failure_caseid != "" and partial_caseid == "":
                descrp = "Failed to abort jobs for the following plans:" + failure_caseid+"."           
                if aborted_caseid != "":
                    descrp = descrp +"Already aborted the following plans:" + aborted_caseid + "."    
                if completed_caseid != "":
                    descrp = descrp +"The following plans are completed already in hpc:" + completed_caseid + "."   
                return jsonify({"Message":"Error", "Result": output_dict ,"Description":descrp, "Code":"PYT320" }) 
            
            elif success_caseid == "" and failure_caseid == "" and partial_caseid != "":
                descrp = "Abort was partially successful for these plan:" + partial_caseid+"."    
                if aborted_caseid != "":
                    descrp = descrp +"Already aborted the following plans:" + aborted_caseid + "."        
                if completed_caseid != "":
                    descrp = descrp +"The following plans are completed already in hpc:" + completed_caseid + "."      
                return jsonify({"Message":"Error", "Result": output_dict ,"Description":descrp, "Code":"PYT320" }) 
            
            elif success_caseid != "" and failure_caseid == "" and partial_caseid == "":
                descrp = "Succesfully aborted jobs for the following plans:" + success_caseid+"."
                if aborted_caseid != "":
                    descrp = descrp +"Already aborted the following plans:" + aborted_caseid + "."
                if completed_caseid != "":
                    descrp = descrp +"The following plans are completed already in hpc:" + completed_caseid + "."  
                return jsonify({"Message":"Success", "Result": output_dict ,"Description":descrp, "Code":"PYT100" })
            
            elif success_caseid == "" and failure_caseid == "" and partial_caseid == "" and aborted_caseid != "":
                descrp = "Already aborted the following plans:" + aborted_caseid + "."
                if completed_caseid != "":
                    descrp = descrp +"The following plans are completed already in hpc:" + completed_caseid + "."  
                return jsonify({"Message":"Warning", "Result": output_dict ,"Description":descrp, "Code":"PYT300" })
    
            elif success_caseid == "" and failure_caseid == "" and partial_caseid == "" and aborted_caseid == "" and completed_caseid != "":
                descrp = "The following plans are completed already in hpc:" + completed_caseid + "."
                return jsonify({"Message":"Warning", "Result": output_dict ,"Description":descrp, "Code":"PYT300" })

    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT321" })  

@app.route('/ecfd/<dbName>/<collection>/searchauditdata', method=['OPTIONS','POST'])
def searchAuditdata(dbName,collection):
    """track data in ecfd application by using user,datatime,eventtype.
    It could simply be used to determine which user effected the change to the application/process state to be able to trouble shoot problems
    Args:
        dbName:Name of the respective database in which the collection is located
        collection:Name of the collection
        
    Url example:http:// 10.138.41.56/ecfd_repo_test_cg /ecfd/ecfddbcg/AuditLog/searchauditdata

    input example:{ "start_time":"","end_time":"","user":"","eventtype":""}

    """

    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested data for get_audit_data service is %s" %(data))
        start_time = data["start_time"] if data.has_key('start_time') else None
        end_time = data["end_time"] if data.has_key('end_time') else None
        user =data["user"] if data.has_key('user') else None
        eventtype = data["eventtype"] if data.has_key('eventtype') else None
        db.search_auditdata(collection, start_time, end_time, user, eventtype)
        
        if db.db_error==None:
            response.status = 200
            if json.loads(db.db_output) == []:
                descrp = "Couldn't find audit data based on your search criteria."
                return jsonify({"Message":"Success", "Result": {}, "Description":descrp, "Code":db.code})
            else:
                desc_out=db.error_lookup("Utility",db.code)            
                return jsonify({"Message":"Success", "Result":json.loads(db.db_output), "Description":desc_out["UIDescription"], "Code":db.code })
        else:
            response.status = 200            
            desc_out=db.error_lookup("Utility",db.code)
            BottleLog.logger.error(db.db_error)
            return jsonify({"Message":"Error", "Result": {},"Description":desc_out["UIDescription"], "Code":db.code })

    except:        
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                         "Code":"PYT322" })
        
@app.route('/ecfd/launch_dynamic_tool', method=['GET', 'OPTIONS','POST'])
def launch_dynamic_tool():
    """Funtion to Launch dynamic tool.This will take the Bare dynamictool.json object from db.And update the dynamic keys in the
    dynamictool.json And pass that json to Runtask with a display variable which will launch XWindow.
    Example:
        http://ecfd-devtest.cs.boeing.com:58181/cg_python_dev/ecfd/launch_dynamic_tool
    """
    try:
        data = request.json
        db = eCFDdb()
        db.connect(config_data.DatabaseName)
        BottleLog.logger.info("Requested input for Launch Dynamic tool service is %s" %(data))
        if request.method == 'POST':
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')
                desc_out=db.error_lookup("Utility","PYT227")
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":"PYT227" })
            else:
                username = data['username']
                rundir = data['rundir'] 
			    #display variable is not be mandatory for all tools, so if one is not passed set it to None, UserExecute.py will
				#handle None value for display variable. 
                display = data['display'] if data.has_key('display') else "None"
                hpcserver = data['hpcserver']
                bemsid = data['bemsid']
                service_name = data['service_name']
                path = data['path']
                cmd = data['cmd']
                dynamic_fields = data['dynamic'] if data.has_key('dynamic') else []
                launch = UtilityTools(username, bemsid, rundir, display, hpcserver, path, cmd, service_name ,dynamic_fields)
                launch.LaunchDynamicTool()
                response.status = 200
                if launch.output != None:
                    descrptn = "Tool successfully invoked.Response from tool - " + str(launch.output)
                    return jsonify({"Message":"Success", "Result": {}, "Description": descrptn, "Code":launch.code })
                else:
                    desc_out=db.error_lookup("Utility",launch.code)
                    descrptn = desc_out["UIDescription"] + " " + str(launch.error)
                    return jsonify({"Message":"Error", "Result": {}, "Description": descrptn, "Code":launch.code })
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                        "Code":"PYT293" })
        
@app.route('/ecfd/<dbName>/<collection>/deleteProcessNestedJsons', method=['OPTIONS','GET','POST'])
def deleteProcessNestedJsons(dbName, collection):
    
    """Function used to delete the datamap json in the publish json based on the inputs like process name,
    process version,process step and step name.
    Args:
        DbName:Name of the respective database in which the collection is located.
        collection:Name of the collection.
    Url Example:
        URL: http://10.138.41.56:58181/ecfd_repo_test_cg/ecfd/ecfddbcg/pulish/deleteProcessNestedJsons
    Input Example:
        Input  Example: {"process_name":"AeroDB_Overflow_Process","process_version":"0.1","stepname":"GetVolumeGrid",field":"DataMapJSON","process_step":"ExecuteStep/AnalyseStep"}
        Note:In case of deleting the plan json input will be: {"process_name":"AeroDB_Overflow_Process","process_version":"0.1","field":"PlanJson","process_step":"PlanStep"}"""
    try:
        db = eCFDdb()
        db.connect(dbName)
        data=request.json
        BottleLog.logger.info("Requested input for deleteProcessNestedJsons service is %s" %(data))
        
        process_name = data['process_name']
        process_version = data['process_version']
        if data.has_key("stepname"):
            stepname = data['stepname']
        else:
            stepname =""
        field_to_delete = data['field']
        process_step = data['process_step']
        #datamap_json = {"myjson":"forexample"}
        #stepname = "LaunchSetUp"
        db.deleteProcessNestedJsons(collection,process_name,process_version,stepname,field_to_delete,process_step )
        if db.db_error==None:
                response.status = 200                
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Success", "Result": {}, "Description":desc_out["UIDescription"], "Code":db.code })
                #return jsonify({'success' : 'request accepted'})
        else:
                response.status = 200
                #return jsonify({"error":db.db_error})
                BottleLog.logger.error(db.db_error)
                desc_out=db.error_lookup("Utility",db.code)
                return jsonify({"Message":"Error", "Result":{}, "Description":desc_out["UIDescription"], "Code":db.code})
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        #return jsonify({"error" :traceback.format_exc().splitlines()[-1]})        
        return jsonify({"Message":"Error", "Result": {}, 
                        "Description":"We are unable to process your request due to a system error. Please contact support.", 
                        "Code":"PYT324" })
@app.route('/ecfd/invokeExternalservice', method=['GET', 'OPTIONS','POST'])
def invoke_externalservice():

    try:
        data = request.json
        db = eCFDdb()
        db.connect(config_data.DatabaseName)
        BottleLog.logger.info("Requested input for invokeExternalservice service is %s" %(data))
        if request.method == 'POST':
            if not data:
                BottleLog.logger.error('No data')
                #abort(400, 'No data received')
                desc_out=db.error_lookup("Utility","PYT227")
                return jsonify({"Message":"Error", "Result": {},"Description":desc_out['UIDescription'], "Code":"PYT227" })
            else:
                tr_id=data["transaction_id"]
                service_name = data["service_name"]
                dynamic_fields = data["input_params"]
                path = dynamic_fields["Path"]
                cmd = dynamic_fields["Command"]
                del dynamic_fields["Path"]
                del dynamic_fields["Command"]
                output_params = data["output_params"]
                db.get_basic_parameters(tr_id)
                if db.db_error == None:
                    username = db.db_output['username']
                    rundir = db.db_output['rundir']                     
                    hpcserver = db.db_output['hpcserver']
                    bemsid = db.db_output['bemsid']
                                   
                    obj = UtilityTools(username, bemsid, rundir, None, hpcserver, path, cmd, service_name ,dynamic_fields,output_params)
                    res = obj.launch_external_service()
                    response.status = 200                                           
                    if res.output != None:
                        desc_out=db.error_lookup("Utility",obj.code)                        
                        return jsonify({"Message":"Success", "Result": res.output , "Description":desc_out['UIDescription'], "Code":obj.code })
                    else:
                        #desc_out=db.error_lookup("Utility",launch.code)
                        return jsonify({"Message":"Error", "Result": {}, "Description": str(res.error), "Code":obj.code })
                    
                else:
                    response.status = 200 
                    desc_out=db.error_lookup("Utility",db.code)                       
                    return jsonify({"Message":"Error", "Result": {},
                                 "Description":desc_out['UIDescription'], "Code": db.code})                              
 
    except:
        BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        response.status = 200
        return jsonify({"Message":"Error", "Result": {},
                        "Description":"We are unable to process your request due to a system error. Please contact support.",
                        "Code":"PYT325" })    
if __name__=='__main__':
    #run(app, host='localhost', port=58180, reloader=True)
    run(app, host='localhost', port=58180)
    #run(app, host='10.117.217.107', port=58180)
    #run(app, server='cherrypy', host='localhost', port=3737, debug=True)
