#!/boeing/sw/ecfd/bin/python2.7

""""DatabaseWrapper is the wrapper for eCFD to MongoDB. This wrapper is used to connect to the Mongo database and perform the 
CRUD operations on the collection.This wrapper can also be used to initialize the Master Doc to the database, store , search 
and get the analytics results.
"""


__author__ = "Sreevatsa Beleyur Devappa"
__copyright__ = ""
__credits__ = ["Sreevatsa Beleyur Devappa , Venkata Harish Nagamangalam,Ritesh Kumar Srivastava, Neeharika Pittu"]
__license__ = ""
__version__ = "1.0"
__maintainer__ = "Sreevatsa Beleyur Devappa"
__email__ = "sreevatsa.b@hcl.com"
__status__ = "Code Generator"
__lastupdatedon__= "08/11/2014" #dd/mm/yyyy

import json
from JsonHelper import jsonify
from bson import ObjectId
from pymongo import Connection
from copy import deepcopy
import os
from EcfdConfig import EcfdConfig
from BottleAppLogger import BottleAppLogger
import traceback
import re
import sys
import datetime
config_data = EcfdConfig()
template_script_path = config_data.templatescript_path
sys.path.append(template_script_path)
from template import Template
    
#from bson.objectid import ObjectId

#os.chdir(os.path.dirname(__file__))

#fh = open('DB_Jsons/Transaction.json')
#transactionDoc = json.load(fh)
#fh.close()

#fh = open('DB_Jsons/Master.json')
#masterDoc = json.load(fh)
#fh.close()

class eCFDdb:
    """This class has functions to access Database.It makes connections to the Mongo database and perform the CRUD operations 
    on the collection."""
    
    def __init__(self):
        """Initializer for eCFDdb class.It internally calls BottleAppLogger class."""
        self.config_data = EcfdConfig()
        self.BottleLog = BottleAppLogger('DatabaseWrapper')
        #self.BottleLog.logger.info('initializing Database wrapper')
        self.hostname = self.config_data.DatabaseHost
        self.port = self.config_data.DatabasePort
        self.max_pool_size= self.config_data.max_pool_size
        self.client = Connection(self.hostname, self.port, self.max_pool_size)
        self.db_error = None
        self.db_output = None
        self.code=None        
        #self.BottleLog.logger.info('initializing Database wrapper complete')

    def connect(self, database):
        """Connection to the MongoDb is made here.
        Args:
            database:Name of the database for which connection has to be made.        
        """        
        try:
            #self.BottleLog.logger.info('Connected to database - %s'%(database))
            self.db = self.client[database]
        except:
            self.BottleLog.logger.error('Failed to Connect to database - %s. Got error %s'%(database, traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
        return
            
    def cleanup_database(self, database):
        """This is used to empty/clean the database.
        Args:
            database:Name of the database for which cleanup has to be done.
        """
        #self.client.drop_database(database)
        try:
            self.BottleLog.logger.info('Dropping database - %s'%(database))
            self.client.drop_database(database)
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('Failed to Drop database - %s. Got error %s'%(database, traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT250"
        return
            
        
    def cleanup_collection(self, collection):
        """This is used to empty/clean the collection.
        Args:
            collection:Name of the collection for which cleanup has to be done.
        """
        #self.client.drop_database(database)
        try:
            self.BottleLog.logger.info('Dropping Collection - %s'%(collection))
            self.db.drop_collection(collection)
            self.code="PYT100"
        except:
            self.code="PYT249"
            self.BottleLog.logger.error('Failed to Drop Collection - %s. Got error %s'%(collection, traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
        return    
    
    def create_collection(self, collection):
        """This method store the data in the given collection.
        Args:
            collection:Name of the collection to be created.
        Returns:
            Returns the respective output or error messages.
        """
        try:
            collection_db = self.db[collection]
            self.BottleLog.logger.info('Creating '+collection+' Document')
            fh = open(os.path.join('./DB_Jsons',collection.capitalize()+".json"))
            Doc = json.load(fh)
            fh.close()
            self.db_output = collection_db.insert(Doc)
            self.code="PYT100"
        except:
            self.code="PYT248"
            self.BottleLog.logger.error('Failed to create '+collection+' document. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
        return
    
    def create_collection_new(self, collection, type, data):
        """This method store the data in the given collection.
        Args:
            collection:Name of the collection to be created.
            type:If 0 inserts the data from DBJsons folder based on collection name,
                 If 1 inserts the data provided as input.
            data:data to be inserted in case of if value of type is 1
        Returns:
            Returns the respective output or error messages.
        """
        try:
            collection_db = self.db[collection]
            self.BottleLog.logger.info('Creating '+collection+' Document')
            if int(type)==0:
                fh = open(os.path.join('./DB_Jsons',collection.capitalize()+".json"))
                doc = json.load(fh)
                fh.close()
            elif int(type)==1:
                doc = data
                #doc = json.dumps(data)
            else:
                self.code="PYT247"
                self.db_error = 'type provided in the url is not correct'
                return jsonify({'error':'type provided in the url is not correct'})
            self.code="PYT100"        
            self.db_output = collection_db.insert(doc)
        except:
            self.code="PYT248"
            self.BottleLog.logger.error('Failed to create '+collection+' document. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
        return
    
    def remove_collection(self, collection, id):
        """This method deletes the json document in the given collection.
        Args:
            collection:Name of the collection .
            id:ObjectId of the json document.
        Returns:
            Returns the respective output or error messages.        
        """
        try:
            collection_db = self.db[collection]
            self.BottleLog.logger.info('%s:Removing collection'%(id))
            collection_db.remove({'_id':ObjectId(id)})
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('%s:Failed to remove collection. Got error %s'%(id,traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT203"
        return
    
    def get(self, collection, mongoid):
        """This method returns the data from the collection based on the ObjectId.
        Args:
            collection:Name of the collection .
            id:ObjectId of the json document.
        Returns:
            Returns the respective output or error messages.        
        """
        try:
            if mongoid == None or mongoid == 'None' or mongoid == "":
                self.db_error = "MongoId is None"
                self.BottleLog.logger.debug('%s:Mongo ID is None and hence cannot retrieve - %s'%(mongoid,collection))
                return
            query = {}
            query['_id'] = ObjectId(mongoid)
            result = self.db[collection].find_one(query)
            self.BottleLog.logger.debug('%s:Retrieved data in the collection - %s'%(mongoid,collection))
            self.db_output =  jsonify(result)
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('%s:Failed to retrieve data. Got error %s'%(mongoid,traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return
    
    def get_datastore(self, collection):
        """This method returns the entire stored data from the collection.
        Args:
            collection:Name of the collection .
        Returns:
            Returns the respective output or error messages.
        """
        try:
            result = []
            for data in self.db[collection].find():
                result.append(data)
            self.BottleLog.logger.debug('Retrieved data in the collection - %s'%(collection))
            #json.loads(result) 
            self.db_output = jsonify(result)
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('Failed to retrieve data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return
    
    def get_ids(self, collection,data=None):
        """This method returns all the ObjectIds from the collection.
        Args:
            collection:Name of the collection .
        Returns:
            Returns the list of all the ObjectIds.        
        """
        try:
            self.BottleLog.logger.info('Retrieving the ids in the collection - %s'%(collection))
            if data:
                query={}
                l=[]
                for i in range(len(data["params"])): 
                    query[data["params"][i]]=1               
                output = self.db[collection].find({data["search_by"]:{"$exists":True}},query) 
                for each in output:
                    d={}
                    d.update({"_id":each["_id"]})
                    for i in range(len(data["params"])):
                        value = reduce(lambda d, key: d[int(key)] if type(key) == str and key.isdigit()  else d[key],\
                                                data["params"][i].split("."), each)
                        d[data["params"][i]] = value
                    l.append(d)
                self.db_output =  l                                  
                        
            else:
                result = self.db[collection].find({},{'_id':1})
                self.db_output =  list(result)
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('Failed to retrieve data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return
                
    def store_data(self, collection, data):
        """This method store the data in the given collection.
        Args:
            collection:Name of the collection .
            data:data to be inserted in the collection.
        Returns:
            Returns the ObjectId of the inserted json document .           
        """
        try:
            collection_name = collection
            collection = self.db[collection]
            self.BottleLog.logger.info('Storing Data in the collection - %s'%(collection))
            self.db_output = collection.insert(data)
            post_id = self.db_output
            tr_id = jsonify(self.db_output).strip('"')
            if "TemplateRevision" in data.keys():
                self.update_datetime(collection_name,tr_id,False)
            self.db_output = post_id
            self.BottleLog.logger.debug('post_id is = %s'%(self.db_output))
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('Failed to store data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT201"
        return
    
    def store_auditdata(self, collection, data):
        """This method store the data in the given collection.
        Args:
            collection:Name of the collection .
            data:data to be inserted in the collection.
        Returns:
            Returns the ObjectId of the inserted json document .           
        """
        try:            
            collection = self.db[collection]
            self.BottleLog.logger.info('Storing Data in the collection - %s'%(collection))
            self.db_output = collection.insert(data)
            time_strobject = data["AuditData"]["DateTime"]
            time_iso_object = datetime.datetime.strptime(time_strobject,"%Y-%m-%dT%H:%M:%S")
            collection.update({"_id":ObjectId(self.db_output)},{"$set":{"AuditData.DateTime":time_iso_object}})
            self.BottleLog.logger.debug('post_id is = %s'%(self.db_output))
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('Failed to store data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT201"
        return

        
    def update_partdata(self, collection, data, upsert=False):
        """This method updates the existing collection."""
        try:
            collection_name = collection
            collection = self.db[collection]
            self.BottleLog.logger.info('%s:Updating Data in the collection - %s'%(data['_id'],collection))
            tr_id = data['_id']
            if collection_name == self.config_data.eCFD_Transaction_Collection:
                result=None
                result=collection.find_one({"_id":ObjectId(tr_id)})                
                if result !=None:
                    if "TemplateRevision" in result.keys():
                        self.update_datetime(collection_name,tr_id)
#                 self.get_content_of_case(self.config_data.eCFD_Transaction_Collection, tr_id, "MetaData", "Type")
#                 if self.db_error == None:
#                     self.update_datetime(collection_name,tr_id)
#                 else:
#                     self.db_error = None 
            #self.db_output = collection.update({'_id': ObjectId(data['_id'])}, {'$set': data['updatedata']},upsert=upsert)
            self.db_output = collection.update({'_id': ObjectId(data['_id'])}, {'$set': data['updatedata']},upsert=upsert)
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('%s : Failed to update data. Got error %s'%(data['_id'],traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT202"
        return    
    
    def update_partdata_onid(self, collection, data,process_type,caseId=None,upsert=False):
        """This method updates particular blocks like AppJson,Runs,Status and Notes block in the transaction collection
        of database.
        Args:
            collection:Name of the collection.
            data:Combination of ObjectId and query which includes the block name(where to update),particular criteria
            (searches based on this and updates) and the data to be updated.
        Returns:
            Returns the respective output or error messages.
        """
        try:
            collection_name = collection
            collection = self.db[collection]
            if "stepname" in data.keys():
                self.BottleLog.logger.info('%s:Updating Data in the collection - %s'%(data['_id'],data))
                if "status_details" in data.keys():
                    if process_type == "ExecuteProcess":
                        if data["stepname"] != None:
                            self.db_output = collection.update({'$and': [{'_id': ObjectId(data['_id'])} , \
                                                         {'ExecuteProcess.Steps.Name': data['stepname']} ] },  
                                               {'$set': {'ExecuteProcess.Steps.$.Param.'+data['block']:data['status_details'] }}, upsert=upsert)
                        else:
                            self.db_output = collection.update({'_id': ObjectId(data['_id'])} , \
                                            {'$set': {'ExecuteProcess.'+data['block']:data['status_details'] }}, upsert=upsert)                            
                            
                    elif process_type == "AnalyseProcess":
                        self.query_withproj(collection_name,{'_id':ObjectId(data['_id']),'AnalyseProcess.id':caseId},{'AnalyseProcess.$':1})
                        analyse_block=self.db_output[0][process_type][0]
                        if data["stepname"] != None:
                            steps_block=self.db_output[0][process_type][0]["Steps"]
                            for i in range(len(steps_block)):
                                if steps_block[i]["Name"] == data["stepname"]:  
                                    block=["Param"]                                                                  
                                    path = data["block"].split(".")
                                    block.extend(path)                                    
                                    self.update_dictionary(steps_block[i], block, data['status_details'], pattern=False)                                    
                                    analyse_block["Steps"] = steps_block
                                    break
                        else:
                            analyse_block[data['block']] = data['status_details']
                        self.db_output = collection.update({'AnalyseProcess.id':caseId},{'$set': {'AnalyseProcess.$':analyse_block }})
                else:
                    if process_type == "ExecuteProcess":
                        self.db_output = collection.update({'$and': [{'_id': ObjectId(data['_id'])} , \
                                                         {'ExecuteProcess.Steps.Name': data['stepname']} ] },  
                                               {'$set': {'ExecuteProcess.Steps.$.Param.Status.ErrorCd':data['error_code'],'ExecuteProcess.Steps.$.Param.Status.ErrorDesc':data['error_desc']}}, upsert=upsert)
                    elif process_type == "AnalyseProcess":
                        self.query_withproj(collection_name,{'_id':ObjectId(data['_id']),'AnalyseProcess.id':caseId},{'AnalyseProcess.$':1})
                        analyse_block=self.db_output[0][process_type][0]
                        steps_block=self.db_output[0][process_type][0]["Steps"]
                        for i in range(len(steps_block)):
                            if steps_block[i]["Name"] == data["stepname"]:
                                steps_block[i]["Param"]["Status"]["ErrorCd"] = data['error_code']                               
                                steps_block[i]["Param"]["Status"]["ErrorDesc"] = data['error_desc']
                                break
                        self.db_output = collection.update({'AnalyseProcess.id':caseId},{'$set': {'AnalyseProcess.$':analyse_block }})
                        
            elif "NoteData" in data.keys():
                self.BottleLog.logger.info('%s:Updating Note Data in the collection - %s'%(data['_id'],collection))
                self.db_output = collection.update({'$and': [{'_id': ObjectId(data['_id'])} , \
                                                         {'MetaData.Notes.'+data['field']: data['fieldvalue']}]},  
                                               {'$set': {'MetaData.Notes.$':data['NoteData']}}, upsert=upsert)                    
            else:
                pass
                '''    
                self.BottleLog.logger.info('%s:Updating Data in the collection - %s'%(data['_id'],collection))
                self.db_output = collection.update({'$and': [{'_id': ObjectId(data['_id'])} , \
                                                         {'Process.Steps.Param.'+data['block']+'.id': data['id']} ] },  
                                               {'$set': {'Process.Steps.$.Param.'+data['block']+'.json':data['jsondata'] }}, upsert=upsert)'''
            tr_id = data['_id']
            self.code="PYT100"
            if collection_name == self.config_data.eCFD_Transaction_Collection:
                self.update_datetime(collection_name,tr_id)
        except:
            self.BottleLog.logger.error('%s : Failed to update data. Got error %s'%(data['_id'],traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT202"
        return   
                   
    def update_data(self, collection, query, data, upsert=False):
        """This method updates the existing collection."""
        try:
            collection_name = collection
            collection = self.db[collection]
            self.BottleLog.logger.info('%s:Updating Data in the collection - %s'%(query['_id'],collection))
            tr_id = query['_id']
            if tr_id == None or tr_id == 'None' or tr_id == "" or tr_id.lower() == "null":
                self.db_error = "MongoId is None"
                self.code="PYT252"
                self.BottleLog.logger.debug('%s:Mongo ID is None and hence cannot update - %s'%(tr_id,collection))
                return

            if collection_name == self.config_data.eCFD_Transaction_Collection:
                result=None
                result = collection.find_one({"_id":ObjectId(tr_id)})
                if result != None:
                    if "TemplateRevision" in result.keys():
                        self.update_datetime(collection_name,tr_id)
#                 self.get_content_of_case(self.config_data.eCFD_Transaction_Collection, tr_id, "TemplateRevision", "Type")
#                 if self.db_error == None:
#                     self.update_datetime(collection_name,tr_id)
#                 else:
#                     self.db_error = None 
            #post_id = collection.update({'_id': ObjectId(query['_id'])}, data, upsert=upsert)
            post_id = collection.update({'_id': ObjectId(query['_id'])}, data, upsert=upsert)
            self.BottleLog.logger.debug('post_id is = %s'%(post_id))
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('%s : Failed to update data. Got error %s'%(query['_id'],traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT202"
        return     
        
    def query_data(self, collection, query, single_multiple):
        """This method queries in respective collection based on either ObjectId or query and returns the output as list.
        Args:
            collection:Name of the collection.
            query:Combination of ObjectId and path of the field to be searched.
            single_multiple:if value single it searches for single query or if value is multiple it searches for
                            multiple queries.
        Returns:
            Returns the queried output as list.         
        """
        try:
            if query.has_key('_id'):
                query['_id'] = ObjectId(query['_id'])
            if query.has_key('transaction_id'):    
                query['transaction_id'] = ObjectId(query['transaction_id'])    
            if single_multiple=='single':                
                result = self.db[collection].find_one(query)
            else:    
                result = []
                for data in self.db[collection].find(query):
                    result.append(data)
            self.BottleLog.logger.debug('%s:Retrieving data for query in the collection - %s'%(query, collection))
            self.db_output = jsonify(result)
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('%s : Failed to query data. Got error %s'%(query,traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return
    
    def query_withproj(self, collection, query, projection):
        """This method queries in respective collection based on either ObjectId or query and returns the output as list.
        Args:
            collection:Name of the collection.
            query:ObjectId of the json document.
            projection:query of the field.
        Returns:
            Returns the queried output as list.
        """
        try:
            if query.has_key('_id'):
                query['_id'] = ObjectId(query['_id'])
            result = self.db[collection].find(query,projection)
            self.BottleLog.logger.debug('%s:Retrieving data for query in the collection - %s'%(query, collection))
            self.db_output = list(result)
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('%s : Failed to query data. Got error %s'%(query,traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return
    
    def get_volgrids(self,collection):
        """This method returns the entire volume grid data present in the master collection of database.
        Args:
            collection:Name of the collection.
        Returns:
            Returns the entire volume grid data as list.
        """
        try:
            self.BottleLog.logger.info('Getting volumegrid data from Master collection')
            result = self.db[collection].find({},{'volumegriddata':1})
            self.db_output =  list(result)
            self.code="PYT100"
            return self.db_output 
        except:
            self.BottleLog.logger.error('Failed to get volume grids. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return    
    
    def get_config_id(self, collectionName):
        """This method will return the Case ID for a new plan. And will create an empty Transaction document for that Case Id.
        Args:
            collectionName=Name of the collection.
        Returns:
            Returns the respective output or error message.
        """
        try:
            #self.BottleLog.logger.info('Generationg configuration Id for New configuration imported')
            collection = self.db[collectionName]
            configIdList = []
            #self.storeData(collectionName, transactionDoc)
            configdetList = collection.distinct('configdetails')
            #print configdetList[0]['configid']
            for i in range(len(configdetList)):
                configdetList[i] = json.dumps(configdetList[i])
                conf = json.loads(configdetList[i])
                configIdList.append(conf['configid'])
            configidList = sorted(configIdList, reverse=True)
            try:
                configId = configidList[0]
                configid = int(configId) + 1
            except:
                configid = 0
            self.code="PYT100"
            return configid
        except:
            self.BottleLog.logger.error('Failed to get Config Id. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.code="PYT200"
        return    
    
    def update_conf_details(self,collection,data,confdetails):
        try:
            post_id = self.db[collection].update({'configdetails':confdetails},{'$push':{'configdetails':data}})
            print (post_id)
            self.code="PYT102"
            return jsonify({'success' : 'File uploaded Successfully'})
        except:
            self.code="PYT202"
            self.BottleLog.logger.error('Failed to update Configuration details. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            return False  
    
    def get_deleted_objects(self,collection):
        """This method returns the data of deletedObjects which is present in master collection.
        Args:
            collection:Name of the collection.
        Returns:
            Returns the respective output as list.
        """
        try:
            self.BottleLog.logger.info('Getting deletedObjects list from Master collection')
            result = self.db[self.config_data.eCFD_Master_Collection].find({},{'deletedObjects':1})
            self.code="PYT100"
            return list(result)
        except:
            self.BottleLog.logger.error('Failed to get deleted Objects. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.code="PYT200"
            return False
    
            
    def get_grids(self,collection,data):
        """This method returns the respective grid data present in master collection,based on given input.
        Args:
            collection:Name of the collection.
            data:Name of the grid data to be searched.
        Returns:
            Returns the respective grid data as list.        
        """
        try:
            self.BottleLog.logger.info('Getting %s data from Master collection'%(data))
            result = None
            if data == "volumegrid":
                result = self.db[collection].find({},{"volumegriddata":1})
                self.db_output =  list(result)
                result = self.db_output
            elif data == "surfacegrid":
                result = self.db[collection].find({},{"surfacegriddata":1})
                self.db_output =  list(result)
                result = self.db_output
            elif data == "configuration":
                result = self.db[collection].find({},{"configurationdata":1})
                self.db_output =  list(result)
                result = self.db_output
            self.code="PYT100"
            return result
        except:
            self.BottleLog.logger.error('Failed to get grids. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return      
    
    def update_grid_or_conf(self, collection, entitytype, data, vol_surf_conf_data):
        """This method updates the volumegrid/surfacegrid/configuration data in master collection with the given data.
        Args:
            collection:Name of the collection.
            entitytype: volumegriddata/surfacegriddata/configurationdata
            data:data to be updated in the volumegriddata/surfacegriddata/configurationdata array.
            vol_surf_conf_data:Existing volgrids/surfgrids/config details data in collection.
        Returns:
            Returns the respective output or error messages.
        """
        try:
            #self.BottleLog.logger.info('Updating Volumegrid details to Master collection')
            #print("volgrids-----------",json.dumps(volgrids))
            #print("data-----------",data)
            self.db[collection].update({entitytype:vol_surf_conf_data},{'$push':{entitytype:data}})
            self.BottleLog.logger.debug("Updated the %s successfully"%(entitytype))
            self.code="PYT102"
            return jsonify({'success' : 'File uploaded Successfully'})
        except:
            self.BottleLog.logger.error('Failed to update '+entitytype+' details. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.code="PYT202"
            return False
        
        
    def update_volgrids(self,collection,data,volgrids):
        """This method updates the volume grid data in master collection with the given data.
        Args:
            collection:Name of the collection.
            data:data to be updated in the volumegriddata array.
            volgrids:Existing volgrids details data in collection.
        Returns:
            Returns the respective output or error messages.
        """
        try:
            #self.BottleLog.logger.info('Updating Volumegrid details to Master collection')
            #print("volgrids-----------",json.dumps(volgrids))
            #print("data-----------",data)
            self.db[collection].update({'volumegriddata':volgrids},{'$push':{'volumegriddata':data}})
            self.BottleLog.logger.debug("Updated the volumegriddata successfully")
            self.code="PYT102"
            return jsonify({'success' : 'File uploaded Successfully'})
        except:
            self.BottleLog.logger.error('Failed to update Volumegrid details. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.code="PYT202"
            return False
    
    def update_surfacegrids(self,collection,data,surface_data):
        """This method updates the surface grid data in master collection with the given data.
        Args:
            collection:Name of the collection.
            data:data to be updated in the surfacegriddata array.
            surface_data:Existing surfacegriddata details data in collection.
        Returns:
            Returns the respective output or error messages.
        """
        try:
            self.db[collection].update({'surfacegriddata':surface_data},{'$push':{'surfacegriddata':data}})
            self.BottleLog.logger.debug("Updated the surfacegriddata successfully")
            self.code="PYT102"
            return jsonify({'success' : 'File uploaded Successfully'})
        except:
            self.BottleLog.logger.error('Failed to update Surface Grid details. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.code="PYT202"
            return False
             
    def delete_obj(self,collection, url, obj):
        """This method deletes the respective block data ,based on the inputs like block name and url of the respective
        block ,and updates the respective deleted url in the deletedObjects block in master collection.
        Args:
            collection:Name of the collection.
            url:Url of the grid that has to be deleted.
            obj:Name of the grid data block..
        Returns:
            Returns the respective output or error messages.        
        """
        try:
            op=""
            for i in range(len(url)):
                if obj == "volumegrid":
                    #self.db[collection].update({'volumegriddata.URL':url[i]},{'$push':{'deletedObjects':url[i]}})
                    data = self.db[collection].find({},{"volumegriddata":1})
                    for j in data:                                                                        
                        for k in range(len(j["volumegriddata"])):
                            if j["volumegriddata"][k]["URL"]== url[i]:
                                op=op+'\''+(j["volumegriddata"][k]["Name"])+ '\''+','
                                self.db[collection].update({},{'$pull':{'volumegriddata':{'URL':url[i]}}})
                    
                                      
                elif obj == "surfacegrid":
                    #self.db[collection].update({'surfacegriddata.URL':url[i]},{'$push':{'deletedObjects':url[i]}})
                    data = self.db[collection].find({},{"surfacegriddata":1})
                    for j in data:
                        for k in range(len(j["surfacegriddata"])):
                            if j["surfacegriddata"][k]["URL"]== url[i]:
                                op=op+'\''+(j["surfacegriddata"][k]["Name"])+ '\''+','
                                self.db[collection].update({},{'$pull':{'surfacegriddata':{'URL':url[i]}}})
                     
                elif obj == "configuration":
                    #self.db[collection].update({'configurationdata.URL':url[i]},{'$push':{'deletedObjects':url[i]}})
                    data = self.db[collection].find({},{"configurationdata":1})
                    for j in data:
                        for k in range(len(j["configurationdata"])):
                            if j["configurationdata"][k]["URL"]== url[i]:
                                op=op+'\''+(j["configurationdata"][k]["Name"])+'\''+','
                                self.db[collection].update({},{'$pull':{'configurationdata':{'URL':url[i]}}})
            self.BottleLog.logger.debug("Object %s deleted Successfully"%(op[:-1]))
            self.code="PYT100"
            return jsonify({"success" :"Object %s deleted Successfully"%((op[:-1]))})
        except:
            self.db_error=traceback.format_exc().splitlines()[-3:]
            self.BottleLog.logger.error('Failed to delete Object. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.code="PYT203"
            return False    
    
    def import_deleted(self,collection,url,obj):
        """This method pulls the url from the deletedObjects block and removes the respective grid block to which the url
        belongs based on the inputs like block name and url of the respective block in master collection.
        Args:
            collection:Name of the collection.
            url:Url of the grid that has to be deleted imported from deletedObjects block.
            obj:Name of the grid data block..
        Returns:
            Returns the respective output or error messages.
        """
        try:
            self.BottleLog.logger.info('%s:Deleting the %s data from Master collection and removing the same from deletedObjects'%(url,obj))
            if obj == "volumegrid":
                self.db[collection].update({'volumegriddata.URL':url},{'$pull':{'deletedObjects':url}})
                self.db[collection].update({},{'$pull':{'volumegriddata':{'URL':url}}})
            elif obj == "surfacegrid":
                self.db[collection].update({'surfacegriddata.URL':url},{'$pull':{'deletedObjects':url}})
                self.db[collection].update({},{'$pull':{'surfacegriddata':{'URL':url}}})
            elif obj == "configuration":
                self.db[collection].update({'configurationdata.URL':url},{'$pull':{'deletedObjects':url}})
                self.db[collection].update({},{'$pull':{'configurationdata':{'URL':url}}})
            self.code="PYT100"
            return True
        except:
            print (traceback.format_exc().splitlines()[-3:])
            self.BottleLog.logger.error('Failed to delete Object. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.code="PYT204"
            return False
                    
    def get_refined_grids(self,collection,data):
        """This method returns the grid data from master collection,based on the inputs like grid name and any specific field 
        of the respective grid.
        Args:
            collection:Name of the collection.
            data:Includes the grid data name and particular field to search among the respective grids.
        Returns:
            Returns the respective grid data based on specific field .        
        """
        try:
            self.BottleLog.logger.info('Getting volumegrid data from Master collection')
            entity_type = data["entity"].lower()
            if entity_type == 'volumegrid':
                result = self.db[collection].find({},{'volumegriddata':1})
                res = list(result)
                for i in range(len(res)):
                    if 'volumegriddata' in res[i]:
                        result1 = res[i]
                volgrids_res = result1['volumegriddata']
            elif entity_type == 'surfacegrid':
                result = self.db[collection].find({},{'surfacegriddata':1})  
                res = list(result)
                for i in range(len(res)):
                    if 'surfacegriddata' in res[i]:
                        result1 = res[i]
                volgrids_res = result1['surfacegriddata']
            elif entity_type == "configuration":
                result = self.db[collection].find({},{'configurationdata':1}) 
                res = list(result)
                for i in range(len(res)):
                    if 'configurationdata' in res[i]:
                        result1 = res[i]
                volgrids_res = result1['configurationdata']
                
            '''        
            elif entity_type == "config":
                result = self.db[collection].find({},{'configdetails':1}) 
                res = list(result)
                for i in range(len(res)):
                    if 'configdetails' in res[i]:
                        result1 = res[i]
                volgrids = result1['configdetails']     
            '''
            volgrids=[]            
            for each in volgrids_res:
                process_name=[]
                for i in range(len(each["eCFDProcessList"])):
                    process_name.append(each["eCFDProcessList"][i]["Process"]["ProcessID"])
                for k in range(len(process_name)):
                    if process_name[k] == data["process_name"]:
                        volgrids.append(each)
#                 if each["eCFDProcessList"][0]["Process"]["ProcessID"] == data["process_name"]:
#                     volgrids.append(each)
            data_temp = deepcopy(data)        
            if data_temp.has_key("entity"):
                del data_temp["entity"]
            if data_temp.has_key("process_name"):
                del data_temp["process_name"] 
            print data_temp
            keys = data_temp.keys()  
            vals = data_temp.values()
            self.code="PYT100"
            if len(keys) == 0:
                self.db_output =  volgrids
                return
            else:
                for i in range(len(keys)):
                    volgrids1 = []
                    for j in range(len(volgrids)):
                        if vals[i] in volgrids[j][keys[i]]:
                            volgrids1.append(volgrids[j])
                    volgrids = deepcopy(volgrids1)         
                self.db_output =  volgrids
                return
        except:
            self.BottleLog.logger.error('Failed to get '+entity_type+'. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"       
            
    def get_content_of_case(self, collection, mongo_id, *args):
        """This method returns the specific content of the document in the respective collection based on the given
        arguments(path) passed to the method.
        Args:
            collection:Name of the collection.
            mongo_id:ObjectId of the json document.
            args:Path of the required block.
        Returns:
            Returns the specific content of the document .
        """
        try:
            
            if collection=='master':
                args = map(lambda x:str(x), args)
                result = json.loads(jsonify(self.db[collection].find_one()))
                self.db_output = reduce(lambda d, key: d[int(key)] if type(key) == str and key.isdigit()  else d[key], args, result)
            else:
                args = map(lambda x:str(x), args)
                query = {}
                query['_id'] = ObjectId(mongo_id)
                result = jsonify(self.db[collection].find_one(query))
                result = json.loads(result)
                self.BottleLog.logger.debug('%s:Getting data from collection - %s'%(mongo_id,collection))
                self.db_output = reduce(lambda d, key: d[int(key)] if type(key) == str and key.isdigit()  else d[key], args, result)
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('%s : Failed to get content of case. Got error %s'%(mongo_id,traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
    
    def get_content_of_block(self, collection, data):
        """This method returns the specific content of the document in the respective collection based on the given
        arguments(data) passed to the method.
        Args:
            collection:Name of the collection.
        Returns:
            Returns the specific content of the document .
        Example Input:{"_id":"55ed2736dc16ed0314078a47","block":["AnalyseProcess"],"fields":["Name","CurrentStep"],"condition":{}}
                Input:{"_id":"55ed2736dc16ed0314078a47","block":["ExecuteProcess"],"fields":["Name","CurrentStep"],"condition":{}}
                Input:{"_id":"55ed2736dc16ed0314078a47","block":["AnalyseProcess"],"fields":["Name","CurrentStep"],"condition":{"id":123}}
                Input:{"_id":"55ed2736dc16ed0314078a47","block":["ExecuteProcess","Steps"],"fields":["Name","Param"],"condition":{}}
        """
        try:
            self.BottleLog.logger.debug('%s:Getting data from collection - %s'%(data['_id'],collection))
            self.get_content_of_case(collection, data["_id"], *data["block"])
            block=self.db_output
            results=[]
            condition=[]
            if data["condition"] !={}:
                condition=data["condition"].keys()
                
            if isinstance(block, list):
                if condition !=[]:
                    for each in block:
                        data_dict={}                        
                        if each[condition[0]]==data["condition"][condition[0]]:
                            for each_field in data["fields"]:
                                data_dict[each_field]=each[each_field]
                            results.append(data_dict)
                else:
                    for each in block:
                        data_dict={}  
                        for each_field in data["fields"]:
                            data_dict[each_field]=each[each_field]
                        results.append(data_dict)
                            
            elif isinstance(block, dict):
                data_dict={}
                for each_field in data["fields"]:
                    data_dict[each_field]=block[each_field]
                results.append(data_dict)
            else:
                results.append(block)
            
            self.db_output=results
            self.BottleLog.logger.debug('%s:Getting data from collection - %s'%(data['_id'],collection))            
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('%s : Failed to get content of case. Got error %s'%(data['_id'],traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"


    def getprocessdata(self, collection, data):
        """This method returns the values of planname,program,prosess,HPCHost and HPCUserId.And also returns the MetaData
        information like whether the plan has to be cloned,transferred or hidden  from transaction collection.
        Args:
            collection:Name of the collection.
            data:process id/case id of the respective plan.           
        Returns:
            Returns the specific process data .        
        """
        try:
            self.BottleLog.logger.info("starting time in  required process data %s"%(datetime.datetime.now()))
            execute_ids_list = []            
            ids_list = []
            tr_id = None
            data_frmdb = []
            output = []                        
            
            if data["process_type"] == "ExecuteProcess":
                query_list =[]
                query = None
                for i in range(len(data["processid_list"])):
                    execute_ids_list.append(data["processid_list"][i]["processid"]) 
                if data.has_key("search_criteria") and data["search_criteria"] !={}:
                    
                    for key,value in data["search_criteria"].items():
                        if value ==  None or value == [] or value =="" :
                            del data["search_criteria"][key]
                    
                    query_tmp = {"ExecuteProcess.id":{"$in":execute_ids_list},"Basic":{"$all":query_list}}
                            
                    if data["search_criteria"].has_key("ModifiedDate"):
                        ModifiedDateRange = int(data["search_criteria"]["ModifiedDate"])
                        if ModifiedDateRange == 0:
                            modified_time_now = datetime.datetime.now()
                            t = datetime.time(0, 0, 0)
                            d = datetime.date.today()
                            modified_time_now_past = datetime.datetime.combine(d, t)                        
                        else:
                            modified_time_now = datetime.datetime.now()
                            modified_time_now_past = modified_time_now + datetime.timedelta(days=-ModifiedDateRange)  
                            
                        query_tmp.update({"TemplateRevision.UpdateTimestamp":{"$gte":modified_time_now_past,"$lte":modified_time_now}})                      
                        del data["search_criteria"]["ModifiedDate"]
                        
                    if data["search_criteria"].has_key("CreatedDate"):
                        CreateDateRange = int(data["search_criteria"]["CreatedDate"])
                        if CreateDateRange == 0:
                            created_time_now = datetime.datetime.now()
                            t = datetime.time(0, 0, 0)
                            d = datetime.date.today()
                            created_time_now_past = datetime.datetime.combine(d, t)                               
                        else:
                            created_time_now = datetime.datetime.now()
                            created_time_now_past = created_time_now + datetime.timedelta(days=-CreateDateRange)  
                        query_tmp.update({"TemplateRevision.CreateTimestamp":{"$gte":created_time_now_past,"$lte":created_time_now}})   
                        del data["search_criteria"]["CreatedDate"] 
                        
                    if data["search_criteria"].has_key("owner"):
                        ownerDetails = data["search_criteria"]["owner"]
                        if len(ownerDetails) != 2 and len(ownerDetails) != 0 and data["search_criteria"].has_key("bemsid"):
                            if (ownerDetails[0]).lower() == "me":
                                query_tmp.update({"MetaData.CurrentOwner":data["search_criteria"]["bemsid"]})
                            elif (ownerDetails[0]).lower() == "others": 
                                query_tmp.update({"MetaData.CurrentOwner":{"$ne":data["search_criteria"]["bemsid"]},"MetaData.Owner":data["search_criteria"]["bemsid"]})
                            del data["search_criteria"]["bemsid"]
                        del data["search_criteria"]["owner"]
                        
                        if data["search_criteria"].has_key("bemsid"):
                            del data["search_criteria"]["bemsid"]
                    
                    if data["search_criteria"].has_key("CurrentPhase"):
                        plan_phase= data["search_criteria"]["CurrentPhase"]                  
                        if isinstance(plan_phase,list):     
                            if len(plan_phase) > 1:        
                                or_query = []         
                                for each_phase in plan_phase:
                                    if each_phase == "Plan" or each_phase == "Setup" or each_phase == "Analyse" or each_phase == "Analyze" : 
                                        if each_phase == "Analyze": 
                                            or_query.append({"ExecuteProcess.CurrentStep":"Analyse"})
                                        else:                              
                                            or_query.append({"ExecuteProcess.CurrentStep":each_phase})
                                    else:                                
                                        or_query.append({"ExecuteProcess.CurrentStep":{"$not":{"$in":["Plan","Setup","Analyse"]}}})
                                        
                                for each_or_query in or_query:
                                    each_or_query.update(query_tmp)
                                    
                                query = {"$or":or_query}                                               
                                    
                            else:
                                plan_phase = plan_phase[0]
                                if plan_phase == "Plan" or plan_phase == "Setup" or plan_phase == "Analyse" or plan_phase == "Analyze":
                                    if plan_phase == "Analyze":
                                        query_tmp.update({"ExecuteProcess.CurrentStep":"Analyse"})   
                                    else:
                                        query_tmp.update({"ExecuteProcess.CurrentStep":plan_phase})                            
                                else:
                                    query_tmp.update({"ExecuteProcess.CurrentStep":{"$not":{"$in":["Plan","Setup","Analyse"]}}})
                                    
                                query = query_tmp
                            
                        del data["search_criteria"]["CurrentPhase"]
                    else:
                        query = query_tmp
                                                         
                    for key,value in data["search_criteria"].items():
                        if key.lower() == "process" or key.lower() == "version":
                            query_list.append({"$elemMatch":{"Name":key,"Value":value}})
                        else:
                            query_list.append({"$elemMatch":{"Name":key,"Value":{"$regex":value,"$options":"i"}}})
                        
                    if query_list == [] :
                        if query.has_key("$or"):
                            for a in query["$or"]:
                                del a["Basic"]  
                        else:
                            del query["Basic"]
                    self.BottleLog.logger.info("logging the query in the process data %s"%(query))
                    data_frmdb = list(self.db[collection].find(query))  
                else:
                    data_frmdb = list(self.db[collection].find({"ExecuteProcess.id":{"$in":execute_ids_list}}))
                for each in data_frmdb:
                    temp_dict={}
                    temp_dict["Version"] = each["ExecuteProcess"]["Version"]
                    temp_dict["id"] = each["_id"]
                    temp_dict["processid"] = each ["ExecuteProcess"]["id"] 
                    temp_dict["Name"] = each["ExecuteProcess"]["Name"]
                    notes_block = each["MetaData"]["Notes"]
                    temp_dict["Notes"] = each["MetaData"]["Notes"][len(notes_block)-1]["Note"]
                    ids_list.append(each["ExecuteProcess"]["id"])
                    try:
                        for j in range(len(each["Basic"])):
                            if each["Basic"][j]["Name"] == "PlanName":
                                temp_dict["PlanName"] = each["Basic"][j]["Value"]
                            elif each["Basic"][j]["Name"] == "Program":
                                temp_dict["Program"] = each["Basic"][j]["Value"]
                            elif each["Basic"][j]["Name"] == "Process":
                                temp_dict["Process"] = each["Basic"][j]["Value"]
                            elif each["Basic"][j]["Name"] == "HPCHost":
                                temp_dict["HPCHost"] = each["Basic"][j]["Value"]
                            elif each["Basic"][j]["Name"] == "HPCUserId":
                                temp_dict["HPCUserId"] = each["Basic"][j]["Value"] 
                        if "MetaData" in each.keys():
                            if "Cloned" in each["MetaData"].keys():
                                temp_dict["Cloned"]=each["MetaData"]["Cloned"]
                            else :
                                temp_dict["Cloned"]=""
                            if "Transferred" in each["MetaData"].keys():
                                temp_dict["Transferred"]=each["MetaData"]["Transferred"]
                            else:
                                temp_dict["Transferred"]=""
                            if "Hidden" in each["MetaData"].keys():
                                temp_dict["Hidden"]=each["MetaData"]["Hidden"]
                            else:
                                temp_dict["Hidden"]=""
                        else:
                            temp_dict["Cloned"]=""
                            temp_dict["Transferred"]=""
                            temp_dict["Hidden"]=""  
                    except:
                        temp_dict["PlanName"] = ""
                        temp_dict["Cloned"]=""
                        temp_dict["Transferred"]=""
                        temp_dict["Hidden"]=""   
                        temp_dict["Program"] =""  
                        temp_dict["Process"] =""   
                        temp_dict["HPCHost"] =""  
                        temp_dict["HPCUserId"] =""
                        
                    output.append(temp_dict)    
                ids_absent = list(set(ids_list).symmetric_difference(set(execute_ids_list)))                
                if ids_absent != []:
                    for each_id in ids_absent:
                        d={}                            
                        d["processid"] = each_id
                        d["id"] = "processid doesn't exist in transaction"
                        self.BottleLog.logger.debug("%s:processid doesn't exist in transaction"%(each_id))
                        output.append(d)
                     
            elif data["process_type"] == "AnalyseProcess":
                tr_id = data["transactionid"]
                data_frmdb = list(self.db[collection].find({"_id":ObjectId(tr_id)},{"AnalyseProcess":1,"Basic":1,"MetaData":1}))                    
                for each in data_frmdb:
                    temp_dict = {}                 
                    for j in range(len(each["AnalyseProcess"])):
                        temp_dict={}
                        temp_dict["Version"] = each["AnalyseProcess"][j]["Version"]
                        temp_dict["id"] = each["_id"]
                        temp_dict["processid"] = each ["AnalyseProcess"][j]["id"]
                        temp_dict["Name"] = each["AnalyseProcess"][j]["Name"]
                        temp_dict["AnalysisName"] = each["AnalyseProcess"][j]["AnalysisName"]
                        output.append(temp_dict) 
                    temp_dict = {}
                    try:
                        for j in range(len(each["Basic"])):
                            if each["Basic"][j]["Name"] == "PlanName":
                                temp_dict["PlanName"] = each["Basic"][j]["Value"]
                            elif each["Basic"][j]["Name"] == "Program":
                                temp_dict["Program"] = each["Basic"][j]["Value"]
                            elif each["Basic"][j]["Name"] == "Process":
                                temp_dict["Process"] = each["Basic"][j]["Value"]
                            elif each["Basic"][j]["Name"] == "HPCHost":
                                temp_dict["HPCHost"] = each["Basic"][j]["Value"]
                            elif each["Basic"][j]["Name"] == "HPCUserItemp_dict":
                                temp_dict["HPCUserId"] = each["Basic"][j]["Value"] 
                        if "MetaData" in each.keys():
                            if "Cloned" in each["MetaData"].keys():
                                temp_dict["Cloned"]=each["MetaData"]["Cloned"]
                            else :
                                temp_dict["Cloned"]=""
                            if "Transferred" in each["MetaData"].keys():
                                temp_dict["Transferred"]=each["MetaData"]["Transferred"]
                            else:
                                temp_dict["Transferred"]=""
                            if "Hidden" in each["MetaData"].keys():
                                temp_dict["Hidden"]=each["MetaData"]["Hidden"]
                            else:
                                temp_dict["Hidden"]=""
                        else:
                            temp_dict["Cloned"]=""
                            temp_dict["Transferred"]=""
                            temp_dict["Hidden"]=""  
                    except:
                        temp_dict["PlanName"] = ""
                        temp_dict["Cloned"]=""
                        temp_dict["Transferred"]=""
                        temp_dict["Hidden"]=""   
                        temp_dict["Program"] =""  
                        temp_dict["Process"] =""   
                        temp_dict["HPCHost"] =""  
                        temp_dict["HPCUserId"] =""
   
                    for i in range(len(output)):
                        output[i].update(temp_dict)                  
                
            self.BottleLog.logger.info("ending time in  required process data %s"%(datetime.datetime.now()))
            self.db_output = output
            self.code="PYT100"
#             for i in range(len(data)):
#                 try:
#                     processid = data[i]["processid"]
#                     res_execute = self.db[collection].find({"ExecuteProcess.id":processid})
#                     reslst_execute = list(res_execute)
#                     res_analyse = self.db[collection].find({"AnalyseProcess.id":processid})
#                     reslst_analyse = list(res_analyse)                    
#                     if len(reslst_execute) == 0 and len(reslst_analyse) == 0:
#                         output = {}
#                         output["processid"] = data[i]["processid"]
#                         output["id"] = "processid doesn't exist in transaction"
#                         result.append(output)
#                         self.BottleLog.logger.debug("%s:processid doesn't exist in transaction"%(data[i]["processid"]))
#                     elif len(reslst_execute) > 0 or len(reslst_analyse) > 0:
#                         self.BottleLog.logger.info("%s:Retrieving the required process data"%(data[i]["processid"]))
#                         output = {}  
#                                                 
#                         if reslst_execute:
#                             reslst = reslst_execute
#                             output["Version"] = reslst[0]["ExecuteProcess"]["Version"]
#                         elif reslst_analyse:
#                             reslst = reslst_analyse
#                             for each in reslst[0]["AnalyseProcess"]:
#                                 if each["id"] == data[i]["processid"]:
#                                     output["Version"] = each["Version"]
#                                     output["Name"] = each["Name"]
#                                     output["AnalysisName"] = each["AnalysisName"]
# 
#                         for j in range(len(reslst[0]["Basic"])):
#                             if reslst[0]["Basic"][j]["Name"] == "PlanName":
#                                 output["PlanName"] = reslst[0]["Basic"][j]["Value"]
#                             elif reslst[0]["Basic"][j]["Name"] == "Program":
#                                 output["Program"] = reslst[0]["Basic"][j]["Value"]
#                             elif reslst[0]["Basic"][j]["Name"] == "Process":
#                                 output["Process"] = reslst[0]["Basic"][j]["Value"]
#                             elif reslst[0]["Basic"][j]["Name"] == "HPCHost":
#                                 output["HPCHost"] = reslst[0]["Basic"][j]["Value"]
#                             elif reslst[0]["Basic"][j]["Name"] == "HPCUserId":
#                                 output["HPCUserId"] = reslst[0]["Basic"][j]["Value"]     
#                         output["id"] = reslst[0]["_id"]
#                         output["processid"] = data[i]["processid"]
#                         
#                         if "MetaData" in reslst[0].keys():
#                             if "Cloned" in reslst[0]["MetaData"].keys():
#                                 output["Cloned"]=reslst[0]["MetaData"]["Cloned"]
#                             else :
#                                 output["Cloned"]=""
#                             if "Transferred" in reslst[0]["MetaData"].keys():
#                                 output["Transferred"]=reslst[0]["MetaData"]["Transferred"]
#                             else:
#                                 output["Transferred"]=""
#                             if "Hidden" in reslst[0]["MetaData"].keys():
#                                 output["Hidden"]=reslst[0]["MetaData"]["Hidden"]
#                             else:
#                                 output["Hidden"]=""
#                         else:
#                             output["Cloned"]=""
#                             output["Transferred"]=""
#                             output["Hidden"]=""
#                         
#                         result.append(output)
#                         #self.BottleLog.logger.debug("%s:process data is %s"%(data[i]["processid"],result))
#                 except:
#                     output = {}
#                     output["processid"] = data[i]["processid"]
#                     output["id"] = "processid doesn't exist in transaction"
#                     result.append(output)
#                     self.BottleLog.logger.debug("%s:processid doesn't exist in transaction"%(data[i]["processid"]))
#                     continue
#             self.db_output = result
#             self.code="PYT100"
        except:
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error('Failed to get process data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.code="PYT200"
        return
    
    def search_plan(self,collection,data):
        """This method returns the values of program,planName,process,planId,transaction_id,Version and Current owner.And 
        also returns the MetaData information like whether the plan has to be cloned,transferred or hidden from transaction
        collection. 
        Args:
            collection:Name of the collection.
            data:Values of program,plan name,process,tags of the transaction documents.           
        Returns:
            Returns the above mentioned values as a list . 
        """ 
        try:
            self.BottleLog.logger.info("Started searching the required plans")
            for key,value in data.items():
                if value ==  None or value == [] or value =="" :
                    del data[key]
            query_list=[]            
            if data.has_key("CurrentOwner") and len(data) > 1:
                query={"Basic":{"$all":query_list},"MetaData.CurrentOwner":data["CurrentOwner"]}
            elif data.has_key("CurrentOwner") and len(data) == 1: 
                query={"MetaData.CurrentOwner":data["CurrentOwner"]}
            else  : 
                query={"Basic":{"$all":query_list}}
                
            for key,value in data.items():
                if key != "CurrentOwner":
                    if isinstance(value,list) : 
                        query_list.append({"$elemMatch":{"Name":key,"Value":{"$in":value}}})
                    else:                 
                        query_list.append({"$elemMatch":{"Name":key,"Value":{"$regex":value,'$options':'i'}}})
                        
            result=self.db[collection].find(query)        
            result=list(result)
            reslst=[]
            for each in result:
                output={}
                for j in range(len(each["Basic"])):
                    if each["Basic"][j]["Name"] == "PlanName":
                        output["PlanName"] = each["Basic"][j]["Value"][0]
                    elif each["Basic"][j]["Name"] == "Program":
                        output["Program"] = each["Basic"][j]["Value"][0]
                    elif each["Basic"][j]["Name"] == "Process":
                        output["Process"] = each["Basic"][j]["Value"][0]
                        
                output["transaction_id"]=each["_id"]
                output["PlanId"]=each["ExecuteProcess"]["id"]
                output["Version"]=each["ExecuteProcess"]["Version"]
                if "CurrentStep" in each["ExecuteProcess"].keys():
                    if each["ExecuteProcess"]["CurrentStep"] == "Analyse":
                        output["StepName"] = "Analyze"
                    else:    
                        output["StepName"]=each["ExecuteProcess"]["CurrentStep"]
                    
                else:
                    output["StepName"]=""
#                 elif data["process_type"] == "AnalyseProcess":
#                     analyse_blocks=each["AnalyseProcess"]
#                     caseId_list=[]
#                     Version_list=[]
#                     current_step_list=[]                    
#                     for block in analyse_blocks:
#                         caseId_list.append(block["id"])
#                         Version_list.append(block["Version"])
#                         if "CurrentStep" in block.keys():
#                             current_step_list.append(block["CurrentStep"])
#                     output["PlanId"]=caseId_list
#                     output["Version"]=Version_list
#                     output["StepName"]=current_step_list
                    
                if "MetaData" in each.keys():
                    if "Cloned" in each["MetaData"].keys():
                        output["Cloned"]=each["MetaData"]["Cloned"]
                    else :
                        output["Cloned"]=""
                    if "Transferred" in each["MetaData"].keys():
                        output["Transferred"]=each["MetaData"]["Transferred"]
                    else:
                        output["Transferred"]=""
                    if "Hidden" in each["MetaData"].keys():
                        output["Hidden"]=each["MetaData"]["Hidden"]
                    else:
                        output["Hidden"]=""
                    if "CurrentOwner" in each["MetaData"].keys():
                        output["CurrentOwner"]=each["MetaData"]["CurrentOwner"]
                    else:
                        output["CurrentOwner"]="" 
                else:
                    output["Cloned"]=""
                    output["Transferred"]=""
                    output["Hidden"]="" 
                    output["CurrentOwner"]=""                  
                reslst.append(output)
            self.db_output = reslst
            self.code="PYT100"
            

        except:
            print (traceback.format_exc())                        
            self.BottleLog.logger.error("Failed to search plan.Got error %s"%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return
        
    
    def get_collection_names(self):
        """This method returns all the collection names of the respective database.
        Returns:
            Returns all the collection names
        """
        try:
            res = self.db.collection_names()
            self.db_output =  list(res)
            self.BottleLog.logger.debug("Names of the collections are "%(list(res)))
            self.code="PYT100"
        except:
            self.BottleLog.logger.error("Failed to get collection names.%s"%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return
    
    def get_flow_cond_params(self, transaction_id):
        """This method returns the values of flow condition parameters from the transaction collection of Database.
        Args
            transaction_id:ObjectId of the json document.
        Returns:
            Returns the flow condition parameters output as list.
        """   
        try:
            query = {'_id':transaction_id}
            self.query_data(self.config_data.eCFD_Transaction_Collection, query, 'single')
            output = json.loads(self.db_output)
            flowcondparams = output['UserInputs']
            for i in range(len(flowcondparams)):
                if flowcondparams[i]['Name']=='Altitude':
                    altitude = flowcondparams[i]['Value']
                    self.altitude = altitude
                elif flowcondparams[i]['Name']=='MachNumber':
                    mach = flowcondparams[i]['Value']
                elif flowcondparams[i]['Name']=='AngleOfAttack':
                    aao = flowcondparams[i]['Value']
                elif flowcondparams[i]['Name']=='SideSlipAngle':
                    sso = flowcondparams[i]['Value']
                elif flowcondparams[i]['Name']=='Reynolds':
                    reynolds = flowcondparams[i]['Value']
                elif flowcondparams[i]['Name']=='FS_Static_Temp':
                    self.temperature = flowcondparams[i]['Value']
            self.BottleLog.logger.debug("flowcondparams are %s,%s,%s,%s,%s"%(altitude, reynolds, mach, aao, sso))
            self.code="PYT100"
            return altitude, reynolds, mach, aao, sso
        except:
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("Error in getting flowcond params.%s"%(self.db_error))
            self.code="PYT237"
        return 
    
    def update_error_details(self, transaction_id, stepname,process_type, block, err_desc, err_code=None, err_type=None,caseId=None):
        """This method updates the values of Description,ErrorCode and ErrorType in Runstatus block of transction 
         collection,based on transaction_id,step name and block name.
        Args:
            transaction_id:ObjectId of the json document.
            stepname:Name of the respective step.
            block:Name of the block in the RunStatus of the transaction document.
            err_desc,err_code,err_type:Field values of the respective block.
        Returns:
            Returns the respective output or error messages.
         """ 
        try:
            data = {}
            self.BottleLog.logger.info('%s:Updating the Runstatus block in the transaction collection'%(transaction_id))
            DateTime=datetime.datetime.now()
            DateTime = DateTime.isoformat()
            data["Description"] = err_desc
            data["ErrorCd"] = err_code
            data["ErrorType"] = err_type
            data["DateTime"]=DateTime
            if process_type == "ExecuteProcess":
                query = {'$and': [{'_id': ObjectId(transaction_id)} , {'ExecuteProcess.Steps.Name': stepname} ] }
                projection = {'ExecuteProcess.Steps.$':1}
                self.query_withproj(self.config_data.eCFD_Transaction_Collection, query, projection)
                block_data = self.db_output[0]["ExecuteProcess"]["Steps"][0]["Param"]["Status"]["Runstatus"][block]            
                collection = self.db[self.config_data.eCFD_Transaction_Collection]
                if len(block_data) > 1 or (len(block_data) == 1 and block_data[0]["Description"] != ''): 
                    self.db_output = collection.update({'$and': [{'_id': ObjectId(transaction_id)} , \
                                                {'ExecuteProcess.Steps.Name': stepname} ] },  
                                                {'$push': {'ExecuteProcess.Steps.$.Param.Status.Runstatus.'+block:data}}, upsert=False)
                elif len(block_data) == 1 and block_data[0]["Description"] == '' :
                    self.db_output = collection.update({'$and': [{'_id': ObjectId(transaction_id)} , \
                                                {'ExecuteProcess.Steps.Name': stepname} ] },  
                                                {'$set': {'ExecuteProcess.Steps.$.Param.Status.Runstatus.'+block:[data]}}, upsert=False)
                self.BottleLog.logger.debug('%s:Updating the %s in Runstatus block in the transaction with data %s'%(transaction_id,block,data))
                self.update_datetime(self.config_data.eCFD_Transaction_Collection, transaction_id)
                self.code="PYT100"            
            elif process_type == "AnalyseProcess":
                query = {'_id':transaction_id,'AnalyseProcess.id': caseId}
                projection = {'AnalyseProcess.$':1}
                self.query_withproj(self.config_data.eCFD_Transaction_Collection, query, projection)
                analyse_block=self.db_output[0][process_type][0]
                steps_list = self.db_output[0][process_type][0]["Steps"]
                for i in range(len(steps_list)):
                    if steps_list[i]["Name"] == stepname:                                
                        block_data=steps_list[i]["Param"]["Status"]["Runstatus"][block]
                        if len(block_data) == 1 and block_data[0]["Description"] == '' :
                            steps_list[i]["Param"]["Status"]["Runstatus"][block] = [data]
                            analyse_block["Steps"]=steps_list
                        elif len(block_data) > 1 or (len(block_data) == 1 and block_data[0]["Description"] != ''):
                            block_data.append(data)
                            steps_list[i]["Param"]["Status"]["Runstatus"][block] = block_data
                            analyse_block["Steps"]=steps_list
                        break 
                self.db_output = self.db[self.config_data.eCFD_Transaction_Collection].update({'AnalyseProcess.id':caseId},{'$set': {'AnalyseProcess.$':analyse_block }}) 
                self.update_datetime(self.config_data.eCFD_Transaction_Collection, transaction_id)
                self.code="PYT100"
            
        except:
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT202"
        return    
          

                
    def delete_process(self,collection,data):
        """This method deletes the documents in transaction collection based on the ObjectIds provided and marks as softDelete 
        in the respective publish documents in publish collection.In case of any error it stores all the deleted associated 
        jsons again to the transaction collection.
        Args:
            collection:Name of the collection.
            data:List of the ObjectIds of the transaction documents.
        Returns:
            Returns the respective output message like which ids are deleted and which are not deleted.
        """
        try:
            db=self        
            return_dict={}
            for i in data['transaction_id']:
                ###---Getting publish id from transaction json---###
                try:
                    db.get_content_of_case(collection, i, data["process_type"], "PublishId")
                    pub_id=db.db_output
                except:
                    pub_id=None                                              
                
                db.db_output=None
                db.db_error=None
                ###---Getting transaction json---###            
                db.get(collection, i)
                error_in_associated_json=[]
                App_Result_Jsons=[]            
                error_count=0
                ###------checking steps block output------###
                if db.db_output !="" and db.db_output !=None and db.db_output !="null":
                    ###Removing the help jsons in case if it is process deletion.
                    if pub_id != None:
                        try:
                            publish_doc = list(self.db["publish"].find({"_id":ObjectId(pub_id)}))[0]
                            process_name = publish_doc["Template"][1]["TemplateApplications"][0]["publish"]["DataBlocks"][0]["publish"]["Name"]["Value"]
                            version = publish_doc["Template"][1]["TemplateApplications"][0]["publish"]["DataBlocks"][0]["publish"]["Version"]["Value"]
                            query = {'Context.Process.ProcessName': process_name, 'Context.Process.ProcessType': data["process_type"], 'Context.Process.Version.VersionName':version}
                            self.db["HelpText"].remove(query)
                            Utility_doc = list(self.db["Utility"].find({'doctype': 'HelpNavigation'}))[0]
                            process_block = Utility_doc["HelpNavigation"]["Processes"]["Process"]
                            for k in range(len(process_block)):
                                if process_block[k]["ProcessType"] == data["process_type"] and process_block[k]["Title"] == process_name :
                                    version_block = process_block[k]["Versions"]
                                    for j in range(len(version_block)):
                                        if version_block[j].has_key("Title") and version_block[j]["Title"] == version:
                                            version_block[j] = {} 
                                    temp_version_block = [block for block in version_block if block != {} ]
                                    process_block[k]["Versions"] = temp_version_block
                                    break
                            self.BottleLog.logger.info("Id is %s.HelpNavigation is %s " % (i,Utility_doc) )        
                            self.db["Utility"].update({'doctype': 'HelpNavigation'},Utility_doc)
                                    
                        except:
                            op =traceback.format_exc().splitlines()[-1]
                            self.BottleLog.logger.error("Failed to delete the help jsons.Id is %s.error is %s " % (i,op) )
                    ###------Getting all associated json ids------###
                    json_ids=re.findall(r'([a-f\d]{24})',db.db_output)
                    if pub_id in json_ids:
                        json_ids.remove(pub_id)

                                            
                    ###------trying to delete associated jsons------###
                    for each in json_ids:
                        if error_count==0:
                            self.get(collection,each)
                            app_json_data=db.db_output
                            db.db_output=None
                            ###------checking appjson data is available or not------###
                            if app_json_data !="" and app_json_data !=None and app_json_data !="null":
                                    ###------appending data in global list for recovering from failure situation------###
                                    App_Result_Jsons.append(app_json_data)
                                    ###------removing json from collection------###
                                    db.remove_collection(collection,each)
                            else:                                                
                                self.BottleLog.logger.error("Failed to get content of associated document.Id is %s"% each)
                                db.db_error=None
                                
                            if db.db_error!=None:
                                self.BottleLog.logger.error('Failed to remove associated document %s,Got error %s'%(each,str(db.db_error)))
                                ###------Tracking errors------###                                                
                                error_in_associated_json.append(each)
                                db.db_error=None
                                error_count +=1
                                break
                        else:
                            break


                    ###------if no errors found in associated json will remove transaction document------###                        
                    if error_in_associated_json==[]:
                        ###------removing transaction document------###
                        db.remove_collection(collection,i)
                        self.BottleLog.logger.debug('%s:Removing transaction document from the collection'%(str(i)))                
                        if db.db_error!=None:
                            ###------error in removing transaction document------###
                            self.BottleLog.logger.error('Failed to remove document %s,Got error %s.'%(str(i),str(db.db_error)))                                        
                            db.db_error=None
                            ###------In case of any error will restore all removed jsons------###
                            for Json_data in App_Result_Jsons:
                                json_d=json.loads(Json_data)
                                doc_id=json_d["_id"]
                                del json_d["_id"]
                                tempdata={"_id":doc_id,"updatedata":json_d}
                                db.update_partdata(collection, tempdata, True)
                            ###------preparing result dict------###
                            return_dict[i]="Error in deletion"
                        else:
                            self.BottleLog.logger.debug('%s:Removed transaction document from the collection'%(str(i))) 
                            ###------In case of no error will update publish document ------###
                            if pub_id !=None and pub_id !="null" and pub_id !="":
                                tempdata={}
                                tempdata["_id"]=pub_id
                                tempdata["updatedata"]={"Template.3.State":"softdelete"}
                                db.update_partdata(self.config_data.eCFD_Publish_Collection,tempdata,False)
                                self.BottleLog.logger.debug('%s:Marked publish as softdelete'%(tempdata["_id"]))
                            else:
                                self.BottleLog.logger.debug('PublishId for %s document not found.'%(str(i)))
                            
                            #db.collection.update({"_id":ObjectId(pub_id)},{$set:{"Template.3.State":"softdelete"}})
                            return_dict[i]="Deleted Successfully"
                    else:
                        ###------if error in associated jsons restoring all removed jsons------###
                        for Json_data in App_Result_Jsons:
                            self.BottleLog.logger.error('Restoring all removed jsons to the collection')
                            json_d=json.loads(Json_data)
                            doc_id=json_d["_id"]
                            del json_d["_id"]
                            tempdata={'_id':doc_id,'updatedata':json_d}
                            db.update_partdata(collection, tempdata, True)
                        return_dict[i]="Error in deletion"
                else:
                    self.BottleLog.logger.error('Failed to get content of %s document.'%(str(i)))
                    return_dict[i]="Error in deletion"     
            return return_dict
        except:
            self.BottleLog.logger.error("Failed to delete.Got error %s"%(traceback.format_exc().splitlines()[-3:]))
            db.db_error=traceback.format_exc().splitlines()[-3:]
            return {}

        
    def search_json(self,data):
            """This method returns values of associated jsons,Created_by,Published_on based on the ProcessName,version and
            associated json names provided.Also it returns Publish_id if the respective json is publish Json from publish 
            collection.
            Args:
                data:Values of version,process name,stepname and associated json names
            Returns:
                Returns the above mentioned data.
            """
            try:
                if data["process_name"] == "" or data["version"] == "" or data["process_name"] == None or data["version"] == None :
                    query={"$or":[ {"Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Name.Value":data["process_name"]},
                                {"Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Version.Value":data["version"]}
                           ]}
                else:
                    query= {"Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Name.Value":data["process_name"],
                                "Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Version.Value":data["version"]}
                    
                if data["ReqDeleted"] == False:
                    query.update({"Template.3.State":{ "$type": 10 }})
                    
                result=[]
                for op in self.db["publish"].find(query):
                    result.append(op)
                result_dict={}
                result_dict["version"]=[]
                result_dict["ProcessName"]=""
                    
                for each in result:
                    try:
                        tpl = Template("publish")
                        tpl.json_restore(each)
                        datablock = tpl.get_data_block("publish","publish")
                        datablock_audit=tpl.get_data_block("publish","audit")
                        Created_by=datablock_audit.get_value("Owner")
                        Published_on=datablock_audit.get_value("DateCreated")
                        process_name = datablock.get_value("Name")
                        version = datablock.get_value("Version")
                        softDelete=each["Template"][3]["State"]
                        
                        if data["required_json"]!=["publishjson"]:
                            self.BottleLog.logger.debug('Searching required associated jsons from the collection')
                            
                            if data.has_key('process_type'): ### To Support previous publish versions and plans.
                                Process = datablock.get_value("Process")                            
                                #tasklist=tasklist.get_value(data['ProcessPhase']) ### uncomment this code if datablock's type is datablcok and value are dictionary###                            
                                ### this code will work for type as string and datablock value as list ###
                                ### if datablock's type is datablock and value are dictionary comment below code from start to end###
                                ### start ###                           
                                dict_new = {}
                                dict_new["Steps"]=[]                                
                                
                                for each in Process:
                                    if each.has_key(data['process_type']):
                                        tasklist=each[data['process_type']]["Value"][0]
                                        break
                                    else:
                                        continue                                
                                
                                ### End ###
                                
                                ### In case of datablock's type is datablock remove ["ProcessStep"] from the below code.###
                                
                                for i in range(len(tasklist)):                                                        
                                    data_new={}
                                    try:
                                        data_new["Stepname"]=tasklist[i]["ProcessStep"]["Name"]["Value"]
                                    except:
                                        data_new["Stepname"]=""
                                                                        
                                    
                                    if data["required_json"]==[] or data["required_json"] == None:                                    
                                        for reqjson in self.config_data.search_json_list:
                                            if data["stepname"]==None or data["stepname"]=='' :
                                                reqjson_id=tasklist[i]["ProcessStep"][reqjson]["Value"]
                                                if reqjson_id !="None" and reqjson_id != None and reqjson_id !="":
                                                    desc=tasklist[i]["ProcessStep"][reqjson]["Description"]
                                                    data_new.update({reqjson:{"Id":str(reqjson_id),"Description":desc}})                                
                                            
                                            else:
                                                if tasklist[i]["ProcessStep"]["Name"]["Value"]==data["stepname"]:
                                                    reqjson_id=tasklist[i]["ProcessStep"][reqjson]["Value"]
                                                    if reqjson_id !="None" and reqjson_id != None and reqjson_id !="":
                                                        desc=tasklist[i]["ProcessStep"][reqjson]["Description"]
                                                        data_new.update({reqjson:{"Id":str(reqjson_id),"Description":desc}})                                
                                    else:             
                                        for reqjson in data['required_json']:
                                            if data["stepname"]==None or data["stepname"]=='' :
                                                reqjson_id=tasklist[i]["ProcessStep"][reqjson]["Value"]
                                                if reqjson_id !="None" and reqjson_id != None and reqjson_id !="":
                                                    desc=tasklist[i]["ProcessStep"][reqjson]["Description"]
                                                    data_new.update({reqjson:{"Id":str(reqjson_id),"Description":desc}})                                
                                            else:
                                                if tasklist[i]["ProcessStep"]["Name"]["Value"]==data["stepname"]:
                                                    reqjson_id=tasklist[i]["ProcessStep"][reqjson]["Value"]
                                                    if reqjson_id !="None" and reqjson_id != None and reqjson_id !="":
                                                        desc=tasklist[i]["ProcessStep"][reqjson]["Description"]
                                                        data_new.update({reqjson:{"Id":str(reqjson_id),"Description":desc}})                                
                                    if len(data_new.keys())>1:
                                        dict_new["Steps"].append(data_new)
                            else:
                                tasklist = datablock.get_value("TaskList")                                
                                dict_new = {}
                                dict_new["Steps"]=[]
                                for i in range(len(tasklist)):                        
                                    data_new={}
                                    data_new["Stepname"]=tasklist[i]["Name"]["Value"]                        
                                    if data["required_json"]==[] or data["required_json"] == None:
                                        
                                        for reqjson in self.config_data.search_json_list:
                                            if data["stepname"]==None or data["stepname"]=='' :
                                                reqjson_id=tasklist[i][reqjson]["Value"]
                                                if reqjson_id !="None" and reqjson_id != None and reqjson_id !="":
                                                    desc=tasklist[i][reqjson]["Description"]
                                                    data_new.update({reqjson:{"Id":str(reqjson_id),"Description":desc}})                                
                                            
                                            else:
                                                if tasklist[i]["Name"]["Value"]==data["stepname"]:
                                                    reqjson_id=tasklist[i][reqjson]["Value"]
                                                    if reqjson_id !="None" and reqjson_id != None and reqjson_id !="":
                                                        desc=tasklist[i][reqjson]["Description"]
                                                        data_new.update({reqjson:{"Id":str(reqjson_id),"Description":desc}})                                
                                    else:             
                                        for reqjson in data['required_json']:
                                            if data["stepname"]==None or data["stepname"]=='' :
                                                reqjson_id=tasklist[i][reqjson]["Value"]
                                                if reqjson_id !="None" and reqjson_id != None and reqjson_id !="":
                                                    desc=tasklist[i][reqjson]["Description"]
                                                    data_new.update({reqjson:{"Id":str(reqjson_id),"Description":desc}})                                
                                            else:
                                                if tasklist[i]["Name"]["Value"]==data["stepname"]:
                                                    reqjson_id=tasklist[i][reqjson]["Value"]
                                                    if reqjson_id !="None" and reqjson_id != None and reqjson_id !="":
                                                        desc=tasklist[i][reqjson]["Description"]
                                                        data_new.update({reqjson:{"Id":str(reqjson_id),"Description":desc}})                                
                                    if len(data_new.keys())>1:
                                        dict_new["Steps"].append(data_new)                                           

                            dict_new["VersionNo"]=version
                            dict_new["Created_by"]=Created_by
                            dict_new["Published_on"]=Published_on
                            dict_new["SoftDelete"]=softDelete
                            result_dict["version"].append(dict_new)
                            result_dict["ProcessName"]=process_name
                        else:
                            self.BottleLog.logger.debug('Retrieving the publish id from the collection')
                            dict_new={}
                            dict_new["VersionNo"]=version
                            dict_new["Created_by"]=Created_by
                            dict_new["Published_on"]=Published_on
                            dict_new["SoftDelete"]=softDelete
                            dict_new["PublishId"]=str(each["_id"])
                            result_dict["version"].append(dict_new)
                            result_dict["ProcessName"]=process_name                            
                    except:
                        #pass
                        self.BottleLog.logger.error("Failed to serach jsons.Got error %s"%(traceback.format_exc().splitlines()[-3:]))
                                          
              
                output=(result_dict)
                self.db_output = output                
                
                
            except:
                #print traceback.format_exc()                         
                self.BottleLog.logger.error("Failed to serach jsons.Got error %s"%(traceback.format_exc().splitlines()[-3:]))
                self.db_error = traceback.format_exc().splitlines()[-1]
            return
        
    def clone_publish(self,data):
        """This method clones the input publish json provided.It clones and stores all the associated jsons in the WorkInProgress
        collection and stores the publish json in publish collection.In case of any error it removes all the associated jsons in
        the WorkInProgress collection.
        Args:
            data:ObjectId of the publish json to be cloned.
        Returns:
            Returns the cloned publish in json format.
        """
        try:  
            self.get(self.config_data.eCFD_Publish_Collection,data["publish_id"])                                               
            if self.db_error==None:
                if self.db_output != "" and self.db_output != None and self.db_output != "null":                    
                    res = json.loads(self.db_output)
                    publish_dump=str(deepcopy(res))
                    tpl =Template("publish")
                    tpl.json_restore(res)
                    datablock = tpl.get_data_block("publish","publish")                    
                    Version = datablock.get_value("Version")               
                    err_count=0
                    new_id_list=[]
                    json_ids=re.findall(r'([a-f\d]{24})',publish_dump)
                    json_ids.remove(data["publish_id"])                    
                    for each in json_ids:
                        self.get(self.config_data.eCFD_Publish_Collection,each)
                        if self.db_error == None:
                            if self.db_output != "" and self.db_output != None and self.db_output != "null":
                                data1=json.loads(self.db_output)
                                del data1["_id"]                    
                                self.store_data(self.config_data.eCFD_workInProgress_Collection,data1)
                                if self.db_error == None:
                                    new_id=str(self.db_output)
                                    new_id_list.append(new_id)                                    
                                    publish_dump=re.sub(each,new_id,publish_dump)                                    
                                else:
                                    err_count=err_count+1
                                    for i in new_id_list:
                                        self.remove_collection(self.config_data.eCFD_workInProgress_Collection,i)
                                    break
                            else:
                                err_count=err_count+1
                                for k in new_id_list:
                                    self.remove_collection(self.config_data.eCFD_workInProgress_Collection,k)
                                break
                        else:
                            err_count=err_count+1
                            for l in new_id_list:
                                self.remove_collection(self.config_data.eCFD_workInProgress_Collection,l)
                            break                                                            
                                    
                    if err_count == 0:                        
                        publish_dump=re.sub(Version,"Copy_"+Version,publish_dump)
                        self.db_output=eval(publish_dump)
                        del self.db_output["_id"]
                        self.db_output=(self.db_output)                        
                        print new_id_list
                        self.BottleLog.logger.debug('%s:Cloned required publish from the collection'%(data["publish_id"]))
                        self.code="PYT100"                         
                    else:
                        self.BottleLog.logger.error("Failed to clone publish")
                        self.db_error="Failed to clone publish" 
                        self.code="PYT239"                            
                else:
                    self.BottleLog.logger.error("Failed because of invalid publish id")
                    self.db_error="Failed because of invalid publish id"
                    self.code="PYT240"                         
            else:
                self.BottleLog.logger.error("Failed to retrieve publish data.Got error %s"%(self.db_error))
                self.db_error=self.db_error
                self.code="PYT241" 
                            
        except:                                  
            self.BottleLog.logger.error("Failed to clone publish.Got error %s"%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT242" 
        return

    def insert_notesdata(self,data):
        """This method updates the Notes block in MetaData section of transaction collection ,based on the input provided.
        It also genrates and updates id/NoteNumber in Notes block of transaction collection.
        Args:
            data:Input notes data to be inserted in notes block.
        Returns:
            Returns the respective output or error messages.
        """
        try:
            self.get_content_of_case("transaction",data["transaction_id"],'MetaData','Notes')
            if self.db_error == None:
                if self.db_output != [] and self.db_output != None and self.db_output != "":         
                    note_list=self.db_output
                    nums_list=[]
                    op_list=[]        
                    for i in range(len(note_list)):
                        if note_list[i]["NoteNumber"] != "" and note_list[i]["NoteNumber"] != None and note_list[i]["NoteNumber"] != "null":                       
                            nums_list.append(note_list[i]["NoteNumber"])
                            if i == len(note_list)-1:
                                num=max(nums_list)
                                data["data"]["NoteNumber"]=num+1
                                data["data"]["id"]=num+1
                                note_list.append(data["data"])
                                op_list=note_list                            
                        else:
                            self.update_partdata("transaction",{"_id":data["transaction_id"],"updatedata":{"MetaData.Notes":""}}, upsert=False)
                            data["data"]["NoteNumber"]=1
                            data["data"]["id"]=1                           
                            op_list.append(data["data"])
                            break                                           
                    self.update_partdata("transaction",{"_id":data["transaction_id"],"updatedata":{"MetaData.Notes":op_list}}, upsert=False) 
                    self.BottleLog.logger.debug('%s:Inserted required data in the collection'%(data["transaction_id"]))
                    if self.db_error == None: 
                        self.code="PYT100"
                        self.update_datetime("transaction",data["transaction_id"])
                    else:
                        self.code="PYT202"       
                else:
                    data["data"]["NoteNumber"]=1
                    data["data"]["id"]=1
                    self.update_partdata("transaction",{"_id":data["transaction_id"],"updatedata":{"MetaData.Notes":[data["data"]]}}, upsert=False)
                    self.BottleLog.logger.debug('%s:Inserted required data in the collection'%(data["transaction_id"])) 
                    if self.db_error == None: 
                        self.code="PYT100"
                        self.update_datetime("transaction",data["transaction_id"])
                    else:
                        self.code="PYT202" 
            else:
                self.BottleLog.logger.error("%s:Failed to get Notes block.Got error %s"%(data["transaction_id"],self.db_error))
                self.db_error=self.db_error
                self.code="PYT244" 
                
        except:
            self.BottleLog.logger.error("Failed to insert Notes block.Got error %s"%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT202" 
        return
    
    def delete_partdata(self,collection,data):
        """This method deletes the particular block from an array of blocks,based on any field of that particular block
        and the path of that block from respective collection.
        Args:
            collection:Name of the collection.
            data:Includes the segemnt of the block i.e path and the filed to be deleted.
        Returns:
            Returns the respective output or error messages.
        """        
        try:        
            args=data["segment"].split(".")
            args=tuple(args)
            self.get_content_of_case(collection,data["transaction_id"],*args)
            op_list=self.db_output
            self.BottleLog.logger.info('%s:Deleting Required Data in the collection - %s'%(collection,data))        
            if data["selectioncriteria"].keys() !=[]:
                parm=data["selectioncriteria"].keys()
                num_list=data["selectioncriteria"].values()
                num_list=num_list[0]
                op=[]             
                for i in range(len(op_list)):               
                    for k in num_list:                                    
                        if str(op_list[i][parm[0]]) == str(k):
                            op.append(op_list[i][parm[0]])
                            op_list[i]=[]
                            break
                op_list=[x for x in op_list if x != []]                     
                self.update_partdata(collection,{"_id":data["transaction_id"],"updatedata":{data["segment"]:op_list}}, upsert=False)
                if self.db_error == None:
                    op_dict={}
                    if op == num_list:
                        for i in op:
                            op_dict[str(i)]="Deleted succesfully"                        
                    else:
                        x=[i for i in num_list if i not in op]
                        for j in x:
                            op_dict[str(j)]="Error in deletion"
                        for i in op:
                            op_dict[str(i)]="Deleted succesfully"
                    self.db_output=op_dict
                    self.BottleLog.logger.debug('%s:Deleted required data in the collection - %s'%(data["transaction_id"],collection))      
                else:
                    self.db_error=self.db_error
                    self.BottleLog.logger.error("%s:Failed to delete.Got error %s"%(data["transaction_id"],self.db_error))
                
            else:
                self.update_partdata(collection,{"_id":data["transaction_id"],"updatedata":{data["segment"]:""}}, upsert=False)
                if self.db_error==None:
                    self.db_output="The value of %s is made to null"%(data["segment"])
                    self.BottleLog.logger.debug('%s:Deleted required data in the collection - %s'%(data["transaction_id"],collection))
                else:                    
                    self.db_error=self.db_error
                    self.BottleLog.logger.error("%s:Failed to delete.Got error %s"%(data["transaction_id"],self.db_error))  
                          
        except:
            self.BottleLog.logger.error("%s:Failed to delete.Got error %s"%(data["transaction_id"],traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
        return
    
    def update_datetime(self, collection, transaction_id, update=True, upsert=False):
        """This method updates current date and time in the TemplateRevision block of the existing collection.
        Args:
            collection:Name of the collection.
            transaction_id:ObjectId of the json document.
        Returns:
            Returns the respective output or error messages.
        """
        try:
            collection = self.db[collection]
            i = datetime.datetime.now()
            #date_iso = i.isoformat()
            date_iso = i
            self.BottleLog.logger.info('%s:Updating Data in the collection - %s'%(transaction_id,collection))
            time_data = {}
            if update:
                time_data["TemplateRevision.UpdateTimestamp"] = date_iso
            else:
                time_data["TemplateRevision.CreateTimestamp"] = date_iso
                time_data["TemplateRevision.UpdateTimestamp"] = date_iso
                time_data["MetaData.Type"] = "Transaction"
            #self.db_output = collection.update({'_id': ObjectId(data['_id'])}, {'$set': data['updatedata']},upsert=upsert)
            self.db_output = collection.update({'_id': ObjectId(transaction_id)}, {'$set':time_data} ,upsert=upsert)
        except:
            self.BottleLog.logger.error('%s : Failed to update data. Got error %s'%(transaction_id,traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
        return
    
    def retrieve_records(self, collection, start_time, end_time):
        """This method retrieves records from transaction collection between two timestamps.
        Args:
            collection:Name of the collection.
            start_time:Starting time.
            end_time:Ending time.
        Returns:
            Returns respective json data.
        """
        try:
            collection = self.db[collection]
            result = collection.find({"TemplateRevision.UpdateTimestamp": {'$gte':start_time, '$lte':end_time}})
            output_result = []
            out_data = list(result)
            self.BottleLog.logger.info('Retrieving Data in the collection - %s'%(collection))
            for l in range(len(out_data)):
                output_result.append(json.loads(jsonify(out_data[l])))
                for i in range(len(out_data[l]["Process"]["Steps"])):
                    appjson_data = out_data[l]["Process"]["Steps"][i]["Param"]["AppJson"]
                    resultjson_data = out_data[l]["Process"]["Steps"][i]["Param"]["Runs"]
                    for j in range(len(appjson_data)):
                        self.get(self.config_data.eCFD_Transaction_Collection,appjson_data[j]["MongoRefId"])                                               
                        if self.db_error==None:
                            if self.db_output != "" and self.db_output != None and self.db_output != "null":                    
                                res = json.loads(self.db_output)
                                output_result.append(res)
                        else:
                            self.db_error = None
                    for k in range(len(resultjson_data)):
                        self.get(self.config_data.eCFD_Transaction_Collection,resultjson_data[k]["ResultJson"]["MongoRefId"])                                               
                        if self.db_error==None:
                            if self.db_output != "" and self.db_output != None and self.db_output != "null":                    
                                res = json.loads(self.db_output)
                                output_result.append(res)
                        else:
                            self.db_error = None        
            self.db_output = output_result
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('Failed to get data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT200"
        return

    def error_lookup(self, collection , error_code):
        #collection = "errorlookup"
        #result = self.get_datastore(collection)
        #query= {"error_lookup": { '$elemMatch': { "Code": error_code }}}
        #projection = {'error_lookup.$':1}
        #self.query_withproj(collection, query, projection)
        #self.db[collection].find({"error_lookup": { '$elemMatch': { "Code": error_code }}, {'error_lookup.Status':1}})
        '''
        if self.db_error==None:
            print self.db_output
        else:
            print self.db_error
        '''
        try:
            if error_code == "all":
                result = self.db[collection].find({"error_lookup":{"$exists" :True}})
                #print list(result)
                return list(result)[0]               
            else:
                result = self.db[collection].aggregate([
                                                   { "$unwind": "$error_lookup" },
                                                   { "$match": { "error_lookup.Code": error_code }},
                                                   { "$project": { "Code": "$error_lookup.Code",
                                                              "Status": "$error_lookup.Status",
                                                              "TechnicalDescription" : "$error_lookup.TechnicalDescription",
                                                              "UIDescription" : "$error_lookup.UIDescription",
                                                              "_id":0 }
                                                    }
                                               ])
                print result
                return  result["result"][0]   
        except:
            self.BottleLog.logger.error('Failed to error lookup. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            return {"error":traceback.format_exc().splitlines()[-1]}
        

    def update_user_preference(self, collection, data, upsert=False):
        """This method updates the existing collection."""
        try:            
            collection = self.db[collection]
            doc_id=collection.find_one({"doctype":"userpreference"},{"_id":1})
            if doc_id != None:
                match=collection.find_one({"Users.preferences":{"$elemMatch":{"bemsid":data["bemsid"]}}})
                if match != None:
                    bems_id=data.pop('bemsid')
                    data_dict={}                    
                    for key,value in data.iteritems():
                        data_dict['Users.preferences.$.'+key]=value
                    
                    self.db_output=collection.update({"Users.preferences.bemsid":bems_id},{"$set":data_dict})
                    self.code="PYT100"
                else:
                    self.db_output=collection.update({"_id":doc_id["_id"]},{"$push":{"Users.preferences":data}})
                    self.code="PYT100"
            else:
                self.code="PYT202"
                self.db_error="User preference document not found"
        except:
            self.code="PYT202"
            self.BottleLog.logger.error('Failed to update user preferences in %s collection. Got error %s'%(collection,traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
        return   
                
    def update_with_query(self, collection, data, upsert=False):
        """This method updates the existing collection."""            
        try:
            collection_name = collection                
            collection = self.db[collection]
            self.BottleLog.logger.info('%s:Updating Data in the collection - %s'%(data,collection))
            if data["_id"] !="":
                data["query"].update({"_id":ObjectId(data["_id"])})                
            self.db_output = collection.update(data["query"],{'$set': data["update"]},upsert=upsert)
            if collection_name.lower() == "transaction" and data.has_key("_id") and data["_id"] !="":
                self.update_datetime(collection_name,data["_id"])
            self.code="PYT100"
        except:
            self.BottleLog.logger.error('Failed to update data. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT202"
        return   
    def update_dictionary(self, dic, keys, value, pattern=False):
        try:
            for key in keys[:-1]:
                if key.isdigit():
                    dic = dic[int(key)]
                else:    
                    dic = dic.get(key, [])
            if keys[-1].isdigit():       
                if pattern:
                    dic[int(keys[-1])].append(value)
                else:
                    dic[int(keys[-1])] = value    
            else:
                if dic.has_key(keys[-1]):
                    dic[keys[-1]] = value 
                else:
                    self.db_error = "Failed to modify the json using this %s path "%(jsonify(keys))
            self.code="PYT100"
            return dic
        except:
            self.BottleLog.logger.error('Failed in modify the json.Got error  %s'%(traceback.format_exc().splitlines()[-3:]))            
            self.db_error = "Failed to modify the json using this %s path "%(jsonify(keys))
            self.code="PYT255"
        return            

    def push_object_to_document(self, collection, data):
        """This method push objects to the existing collection."""
        try:
            collection_name = collection            
            collection = self.db[collection]            
            if data.has_key("_id") and data["_id"] != None and data["_id"] !="":                
                    self.db_output=collection.update({"_id":ObjectId(data["_id"])},{"$push":{data["block"]:data["pushdata"]}})
                    if collection_name.lower() == "transaction":
                        self.update_datetime(collection_name, data["_id"])
                    self.code="PYT100"
            elif data.has_key("query") and data["query"] != None and len(data["query"]) != 0:
                    self.db_output=collection.update(data["query"],{"$push":{data["block"]:data["pushdata"]}})
                    if collection_name.lower() == "transaction":
                        self.update_datetime(collection_name, data["_id"])
                    self.code="PYT100"                 
            else:
                self.db_error="mongo reference id not found"
                self.code="PYT252"
        except:
            self.BottleLog.logger.error('Failed to push data to %s block.Got error %s'%(data["block"],traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT202"
        return            
    def update_jsons(self,collection,data):
        
        """This method updates the input jsons(single/multiple) using the list of path and values.
        data={"pathList":[{}],"transaction_id":"","process_type":"","caseId":"","stepname":"","json_name":""}"""
        try:
            ###--Getting the steps block in required format--###
            if data["process_type"] == "ExecuteProcess":
                steps_block = self.db[collection].find({"_id":ObjectId(data["transaction_id"]),"ExecuteProcess.Steps.Name":data["stepname"]},{"ExecuteProcess.Steps.$":1})
                steps_block = list(steps_block)
                
            elif data["process_type"] == "AnalyseProcess":
                analyse_block = self.db[collection].find({"_id":ObjectId(data["transaction_id"]),"AnalyseProcess.id":int(data["caseId"])},{"AnalyseProcess.$":1})
                analyse_block = list(analyse_block)
                steps = analyse_block [0]["AnalyseProcess"][0]["Steps"]
                output = [each for each in steps if each["Name"] == data["stepname"]]
                steps_block = [{"AnalyseProcess" :{"Steps":output}}]
                
            ###--Storing the required json block from "Steps" block as a list--###    
            if data["json_name"].lower() == "appjson": 
                jsons = steps_block[0][data["process_type"]]["Steps"][0]["Param"]["AppJson"]
            elif data["json_name"].lower() == "resultjson" or data["json_name"].lower() == "queryjson":
                runs_block = steps_block[0][data["process_type"]]["Steps"][0]["Param"]["Runs"]
                jsons=[]
                for j in range(len(runs_block)) : 
                    if data["json_name"].lower() == "resultjson":
                        jsons.append(runs_block[j]["ResultJson"])
                    elif data["json_name"].lower() == "queryjson":
                        jsons.append(runs_block[j]["QueryJson"])
                        
            ###--Storing the mongo reference ids of the json from the above stored json block as a list.--###
            if jsons!=[]:
                ids_list = []            
                for i in range(len(jsons)) :
                    ids_list.append(jsons[i]["MongoRefId"])
                
                for k in range(len(ids_list)) :
                    if ids_list[k] != None or ids_list[k] != 'None' or ids_list[k] != "":
                        json_data = self.db[collection].find({"_id":ObjectId(str(ids_list[k]))})
                        json_data = list(json_data)                    
                        if json_data != [] :                        
                            json_data=list(json_data)[0]
                            json_data_dict=jsonify(json_data)
                            json_data_dict=json.loads(json_data_dict)
                            if "_id" in json_data_dict.keys():
                                del json_data_dict["_id"]
                                
                            ###--Modifing the json data based on the path and value--###                    
                            for a in range(len(data["pathList"])) :
                                path_field = data["pathList"][a]["path"]
                                value = data["pathList"][a]["value"] 
                                path = re.sub(r'\[(\d+)\]',r'\g<1>', path_field)
                                path_as_list=path.split("/")
                                if data["pathList"][a]["operation"] == "add":
                                    self.BottleLog.logger.info("Started adding the block in the json for the  %s path" %(path))
                                    path_as_list.append("0")
                                    self.get_content_of_case(collection, ids_list[k] , *tuple(path_as_list))
                                    #print self.db_output
                                    #print value
                                    self.db_output.append(value)
                                    self.update_dictionary(json_data_dict,path_as_list, self.db_output)
                                    if self.db_error != None :
                                        self.BottleLog.logger.error("%s:Failed to modify the json using the %s path ."%(ids_list[k],path))
                                        self.code="PYT255"
                                        return 

                                elif data["pathList"][a]["operation"] == "update":
                                    self.BottleLog.logger.info("Started modifing the json for the  %s path" %(path))
                                    self.update_dictionary(json_data_dict, path_as_list, value)
                                    if self.db_error != None :
                                        self.BottleLog.logger.error("%s:Failed to modify the json using the %s path ."%(ids_list[k],path))
                                        self.code="PYT255"
                                        return 
                                elif data["pathList"][a]["operation"] == "delete":
                                    self.BottleLog.logger.info("Started deleting the values/blocks in the json for the  %s path" %(path))
                                    self.get_content_of_case(collection, ids_list[k] , *tuple(path_as_list[:-1]))
                                    #self.db_output.remove(self.db_output[int(path_as_list[len(path_as_list)-1])])
                                    del self.db_output[int(path_as_list[len(path_as_list)-1])]
                                    self.update_dictionary(json_data_dict, path_as_list[:-1],self.db_output)
                                    if self.db_error != None :
                                        self.BottleLog.logger.error("%s:Failed to modify the json using the %s path ."%(ids_list[k],path))
                                        self.code="PYT255"
                                        return                                
                                elif data["pathList"][a]["operation"] == "deleteall":
                                    self.BottleLog.logger.info("Started adding the block in the json for the  %s path" %(path))
                                    path_as_list.append("0")                                    
                                    self.update_dictionary(json_data_dict,path_as_list, [])
                                    if self.db_error != None :
                                        self.BottleLog.logger.error("%s:Failed to modify the json using the %s path ."%(ids_list[k],path))
                                        self.code="PYT255"
                                        return             
                            ###--Updating  the json data to the database based on list of the paths and values--### 
                            self.update_data(self.config_data.eCFD_Transaction_Collection,{"_id":ids_list[k]}, json_data_dict)
                            if self.db_error != None:
                                self.code="PYT202"
                                return
                        else:
                            self.BottleLog.logger.error("%s:MongoId reference not found."%(ids_list[k]))
                            self.db_error ="MongoId reference not found."
                            self.code="PYT252"            
                            return 
                    else:
                        self.BottleLog.logger.error("%s:MongoId reference not found."%(ids_list[k]))
                        self.db_error ="MongoId reference not found."
                        self.code="PYT252"            
                        return                             
            else:
                self.BottleLog.logger.error("%s:Failed to retrieve the respective steps block."%(data["transaction_id"]))
                self.db_error ="Failed to retrieve the respective steps block."
                self.code="PYT254"            
                return    
               
   
        except:
            self.BottleLog.logger.error('Failed to update the jsons.Error is %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = "Failed to update the jsons."
            self.code="PYT202" 
            return  
    def search_auditdata(self, collection, start_time, end_time, user, eventtype):
        """This method get audit data from  collection by using between two timestamps,user,eventtype.
        Args:
            collection:Name of the collection.
            start_time:Starting time.
            end_time:Ending time.
            user : BEMS id of the user
            eventtype: ""
        Returns:
            Returns respective audit data.
        """
        try:
    
            query = {}
            if user:
                query.update({"AuditData.User":user})
            if eventtype:
                query.update({"AuditData.EventType":eventtype})
            date_query = {}
            if start_time:
                start_date = datetime.datetime.strptime(start_time,"%Y-%m-%d")                
                start_time = datetime.time.min               
                start_time_iso = datetime.datetime.combine(start_date, start_time)                
                date_query.update({'$gte':start_time_iso})    
#                 start_time_iso = datetime.datetime.strptime(start_time,"%Y-%m-%dT%H:%M:%S.%fZ")
#                 date_query.update({'$gte':start_time_iso})
            if end_time:
                end_date = datetime.datetime.strptime(end_time,"%Y-%m-%d")                
                end_time = datetime.time.max
                end_time_iso = datetime.datetime.combine(end_date,end_time)
                date_query.update({'$lte':end_time_iso})
#                 end_time_iso = datetime.datetime.strptime(end_time,"%Y-%m-%dT%H:%M:%S.%fZ")
#                 date_query.update({'$lte':end_time_iso})
            if date_query:
                query.update({"AuditData.DateTime": date_query})
            self.query_data(collection, query, 'multiple')
             
            self.BottleLog.logger.info('Retrieving audit Data in the collection - %s'%(collection))
        except:
                #print traceback.format_exc()
                self.BottleLog.logger.error("Failed to serach jsons.Got error %s"%(traceback.format_exc().splitlines()[-3:]))
                self.db_error = traceback.format_exc().splitlines()[-1]
        return
    def deleteProcessNestedJsons(self,collection,process_name,process_version,stepname,field_to_delete,process_step,upsert=False):
        """ This method delete the Specified JSON"""
        try:
            #collection = self.db[collection]
            self.BottleLog.logger.info('deleting Data in the collection - %s'%(collection))
            
            query = {'$and': [{'Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Name.Value': process_name } , 
                          {'Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Version.Value':process_version},
                           {'Template.3.State':{ "$type": 10 }} ] }
            self.query_data(collection, query, 'single')
            if self.db_error==None:
                if self.db_output==None or self.db_output== "None" or self.db_output== "null" or self.db_output=="" :
                    self.db_error = "No publish document found for the process : %s ,version : %s"%(process_name,process_version)
                    self.BottleLog.logger.error(self.db_error)
                    self.code = "PYT226"                    
                else:
                    publish_id = json.loads(self.db_output)["_id"]                    
                    tpl=Template("publish")
                    tpl.json_restore(json.loads(self.db_output))
                    datablock=tpl.get_data_block("publish","publish")
                    self.BottleLog.logger.debug('Getting Process block using template class')
                    Process = datablock.get_value("Process")                    
                    self.BottleLog.logger.debug('Getting tasklist block based on %s Phase Name'%(process_step))
                    for each in Process:
                        if each.has_key(process_step):                            
                            tasklist = each[process_step]["Value"][0]
                            if tasklist==[]:
                                self.BottleLog.logger.debug('Tasklist is empty,so nothing to delete')
                                self.db_error="mongo reference id not found"
                                self.code="PYT323"                               
                            else:
                                continue      
                    
                    for i in range(len(tasklist)):                        
                        if process_step == "PlanStep":
                            datamap_mongo_id= tasklist[i]["ProcessStep"][field_to_delete]["Value"] 
                            self.remove_collection(collection,datamap_mongo_id)
                            if self.db_error == None:
                                tasklist[i]["ProcessStep"][field_to_delete]["Value"] = 'None'
                                data = {"_id":publish_id,"updatedata":{'Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Process.Value':Process}}
                                self.update_partdata(collection, data, False)
                                if self.db_error != None:
                                    self.code="PYT202"
                                    self.BottleLog.logger.error("Failed to update the publish docmunet .Error is %s"%self.db_error)   
                                else:
                                    self.code="PYT100"  
                                break
                            else:
                                self.db_error = "Failed to delete the json %s"%datamap_mongo_id
                                self.BottleLog.logger.error("Failed todelete the nested json ,id: %s.Error is %s"%(datamap_mongo_id,self.db_error))
                                self.code="PYT203"
                                break                                
                                   
                        else:
                            if str(tasklist[i]["ProcessStep"]['Name']['Value']) == stepname:  
                                datamap_mongo_id = tasklist[i]["ProcessStep"][field_to_delete]['Value']  
                                if  datamap_mongo_id != "None":                            
                                    self.remove_collection(collection,datamap_mongo_id)
                                    tasklist[i]["ProcessStep"][field_to_delete]['Value']='None'                               
                                    if self.db_error == None:
                                        data = {"_id":publish_id,"updatedata":{'Template.1.TemplateApplications.0.publish.DataBlocks.0.publish.Process.Value':Process}}
                                        self.update_partdata(collection, data, False) 
                                        if self.db_error != None:
                                            self.code="PYT202"
                                            self.BottleLog.logger.error("Failed to update the publish docmunet .Error is %s"%self.db_error)   
                                        else:
                                            self.code="PYT100"                                     
                                        break
                                    else:
                                        self.db_error = "Failed to delete the json %s"%datamap_mongo_id
                                        self.BottleLog.logger.error("Failed to delete the nested json ,id: %s.Error is %s"%(datamap_mongo_id,self.db_error))
                                        self.code="PYT203"
                                        break
                                else:
                                    self.db_error = "mongo reference id not found "
                                    self.BottleLog.logger.error("Failed to delete the nested json.Error is %s"%(self.db_error))
                                    self.code="PYT323"
                                    break                                   
            else:
                self.db_error = "Failed to retrieve the publish document.Query is %s ,Error is %s"%(query,self.db_error)
                self.BottleLog.logger.error(self.db_error)
                self.code = "PYT200"
        
        except:
            self.BottleLog.logger.error('Failed to delete nested json from publish document. Got error %s'%(traceback.format_exc().splitlines()[-3:]))
            self.db_error = traceback.format_exc().splitlines()[-1]
            self.code="PYT203"
        return
    def get_basic_parameters(self,transactionid):
        try:            
            params= {}
            self.query_data(self.config_data.eCFD_Transaction_Collection, {"_id":transactionid},"single")
            if self.db_error == None:
                if json.loads(self.db_output) != []:
                    output = json.loads(self.db_output)
                    for each in output["Basic"]:
                        if each["Name"] == "HPCUserId":
                            params["username"] = each["Value"][0]
                        elif each["Name"] == "RunDir":
                            params["rundir"] = each["Value"][0]
                        elif each["Name"] == "HPCHost":
                            params["hpcserver"] = each["Value"][0]
                
                    params["bemsid"] = output["MetaData"]["CurrentOwner"]   
                    if len(params) == 4:
                        self.db_output = params
                        self.BottleLog.logger.info('%s:Retrieved the basic block parameters.Params are %s'%(transactionid,params))
                    else:
                        self.code="PYT200" 
                        self.db_error = "Failed to retrieve the required  basic block paramaters"
                        self.BottleLog.logger.error('%s:Failed to retrieve the required basic block parameters.Retrieved params are %s'%(transactionid,params))
                else:
                    self.code="PYT200" 
                    self.db_error = "Couldnot  find the transaction document in database"
                    self.BottleLog.logger.error('%s:Couldnot  find the transaction document in database'%(transactionid))
            else:
                self.code="PYT200" 
                self.db_error = "Failed to fecth the transaction document from database"
                self.BottleLog.logger.error('%s:Failed to fecth the transaction document from database.Error is %s'%(transactionid,self.db_error))                
                         
                        
        except:
            self.code="PYT200" 
            self.db_error = "Failed to retrieve the required  basic block paramaters"
            self.BottleLog.logger.error('%s:Failed to retrieve the required basic block parameters.Error is %s'%(transactionid,traceback.format_exc().splitlines()[-3:]))   
            
        return             

        
if __name__ == "__main__":
    db = eCFDdb()
