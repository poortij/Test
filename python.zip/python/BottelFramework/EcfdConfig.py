# Defaults assumed to be
# DBNAME = 'ecfddb'
# LOCAL_PATH = '/boeing/sw/ecfd/alpha'
# LOCAL_PYTHON = '/boeing/sw/ecfd/alpha/python'
# REMOTE_PATH = '/boeing/sw/ecfd/alpha'
# PYTHON_PATH = '/boeing/sw/ecfd/bin/python2.7'
'''
Make all chanes in EcfdConfig.py.  EcfdConfig.py.in has been removed.
'''
import os
import logging
DBNAME = '@DBNAME@'
LOCAL_PATH = '@LOCAL_PATH@'
LOCAL_PYTHON = '@LOCAL_PYTHON@'
REMOTE_PATH = '@REMOTE_PATH@'
PYTHON_PATH = '@PYTHON_PATH@'
BPM_URL = '@BPM_URL@'
VERSION = '@VERSION@'

class EcfdConfig:
    
    def __init__(self):
        global DBNAME, LOCAL_PATH, LOCAL_PYTHON, REMOTE_PATH, PYTHON_PATH, BPM_URL

        self.DatabaseName = DBNAME
        self.local_path = LOCAL_PATH
        self.local_python = LOCAL_PYTHON
        self.remote_path = REMOTE_PATH
        self.python_path = PYTHON_PATH
        self.version = VERSION

        #Database related configuration
        self.DatabaseHost = 'localhost'
        self.DatabasePort = 58280
        self.max_pool_size=10
        
        #Config path for the scripts
        self.rootDir = '/plandata/'
        self.aerodbPath = os.path.join(self.local_path, 'lib/json/aerodb')
        self.utilityPath = os.path.join(self.local_path, 'lib/json/utilities')
        self.templates_path = os.path.join(self.local_path, 'templates')
        self.execute_path_prefix = os.path.join(self.remote_path, 'bin')
        self.script = os.path.join(self.execute_path_prefix, 'RunTask')
        self.templatescript_path = os.path.join(self.local_path, 'lib/python2.7')
        self.userexecute_script = os.path.join(self.local_python,'UserExecute.py')
        
        #Database collection config
        self.eCFD_Master_Collection = 'master'
        self.eCFD_imported_Collection = 'ImportedObjects'
        self.eCFD_Transaction_Collection = 'transaction'
        self.eCFD_Publish_Collection = 'publish'
        self.eCFD_workInProgress_Collection='workInProgress'
        self.eCFD_Sched_Collection = 'sched'
        self.eCFD_SchedTemp_Collection= "temporarysched"
        self.eCFD_Utility_Collection = 'Utility'
        self.eCFD_HelpText_Collection = "HelpText"
        self.eCFD_UserInputs_Collection = 'UserInputsDictionary'
        self.logfile = 'logs/bottle_log'
        self.statuslogfile = 'logs/check_status_log'
        self.loglevel = logging.DEBUG
        
        self.HPCServer = 'pluto.ca.boeing.com'
        self.username = 'mu888d'
        self.runDir = '/home/mu888d/forkrishna'
        self.mailuser='ox967d'
        self.media_path = "/boeing/sw/ecfd/data"
        self.CanSendEmail=False
        self.BluesInfo_Required = "Yes"
        
		
        #Put 'Yes' if you are pointing to local mock else put 'No'
        self.point_to_mock = 'No'
		
        #Config data for Compute atmo tables
        self.stdatmoPath = self.remote_path
        
        
        #Config data for LaunchAeroDb.py         
        self.CGT_FILE = os.path.join(self.aerodbPath, 'cgt.json')
        self.OvHipPProc_FILE = os.path.join(self.aerodbPath,'OvPProc.json')
        self.FlowCondition_FILE = os.path.join(self.aerodbPath,'flowcond.json')
        self.OverPlot_FILE = os.path.join(self.aerodbPath,'Overplot.json')
        self.OverGrid_FILE = os.path.join(self.aerodbPath,'overgrid.json')
        self.GetVolGrid_FILE = os.path.join(self.aerodbPath,'GetGrid.json')
        self.Pbsid_FILE = os.path.join(self.utilityPath, 'pbsid.json')
        self.Xterm_FILE = os.path.join(self.utilityPath, 'xterm.json')
        self.Editor_FILE = os.path.join(self.utilityPath, 'editor.json')
        self.xxdiff_FILE = os.path.join(self.utilityPath, 'xxdiff.json')
        self.qdel_FILE = os.path.join(self.utilityPath, 'qdel.json')
        self.stdatmo_FILE = os.path.join(self.aerodbPath, 'stdatmo.json')
        self.cleanup_FILE = os.path.join(self.aerodbPath, 'Overflow.Cleanup.json')
        
        #Config data for CheckStatusScheduler.py
        self.BPM_PATH = BPM_URL
        self.scheduler_username = 'apache'
        user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
        self.headers = { 'User-Agent' : user_agent, 'Content-Type' : 'application/json'}
        
        #Config data for LaunchRunTask.py
        self.cmd = self.python_path
        
        self.publish_json_list = ['QueryJSON', 'DataMapJSON', 'PresentJSON' , 'Evaluate']
        self.delete_json_type=["AppJson","Runs"]
        self.search_json_list = ['AppJSON', 'ResultJSON','DataMapJSON','QueryJSON']
        
if __name__=='__main__':    
    obj = EcfdConfig()