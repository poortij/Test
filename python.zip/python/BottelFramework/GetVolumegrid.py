#!/boeing/sw/ecfd/bin/python2.7

#GetVolumeGrid is the class to launch check the availablity of volumegrids.
#This class gets the inputs from the user on which volumegrids are required
#and checks the availability of required volumegrids

__author__ = "Sreevatsa Beleyur Devappa"
__copyright__ = ""
__credits__ = ["Sreevatsa Beleyur Devappa , Venkata Harish Nagamangalam"]
__license__ = ""
__version__ = "1.0"
__maintainer__ = "Sreevatsa Beleyur Devappa"
__email__ = "sreevatsa.b@hcl.com"
__status__ = "Code Generator"
__lastupdatedon__= "16/10/2014" #dd/mm/yyyy

import sys
import shutil
import traceback
import copy
import json
import os,time
from JsonHelper import jsonify
from DatabaseWrapper import eCFDdb
from EcfdConfig import EcfdConfig
#from SSHAuthentication import SSHAuthentication
from subprocess import Popen, PIPE, STDOUT
from BottleAppLogger import BottleAppLogger
from EcfdCaller import EcfdCaller
from Retriever import Retriever

class Getgrid:

    def __init__(self, caseid, action):
        """Initializer for the GetVolumeGrid class"""
        self.config_data = EcfdConfig()
        self.BottleLog = BottleAppLogger('Getgrid')
        self.action = action
        self.caseID = caseid
        self.db = eCFDdb()
        self.db.connect(self.config_data.DatabaseName)
        self.NAvailable_list = []
        
        ##for script execution testing purpose only
        #self.username = self.config_data.username
        #self.hpcserver = self.config_data.HPCServer
        #self.setupDir = self.config_data.runDir
        #self.retrieve_obj = Retriever(self.caseID, self.action)
        
        self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, "Basic", "Phase", 0, "SubStep", 0, "Param", 6, "Value")
        self.hpcserver = self.db.db_output
        self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, "Basic", "Phase", 0, "SubStep", 0, "Param", 7, "Value")
        self.username = self.db.db_output
        self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, "Process", "CurrentOwner")
        self.bemsid = self.db.db_output
        self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, "Basic", "Phase", 0, "SubStep", 0, "Param", 8, "Value")
        self.setupDir = self.db.db_output
        
        self.BottleLog.logger.debug('Get grid initialised with caseID: %s and username %s'%(self.caseID, self.username))
        #self.SSHConn = SSHAuthentication(self.username)
        #self.SSHConn.doSSHAuthentication()
        self.BottleLog.logger.info('Get grid Initialization completed')

#     def loadFileContent(self, fileFullPath):
#         """Laod the fileconent provide the fullpath of the file"""
#         try:
#             self.BottleLog.logger.info('Loading file content - %s'%(fileFullPath))
#             current = os.getcwd()
#             self.fPath = os.path.join(self.config_data.rootDir, self.setupDir)
#             #self.dst = self.SSHConn.execute_script_ssh('cd '+self.fPath+';pwd', 2)
#             os.chdir(self.fPath)
#             self.dst = os.getcwd()
#             #self.dst = os.path.join(os.path.join(self.dst, 'master'), 'json')
#             self.BottleLog.logger.debug('destination dst= %s '%(self.dst))
#             if not os.path.exists(self.dst):
#                 os.makedirs(self.dst)
#             #self.SSHConn.execute_script_ssh(self.dst,1)
#             #self.SSHConn.execute_script_ssh('cd '+current, 2)
#             os.chdir(current)
#             shutil.copy(fileFullPath, self.dst)
#             #copy_command = 'cp '+fileFullPath+' '+self.dst
#             #self.SSHConn.execute_script_ssh(copy_command , 2)
#             fp = open(os.path.join(self.dst, os.path.split(fileFullPath)[-1]))
#             #self.data = self.SSHConn.read_file_ssh(os.path.join(self.dst, os.path.split(fileFullPath)[-1]))
#             self.data = json.load(fp)
#             fp.close()
#             self.BottleLog.logger.info('Completed loading file - %s'%(fileFullPath))
#             return True
#         except:
#            self.BottleLog.logger.error('Failed to read file. Got error - %s'%(traceback.format_exc().splitlines()[-1]))
#            self.error_update = traceback.format_exc().splitlines()[-1]
#            return False
# 
#     def fill_details(self):
#         try:
#             """Fill the required details into getvolgrid.json and pass it to runtask"""
#             self.loadFileContent(self.config_data.GetVolGrid_FILE)
#             self.data['Template'][1]['TemplateApplications'][0]['GetGrid']['DataBlocks'][0]['config']['EntityType']['Value'] = self.entity_type
#             self.data['Template'][1]['TemplateApplications'][0]['GetGrid']['DataBlocks'][0]['config']['URL']['Value'] = self.url
#             self.data['Template'][1]['TemplateApplications'][0]['GetGrid']['DataBlocks'][0]['config']['BaseDir']['Value'] = '/' + self.setupDir
#             self.BottleLog.logger.debug('Updating URL - %s and Basedir - %s'%(self.url, self.setupDir))
#             self.pattern = self.data['Template'][1]['TemplateApplications'][0]['GetGrid']['DataBlocks'][0]['config']['GridList']['Value'][1]['Pattern']
#             self.vgridList = self.data['Template'][1]['TemplateApplications'][0]['GetGrid']['DataBlocks'][0]['config']['GridList']['Value']
#             for i in range(len(self.VGridNameList)):
#                 self.vgridList[0].append(copy.deepcopy(self.vgridList[1]['Pattern']))
#                 self.vgridList[0][i]['GridSpec']['Required']['Value'] = True
#                 self.vgridList[0][i]['GridSpec']['Name']['Value'] = self.VGridNameList[i]
#             fp = open(os.path.join(self.dst ,os.path.split(self.config_data.GetVolGrid_FILE)[-1]), 'w+')
#             res = json.dump(self.data, fp)
#             fp.close()
#             self.BottleLog.logger.info('Completed updating file - %s'%(os.path.split(self.config_data.GetVolGrid_FILE)[-1]))
#             return True
# ##            if self.SSHConn.write_file_ssh(os.path.join(self.dst ,os.path.split(self.config_data.GetVolGrid_FILE)[-1]), self.data):
# ##                self.BottleLog.logger.info('Completed updating file - %s'%(os.path.split(self.config_data.GetVolGrid_FILE)[-1]))
# ##                return True
# ##            else:
# ##                self.BottleLog.logger.error('Failed to update details in file - %s'%(os.path.split(self.config_data.GetVolGrid_FILE)[-1]))
# ##                return False
#         except:
#            self.BottleLog.logger.error('Failed to Update details. Got error - %s'%(traceback.format_exc().splitlines()[-1]))
#            self.error_update = traceback.format_exc().splitlines()[-1]
#            return False

    def getvolgrid_availability(self):
        try:
            self.retrieve_obj.retrieve_caller(["AppJson"])
            app_json = self.retrieve_obj.req_out_json['AppJson']['json']
#             """get the filled json object and query the runtask.py for availability"""
#             if self.fill_details():
#                 inputJson=os.path.join(self.dst, os.path.split(self.config_data.GetVolGrid_FILE)[-1])
#                 #command=[self.config_data.script, inputJson, self.fPath]
#                 #self.BottleLog.logger.debug("executing command - %s"%(command))
            if self.script_execution(app_json, self.setupDir)!=False:
                    #getVolGrid = self.SSHConn.read_file_ssh(os.path.join(self.fPath, os.path.split(self.config_data.GetVolGrid_FILE)[-1]))  
                Vgrid = app_json['Template'][1]['TemplateApplications'][0]['GetGrid']['DataBlocks'][0]['config']['GridList']['Value']
                j = 0
                for i in range(len(Vgrid[0])):
                    if Vgrid[0][i]['GridSpec']['Required']['Value'] == True and Vgrid[0][i]['GridSpec']['Available']['Value'] == False:
                            self.NAvailable_list.append(Vgrid[0][i]['GridSpec']['Name']['Value'])
                            j = j+1
                if j > 0:
                    self.BottleLog.logger.error('Few of the selected grids are not available - %s'%(self.NAvailable_list))
                    return {"error": "Following selected Grids are not avialable", "response" : self.NAvailable_list}
                else:
                    self.BottleLog.logger.info('All the selected Grids are avialable')
                    return {"success": "All the selected Grids are avialable"}
            else:
                self.BottleLog.logger.error('SSH script execution error')
                return {"error": "SSH script execution error"}
#             else:
#                 self.BottleLog.logger.error('Failed to update the grid details')
#                 return {"error": "Failed to update the grid details"}
        except:
            self.BottleLog.logger.error('Failed to get the grid availability. Got error - %s'%(traceback.format_exc().splitlines()[-3:]))
            return {"error": traceback.format_exc().splitlines()[-1]}
        
    def script_execution(self, InputJson, RunDir, DISPLAY=None):
        try:
            self.BottleLog.logger.info('script execution initiated in Launcher')
            caller = EcfdCaller(self.username, InputJson, RunDir, self.hpcserver, DISPLAY)
            self.BottleLog.logger.debug("result from caller is : %s" %(caller.result))
            if caller.result=="TRUE":
                self.BottleLog.logger.info('RunTask launched successfully')
                return caller.output
            else:
                self.BottleLog.logger.error('Error in EcfdCaller and return code is %s:' %(caller.code))
                return False         
        except:
            self.BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
            return False  

    

if __name__ == '__main__':
    getvol = Getgrid(40, "Volume", "abcdef", ['qgw','qwfe','qswg'])
    getvol.GetVolgridAvailability()
    #getvol.restoreFileContent()
    #getvol.getVolumeGrid()
    #getvol.check_volGrid()

        
