#!/boeing/sw/ecfd/bin/python2.7

"""Authenticate a remote SSH connection usign a private/public RSA key authentication and execute the script on 
the remote machine and return the results of the script execution."""

__author__ = "Sreevatsa Beleyur Devappa"
__copyright__ = ""
__credits__ = ["Sreevatsa Beleyur Devappa , Venkata Harish Nagamangalam,Ritesh Kumar Srivastava, Neeharika Pittu"]
__license__ = ""
__version__ = "1.0"
__maintainer__ = "Sreevatsa Beleyur Devappa"
__email__ = "sreevatsa.b@hcl.com"
__status__ = "Code Generator"
__lastupdatedon__= "16/10/2014" #dd/mm/yyyy

#import os
#os.environ['PYTHON_EGG_CACHE'] = '/boeing/sw/ecfd/alpha/python/python-eggs'

from JsonHelper import jsonify
import json
import traceback
import subprocess
from subprocess import Popen, PIPE, STDOUT
from DatabaseWrapper import eCFDdb
import sys
import traceback
from BottleAppLogger import BottleAppLogger
from EcfdConfig import EcfdConfig
from tempfile import SpooledTemporaryFile as tempfile
        

class EcfdCaller:
    """Contains all the necessary methods to perform the EcfdCaller class.It authenticates a remote SSH connection using a
    private/public RSA key authentication and executes the script on the remote machine and returns the results of the 
    script execution.""" 
    def __init__(self,username, bemsid, inputJsonPath, RunDir, hpcserver,transaction_id=None,DISPLAY=None,pbs_jobid=None):
        """Initializer for the EcfdCaller class.It internally calls classes like BottleAppLogger,EcfdConfig.
        Args:
            username:ecfd username
            bemsid:BEMSid of the user
            inputJsonPath:Input json that has to sent to remote machine.
            RunDir:Directory name for the execution of scripts 
            hpcserver:Name of the HPCserver
            DISPLAY:Dispaly variable
        Example:
            EcfdCaller("ox967d","2695717",json,"/home/ox967d/ecfdtest","pluto.ca.boeing.com","0")
        """
        self.BottleLog = BottleAppLogger('EcfdCaller')
        self.BottleLog.logger.info('EcfdCaller initialisation started')
        self.config_data = EcfdConfig()
        self.transaction_id=transaction_id
        #self.cmd = self.config_data.cmd
        self.userexecute_script = self.config_data.userexecute_script
        self.ecfd_user = username
        #self.apache_user = 'bottle'
        self.result = None
        self.code = None
        self.output  = None
        self.error = None
        HPCServer = hpcserver
        self.BottleLog.logger.info('EcfdCaller initialisation mid')
        self.bemsid = bemsid
        self.template_type = inputJsonPath["Template"][0]
        self.ssh_string = self.ecfd_user+'@'+HPCServer
        #self.file = inputJsonPath
        #self.f = open(self.file,"r")
        self.input_json = inputJsonPath
        self.f = tempfile()
        self.f.write(json.dumps(self.input_json))
        self.f.seek(0)

        self.RunDir = str(RunDir)
        self.DISPLAY= DISPLAY
        self.pbs_jobid=pbs_jobid
        self.BottleLog.logger.info('EcfdCaller initialisation completed')
        self.call_user_execute()
        
                                
    def call_user_execute(self):
        """Executes the input scripts on the remote machine and returns the respective output scripts.
        Returns:
            Returns the return code and result as TRUE in case of success or FALSE in case of failure.
        """ 
        try:
            #TODO: Uncomment Below code for Blues Implementation
            if (self.config_data.BluesInfo_Required).lower() == "yes":
                self.BottleLog.logger.debug('Bemsid in caller %s'%(self.bemsid))
                p = subprocess.Popen(['/boeing/sw/ecfd/bin/blues', '-b', self.bemsid], shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                out, err = p.communicate()
                code = p.returncode
                if code == 0:
                    bluesinfo = dict([tuple([x.strip()
                                             for x in line.split(":",1)])
                                      for line in out.split("\n") if ":" in line])
                    preferred_uid = bluesinfo["Preferred UID"]
                else:
                    self.BottleLog.logger.error('Error in Blues script and return code is %s:' %(code))
                    self.result = False
                    return
                ecfd_user = str(preferred_uid)
                self.BottleLog.logger.debug("id from blues -- %s"%(ecfd_user))
            else:
                self.BottleLog.logger.debug('making the ssh connection with the user %s'%(self.ecfd_user))
                ecfd_user = self.ecfd_user 
            #remove below line once blues script is implemented
            #ecfd_user = self.ecfd_user 
            
            if self.config_data.point_to_mock == "No":
                if self.template_type == 'oversim_setup' :
                    command = ["sudo", "-u", ecfd_user, self.userexecute_script, self.ssh_string]
                else:
                    if self.pbs_jobid != None:
                        #making it str(self.DISPLAY) in order to handle none type in case if the display variable is not set,"none" value is handled in userexecute.py
                        command = ["sudo", "-u", ecfd_user,self.userexecute_script, self.ssh_string, self.RunDir, str(self.DISPLAY),self.pbs_jobid]
                    else:
                        #making it str(self.DISPLAY) in order to handle none type in case if the display variable is not set,"none" value is handled in userexecute.py
                        command = ["sudo", "-u", ecfd_user, self.userexecute_script, self.ssh_string, self.RunDir, str(self.DISPLAY)]
            else:            
                command = ["python","Run1.py"]
#             proc = lambda:Popen(command,  stdin = self.f, stdout=PIPE, stderr=STDOUT)
#             self.job = Jobmanager(proc, self.hpcname)
#             out,err,return_code = self.job.create_pool()
#             if out == 0:
#                 self.result = "FALSE"
#                 self.BottleLog.logger.error("System is busy in processing other requests. Please re-launch it again") 
            self.BottleLog.logger.debug('%s:command from EcfdCaller is : %s'%(self.transaction_id,command))
            self.BottleLog.logger.debug('%s:EcfdCaller input : %s'%(self.transaction_id,self.input_json))
            proc = Popen(command,  stdin = self.f, stdout=PIPE, stderr=STDOUT)
            out,err = proc.communicate()
            return_code = proc.returncode
            self.BottleLog.logger.debug('%s:Output from UserExecute stdin is : %s'%(self.transaction_id,out))
            self.BottleLog.logger.debug('%s:Error from UserExecute stderr is : %s'%(self.transaction_id,err))
            self.BottleLog.logger.debug('%s:return code from UserExecute is : %s'%(self.transaction_id,return_code))
            self.code = return_code
            self.error = err
            if return_code == 0:
                self.output = out
                self.BottleLog.logger.info("%s:SUCCESSFUL completion of SSH call through EcfdCaller"%(self.transaction_id))
                self.result = "TRUE"
            else:
                self.BottleLog.logger.error("%s:ERROR encountered in SSH call through EcfdCaller"%(self.transaction_id))
                self.result = "FALSE"
        except:
            self.result = "FALSE"
            self.BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        return
    
    
    
if __name__=='__main__':
    username = 'jeb9140'
    #jsonPath = '/boeing/sw/ecfd/Test/sds_0040/GridConnectivity/cgt.json'
    jsonPath = '/home/tstern/GetVolGrid.json'
    RunDir = '/boeing/sw/ecfd/Test/alpha/jeb'        
    DISPLAY = "DISPLAY"    
    #res = EcfdCaller(username, jsonPath, RunDir, DISPLAY)
    res = EcfdCaller(username, jsonPath, RunDir)
    # res = EcfdCaller(username, 'authentication.json', '/boeing/sw/ecfd/alpha/bin')
