#!/boeing/sw/ecfd/bin/python2.7
"""Poller is mainly used to query the status of PBSID and to update the respective JobStatus in transaction when any asynchronous
 step is launched.
 """
__author__ = "Sreevatsa Beleyur Devappa"
__copyright__ = ""
__credits__ = ["Sreevatsa Beleyur Devappa , Venkata Harish Nagamangalam,Ritesh Kumar Srivastava, Neeharika Pittu"]
__license__ = ""
__version__ = "1.0"
__maintainer__ = "Sreevatsa Beleyur Devappa"
__email__ = "sreevatsa.b@hcl.com"
__status__ = "Code Generator"
__lastupdatedon__= "08/11/2014" #dd/mm/yyyy

from EcfdConfig import EcfdConfig
import sys
config_data = EcfdConfig()
template_script_path = config_data.templatescript_path
sys.path.append(template_script_path)
from template import Template
from BottleAppLogger import BottleAppLogger
from Retriever import Retriever
from EcfdCaller import EcfdCaller
from DatabaseWrapper import eCFDdb
from PostProcessor import PostProcessor
import json
import traceback
import urllib2, urllib
from datetime import datetime
import re

class Poller:
    """Contains all the necessary methods to perform the Poller class.Queries the status of PBSID and to updates the 
    respective JobStatus in transaction when any asynchronous step is launched.""" 
    def __init__(self, sched_id, transaction_id, stepname, pbsid, sync_async,process_type,caseId):
        """Initializer for the Retriever class.It internally calls classes like BottleAppLogger,EcfdConfig,eCFDdb,Retriever.
        Parameters like hpc server,user name,bemsid,runDir will be retrieved from the transaction collection of database.
        
        Args:
             sched_id:Object id of the document for which polling is to be done.
             transaction_id:Object id of the document for which the polling is to be done,
             action:Respective name of the step for which the polling is to be done,
             pbsid:pbsid value for which polling is to be done
             sync_async:whether the step is synchronous or asynchronous and has result or not.
             
        Example:
             Poller("5566b2d6299f73190c7a457b", "5565621936246c15bf5bb343", "GridConnectivity", "7336", "async_with_result").
               
        """
        self.BottleLog = BottleAppLogger('Poller')
        self.sched_id = sched_id
        self.transaction_id = transaction_id
        self.stepname = stepname
        self.process_type=process_type
        self.caseId=caseId
        self.pbsid = pbsid
        self.sync_async = sync_async
        self.config_data = EcfdConfig()
        self.db = eCFDdb()
        self.db.connect(self.config_data.DatabaseName)
        
        #for script execution
        self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, "Basic")
        if self.db.db_error == None :
            for each in self.db.db_output:
                if each["Name"] == "HPCHost":
                    self.hpcserver = each["Value"][0]
                elif each["Name"] == "HPCUserId":
                    self.username = each["Value"][0]
                elif each["Name"] == "RunDir" :
                    self.runDir = each["Value"][0]
        self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, "MetaData", "CurrentOwner")
        if self.db.db_error == None :
            self.bemsid = self.db.db_output
        #self.runDir = None
        
        
        ##for script execution testing purpose only
        #self.username = self.config_data.username
        #self.hpcserver = self.config_data.HPCServer
        #self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, "Basic", "Phase", 1, "SubStep", 0)
        #self.runDir = self.db.db_output["Param"][0]["Value"]
        
        self.config_data = EcfdConfig()
        self.db = eCFDdb()
        self.db.connect(self.config_data.DatabaseName)
        self.pbsid_status = None
        self.pbsid_qtime = None
        self.pbsid_pbsout = None
        self.pbsid_limit = None
        self.pbsid_stime = None
        self.pbsid_curtime = None
        self.pbsid_poll = None
        self.ExitCode=None
        self.RunStatus=None
        self.error = None
        self.pbsid_oldvalue=None
        self.retrieve_obj = Retriever(self.transaction_id, self.stepname,self.process_type,caseId=self.caseId)
        self.get_run_dir()
        req_json = ['Status', 'QueryJSON']
        self.retrieve_obj.retrieve_caller(req_json)
    
    def get_run_dir(self):
        try:
            self.retrieve_obj.get_publish_data("EntityType")
            if self.retrieve_obj.retriever_error == None:
                entity_type = self.retrieve_obj.req_out_json['EntityType']
                if entity_type.lower() == "solution":
                    self.retrieve_obj.retrieve_caller(["Runs"], None)
                    if self.retrieve_obj.retriever_error == None:
                        output = self.retrieve_obj.req_out_json["Runs"]
                        for each in output:
                            if each["Pbsid"] == self.pbsid:
                                self.runDir = each["RunDir"] 
                                break
                    else:
                        self.error = self.retrieve_obj.retriever_error
        except:
            self.BottleLog.logger.error("%s:Failed in get_run_dir in Poller.%s"\
                                         %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
            self.error =  traceback.format_exc().splitlines()[-1]
        return            
                
    def script_execution(self, InputJson, RunDir, DISPLAY=None):
        """ Initializes the class EcfdCaller with the received inputs like user name,bemsid,hpc server,display 
        variable,inputJson.
        
        Args:
          InputJson(json):Query json (i.e template type is pbsid)
          RunDir:Directory for the execution of scripts.
          DISPLAY:Dispaly variable
          
        Returns:        
          Returns output as boolean value TRUE in case of success or error code and error message in case of failure.
        """
        try:
            self.BottleLog.logger.info('%s:script execution initiated in Poller'%(self.transaction_id))
            caller = EcfdCaller(self.username, self.bemsid, InputJson, RunDir, self.hpcserver,self.transaction_id,DISPLAY)
            self.BottleLog.logger.debug("%s:result from caller is : %s" %(self.transaction_id,caller.result))
            if caller.result=="TRUE":
                self.BottleLog.logger.info('%s:RunTask launched successfully'%(self.transaction_id))
                return caller.output
            else:
                self.error=caller.error
                self.BottleLog.logger.error('%s:Error in EcfdCaller and return code is %s:' %(self.transaction_id,caller.code))
                return False         
        except:
            self.BottleLog.logger.error("%s:Failed in script execution in Poller.%s"\
                                         %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
            self.error =  traceback.format_exc().splitlines()[-1]
            return False
    '''  
    def get_process_id(self):
        """Returns the case id/process id from the transaction collection using transaction_id.
        Returns:
          case id/process id
        """
        try:
            self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, 'Process','id')
            if self.db.db_error==None:
                process_id = self.db.db_output
                self.BottleLog.logger.info("%s:Process id is %s"%(self.transaction_id,process_id))
                return process_id 
            else:
                self.error = self.db.db_error
                self.BottleLog.logger.error("%s:Failed to get process id.Got error %s"%(self.transaction_id,self.db.db_error))
                return False
        except:
            self.BottleLog.logger.error("%s:Failed to get process id.Got error %s"\
                                              %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
            self.error =  traceback.format_exc().splitlines()[-1]
            return False        
     '''           
            
            
    def get_details(self):
        """Stores the pbsid value in QueryJSON by retrieving the QueryJSON from publish collection and returns the modified 
        serialized AppJson.
        
        Returns:
           Modified Serialized AppJson
        """
        try:
            self.retrieve_obj.retrieve_caller(["QueryJson"],self.pbsid)
            if self.retrieve_obj.retriever_error == None:
                query_json = self.retrieve_obj.req_out_json['QueryJson']
                return query_json["json"]
            else:
                self.BottleLog.logger.error("%s: Failed to get queryjson from transaction" %(self.transaction_id))
                self.error = "Could not get QueryJson from transaction"     
        except:
            self.BottleLog.logger.error("%s: Failed to get details.Got error %s"\
                                           %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
            self.error =  traceback.format_exc().splitlines()[-1]
        return       
    
    def update_status_to_transaction(self):
        """Updates the pbsid_status i.e polling status in JobStatus field of Runs block in transaction collection for the 
        respective transaction id and step name.
        
        Returns:
            Returns the respective output or error variables.
          
        """
        try:
            self.BottleLog.logger.info("%s:Updating  status(JobStatus) to transaction."%(self.transaction_id))
            self.retrieve_obj.retrieve_caller(['Runs'])
            update_data = self.retrieve_obj.req_out_json['Runs']
            for i in range(len(update_data)):
                if self.pbsid_oldvalue:
                    if update_data[i]["Pbsid"] == self.pbsid_oldvalue:
                        update_data[i]["JobStatus"] = "Submitted to HPC" 
                        update_data[i]["Pbsid"] = self.pbsid
                else:
                    if update_data[i]["Pbsid"] == self.pbsid:
                        update_data[i]["JobStatus"] = self.pbsid_status                         
            data = {}
            data['stepname'] = self.stepname
            data['_id'] = self.transaction_id
            data['status_details'] = update_data
            data['block'] = 'Runs'
            self.db.update_partdata_onid(self.config_data.eCFD_Transaction_Collection , data,self.process_type,caseId=self.caseId)
        except:
            self.error =  traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s: Failed to update status to transaction .Got error %s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
        return       
        
    '''    
    def get_sched_data(self):
        try:
            query = {'transaction_id': self.transaction_id, 'stepname': self.stepname, 'pbsid':{'$in': [self.pbsid] ,'$options':'i'}}
            #query = {'transaction_id': self.transaction_id, 'stepname': self.stepname}
            projection = {'Process.PublishId':1,'Process.Name':1 }
            self.db.query_data(self.config_data.eCFD_Sched_Collection, query, 'single')
            if self.db.db_error==None:
                return json.loads(self.db.db_output)
            else:
                self.retriever_error = self.db.db_error    
        except:
             self.error =  traceback.format_exc().splitlines()[-1]
             self.BottleLog.logger.error(traceback.format_exc().splitlines()[-3:])
        return            
    '''
   
    def update_sched_data(self):
        """Updates fields like poll,last_poll_time,first_poll in sched collection of database using sched_id.
        
        Returns:
            Returns the respective output or error variables.
        """
        try:
            #TOD: update the poll time and the curtime to sched
            data = {}
            data['_id'] = self.sched_id
            data['updatedata'] = {'poll' : self.pbsid_poll, 'last_poll_time' : self.pbsid_curtime,
                                  'first_poll':'No',"pbsid.0":self.pbsid}
            if self.pbsid_oldvalue != None:
                data['updatedata']["first_poll"] = "Yes"
            self.db.update_partdata("sched" , data)
            if self.db.db_error == None:
                self.BottleLog.logger.info("%s:Successfully updated sched collection"%(self.transaction_id))
            else:                
                self.error =  self.db.db_error
                self.BottleLog.logger.error("%s:Failed to update sched data %s"%(self.transaction_id,self.error))
        except:
            self.error =  traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s:Failed to update sched data.%s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
        return     
     
    def call_bpm(self):
        """Sends parameters like process id,pbsid,step name,transaction id and error to BPM.Returns the output as TRUE in case of 
        success from BPM.
        
        Returns:
            Returns the respective output or error variables.
        """
        call_status = None
        try:
            process_id = self.caseId
            self.BottleLog.logger.info("%s:bpmpath %s" %(self.transaction_id,self.config_data.BPM_PATH)) 
            self.BottleLog.logger.info("%s:process_id - %s for BPM update" %(self.transaction_id,process_id)) 
            if process_id!=False:                               
                params = { "processid" : process_id, "_id": self.transaction_id ,"pbsid" : self.pbsid, "stepname":self.stepname,"process_type":self.process_type,"error":str(self.error)}                
                self.BottleLog.logger.info("%s:params %s"%(self.transaction_id,params))
                json_data = json.dumps(params)
                post_data = json_data.encode('utf-8')
                req = urllib2.Request(self.config_data.BPM_PATH, post_data, self.config_data.headers)
                try:
                    response = json.loads(urllib2.urlopen(req).read())
                    self.BottleLog.logger.info("%s:logging bpm response %s"%(self.transaction_id,response))
                    if response["jobStatusResponse"].lower() == "success":
                        self.BottleLog.logger.info("%s:Update Status to BPM successfully"%(self.transaction_id))
                        call_status = "success"
                    else:
                        call_status = "failure"
                        self.BottleLog.logger.error("%s:Error updating Status to BPM"%(self.transaction_id))    
                        self.error = "Error updating Status to BPM"
                except urllib2.URLError, err:
                    self.BottleLog.logger.error("%s:Failed to call bpm.Error is %s"%(self.transaction_id,err))
                    call_status = "unabletoreach"
            else:
                self.BottleLog.logger.info("%s:could not retrieve process id"%(self.transaction_id))    
                self.error = "could not get process id in call_bpm"
        except:
            self.error =  traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s: Failed to call bpm.%s"\
                                         %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
        return call_status    
    
    def extract_data_from_output(self, script_output):
        """Extracts the values of status,qtime,pbsout,limit,stime,curtime and poll from the hpc ouput and returns them.
        
        Args:
            script_output(json):output from hpc side after polling(i.e Query Json)
              
        Returns:
            Returns the respective output or error variables.        
        """
        try:
            tpl=Template("pbsid")
            tpl.json_restore(json.loads(script_output))
            self.BottleLog.logger.info("%s:Script output after pbsid polling is %s"%(self.transaction_id,json.loads(script_output)))
            self.pbsid_status = tpl.get_value("pbsid", "pbsid_in", "status")
            self.pbsid_qtime = tpl.get_value("pbsid", "pbsid_in", "qtime")
            self.pbsid_pbsout = tpl.get_value("pbsid", "pbsid_in", "pbsout")
            self.pbsid_limit = tpl.get_value("pbsid", "pbsid_in", "limit")
            self.pbsid_stime = tpl.get_value("pbsid", "pbsid_in", "stime")
            self.pbsid_curtime = tpl.get_value("pbsid", "pbsid_in", "curtime")
            self.pbsid_poll = tpl.get_value("pbsid", "pbsid_in", "poll")
            self.ExitCode=tpl.get_value("pbsid", "Application", "ExitCode")            
            self.RunStatus=tpl.get_value("pbsid", "Application", "RunStatus")
            pbsid_value = tpl.get_value("pbsid", "pbsid_in", "pbsid")
            if self.pbsid_status == "Completed":                
                if pbsid_value != self.pbsid:
                    self.pbsid_oldvalue = self.pbsid
                    self.pbsid = pbsid_value  
                    desc="New linked job %s is detected.Polling for the old job %s is completed."%(self.pbsid,self.pbsid_oldvalue)
                    self.db.update_error_details(self.transaction_id, self.stepname, self.process_type, "System",desc, caseId=self.caseId)
                    tpl.set_value("pbsid","pbsid_in","pbsid",self.pbsid) 
            data=json.loads(script_output)             
            self.update_pbs_out_to_trans(data)
        except:    
            self.error =  traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s:Failed to extract data from output.%s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
        return         
    
    def update_pbs_out_to_trans(self, data):
        try:
            self.retrieve_obj.retrieve_caller(["Runs"])
            update_data = self.retrieve_obj.req_out_json['Runs']
            mongo_id = None
            for i in range(len(update_data)):
                if self.pbsid_oldvalue:
                    if update_data[i]["Pbsid"] == self.pbsid_oldvalue:
                        mongo_id = update_data[i]["QueryJson"]["MongoRefId"]
                        break
                else:
                    if update_data[i]["Pbsid"] == self.pbsid:
                        mongo_id = update_data[i]["QueryJson"]["MongoRefId"]
                        break
            if mongo_id !=None:
                if "_id" in data.keys():
                    del data["_id"]
                query = {}
                query["_id"] = mongo_id
                self.db.update_data(self.config_data.eCFD_Transaction_Collection, query, data)
                if self.db.db_error==None:
                    self.BottleLog.logger.debug("%s:Completed storing QueryJson to Database"%(self.transaction_id))
                else:    
                    self.error = self.db.db_error
                    self.BottleLog.logger.debug("%s:Error in storing QueryJson to Database"%(self.transaction_id)) 
            else:
                self.error = "Could not get Mongo ID for query Json"  
        except:
            self.error =  traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s:Failed to update_pbs_out_to_trans.%s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))       
        return          
         
    def check_timelines(self):
        """ Verifies whether the polling time is in between pbsid_limit time.If it exceeds the limit,updates the JobStatus as 
        timeout in transaction collection and removes the respective document from sched collection.  
              
        Returns:
            Returns the respective output or error variables.    
        """
        try:
            if self.pbsid_curtime == None or self.pbsid_qtime == "None" or self.pbsid_qtime==None:
                return
            else:
                time_format = "%Y-%m-%d %H:%M:%S.%f"
                #The following line is for testing purpose
                #self.pbsid_qtime = "2014-11-20 18:05:21.946000"
                millisec_found_pbsid_qtime = re.search(r'\.',self.pbsid_qtime)
                if not millisec_found_pbsid_qtime:
                    self.pbsid_qtime = self.pbsid_qtime+'.'+'000000'
                millisec_found_pbsid_curtime = re.search(r'\.',self.pbsid_curtime)
                if not millisec_found_pbsid_curtime:
                    self.pbsid_curtime = self.pbsid_curtime+'.'+'000000'
                diff_time = datetime.strptime(self.pbsid_curtime, time_format) - datetime.strptime(self.pbsid_qtime, time_format)
                diff_hours, diff_rest = divmod(diff_time.total_seconds(),3600)
                #diff_time = self.pbsid_curtime - self.pbsid_qtime
                if int(diff_hours) >= int(self.pbsid_limit):
                    #TODO : Update the status to transaction and remove it from sched collection
                    self.pbsid_status = "Timeout"
                    self.update_status_to_transaction()
                    #sched_output = self.get_sched_data()
                    #self.db.remove_collection(self.config_data.eCFD_Sched_Collection, sched_output['_id'])
                    self.db.remove_collection(self.config_data.eCFD_Sched_Collection, self.sched_id)
                else:
                    self.BottleLog.logger.info('%s:Dint reach the Timeout!! Continuing the probe'%(self.transaction_id))      
        except:    
            self.error =  traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s:Failed to check timelines.%s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
        return
    
    def remove_sched(self,polling_msg):
        
        try:
            self.db.get(self.config_data.eCFD_Sched_Collection,self.sched_id) 
            if self.db.db_error == None:
                if self.db.db_output != "" and self.db.db_output != None and self.db.db_output != "null":
                    sched_data = json.loads(self.db.db_output)                    
                    sched_data["polling_status"] = polling_msg
                    mongoid = sched_data["_id"]
                    del sched_data["_id"]
                    self.db.store_data(self.config_data.eCFD_SchedTemp_Collection,sched_data)                        
                    self.db.remove_collection(self.config_data.eCFD_Sched_Collection, mongoid)
                else:
                    self.BottleLog.logger.error("%s:Failed to get sched data from sched collection.%s"%(self.transaction_id,self.db.db_error))
            else:
                self.BottleLog.logger.error("%s:Failed to get sched data from sched collection.%s"%(self.transaction_id,self.db.db_error))
            
        except:
            self.error =  traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s:Failed to update error count.%s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
        return   
    
    def errorhandling_func(self,polling_msg,err_desc):
        """In case of failure,updates the error message in the console part and moves the document from sche dto temporary 
        sched collection."""  
        try:       
            call_success=self.call_bpm()
            if call_success == "success":
                self.remove_sched(polling_msg)                                                      
                self.db.update_error_details(self.transaction_id, self.stepname, self.process_type, "System", err_desc, caseId=self.caseId)
            else:
                self.BottleLog.logger.error('%s:Error in BPM update call'%(self.transaction_id))  
        except:
            self.BottleLog.logger.error('%s:Error in errorhandling_func'%(self.transaction_id))  
    def poll(self):
        """Retrieves the query json for the respective step using retriever and updates pbsid value into QueryJson and calls 
        hcp scripts to check the status of pbsid.Once it gets the status from hpc,the same status is updated as JobStatus in
        transaction collection.Once the status is updated as completed,If the step is with result it calls postprocessor.
        
        It calls BPM service to update the status of that particular step and removes that particular sched document from 
        collection in case of success response from BPM.
              
        Returns:
            Returns the respective output or error variables.        

        """
        try:
            query_json = self.get_details()
            self.BottleLog.logger.info("%s:input Query Json is %s"%(self.transaction_id,query_json))
            if self.error==None:
                script_output = self.script_execution(query_json, self.runDir)   
                if script_output!=False:
                    self.extract_data_from_output(script_output)                    
                    if self.error==None:
                        if self.ExitCode == 0 :
                            self.check_timelines()
                            if self.error==None:
                                self.update_status_to_transaction()
                                if self.error==None:
                                    self.update_sched_data()
                                    if self.error==None:
                                        if self.pbsid_status =='Completed' and  self.pbsid_oldvalue == None:                                            
                                            #sched_output = self.get_sched_data()
                                            #if sched_output['sync_async']=='aync_with_result':
                                            if self.sync_async == 'async_with_result':
                                                post_pro_obj = PostProcessor(self.transaction_id, self.stepname, \
                                                                             self.username, self.hpcserver, self.runDir, self.pbsid,self.process_type,self.caseId )
                                                post_pro_obj.postprocessor_caller()                                            
                                                if post_pro_obj.postprocessor_error==None:
                                                    self.BottleLog.logger.info('%s:Polling completed and result extracted for transaction and pbsid %s'%(self.transaction_id, self.pbsid))
                                                else:                                                
                                                    self.error = post_pro_obj.postprocessor_error    
                                                    self.BottleLog.logger.error('%s:Polling error in PostProcessor for transaction and pbsid %s'%(self.transaction_id, self.pbsid))
                                                    
                                            
                                            call_status = self.call_bpm()
                                            if call_status == "success":    
                                                #self.db.remove_collection(self.config_data.eCFD_Sched_Collection, sched_output['_id'])
                                                self.db.remove_collection(self.config_data.eCFD_Sched_Collection, self.sched_id)
                                                self.BottleLog.logger.info('%s:Polling completed for transaction and pbsid %s'%(self.transaction_id, self.pbsid))
                                            elif call_status == "unabletoreach" :                                                
                                                self.BottleLog.logger.error('%s:failed to make connection with bpm.Unable to reach BPM.'%(self.transaction_id))
                                            elif call_status == "failure" :
                                                self.db.remove_collection(self.config_data.eCFD_Sched_Collection, self.sched_id)
                                                err_desc = "Failed in the process of updating the job status to BPM.\
                                                 Polling of the job is completed .Hence job is removed from sched collection."
                                                self.db.update_error_details(self.transaction_id, self.stepname, self.process_type, "System", err_desc, caseId=self.caseId)
                                            else:
                                                self.BottleLog.logger.error('%s:failed to make connection with bpm.Some exceptions occured in\
                                                                            python side while updating the status to BPM'%(self.transaction_id))
                                                polling_msg = "Exceptions occurred while updating status to BPM.Failed to call BPM.  \
                                                     So removed from sched collection and copied the same to temporary sched collection."
                                                self.remove_sched(polling_msg) 
                                    else:                    
                                        self.BottleLog.logger.error('%s:Error in updating to Sched'%(self.transaction_id)) 
                                        polling_msg = "Exceptions occurred while polling for job status.failed to update status to sched.  \
                                                     So removed from sched collection and copied the same to temporary sched collection."
                                        err_desc = "Failed in the process of polling the job  due to some internal error."
                                        self.errorhandling_func(polling_msg, err_desc)
                                else:
                                    self.BottleLog.logger.error('%s:Error in updating to transaction'%(self.transaction_id))
                                    polling_msg = "Exceptions occurred while polling for job status,failed to update status to transaction. \
                                                 So removed from sched collection and copied the same to temporary sched collection."
                                    err_desc = "Failed in the process of polling the job  due to some internal error."  
                                    self.errorhandling_func(polling_msg, err_desc)  

                            else:   
                                self.BottleLog.logger.error('%s:Error in Checking timeline'%(self.transaction_id))
                                polling_msg = "Exceptions occurred while polling for job status,while checking timelines. \
                                             So removed from sched collection and copied the same to temporary sched collection."
                                err_desc = "Failed in the process of polling the job due to some internal error."
                                self.errorhandling_func(polling_msg, err_desc)      
 
                        else:
                            self.error="Error in Script Execution.Error is %s"%(self.RunStatus)
                            self.BottleLog.logger.error('%s:Error in Script Execution.Error is %s'%(self.transaction_id,self.RunStatus))
                            polling_msg = "Received error message from hpc while polling for job status,received exit code other than 0 \
                                 So removed from sched collection and copied the same to temporary sched collection."
                            err_desc = "Failed in the process of polling the job ,received an error message from hpc server." 
                            self.errorhandling_func(polling_msg, err_desc)      

                    else:
                        self.BottleLog.logger.error('%s:Error in extracting the output.Error is %s'%(self.transaction_id,self.error))
                        polling_msg = "Exceptions occurred while polling for job status ,in the process of extracting the data from output. \
                                     So removed from sched collection and copied the same to temporary sched collection."
                        err_desc = "Failed in the process of polling the job  due to some internal error."
                        self.errorhandling_func(polling_msg, err_desc) 
                   
                else:
                    self.error="Error in Script Execution.Received error message from hpc."
                    self.BottleLog.logger.error('%s:Error in Script Execution.'%(self.transaction_id))   
                    polling_msg = "Received error message from hpc while polling for job status,failed in hpc. \
                             So removed from sched collection and copied the same to temporary sched collection."  
                    err_desc = "Failed in the process of polling the job ,received an error message from hpc server."  
                    self.errorhandling_func(polling_msg, err_desc)                                                    

            else:
                self.BottleLog.logger.error('%s:Error in retrieving the query json.Error is %s'%(self.transaction_id,self.error))
                polling_msg = "Exceptions occurred while polling for job status to get query json. \
                         So removed from sched collection and copied the same to temporary sched collection."
                err_desc = "Failed in the process of polling the job due to some internal error."
                self.errorhandling_func(polling_msg, err_desc)   
              
        except:
            self.error =  traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s: Failed to poll.%s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
        return            
                    
        
if __name__=='__main__':
    obj = Poller("56b3251b299f73258c043154", "569cd69edc16ed2d29dccf98", "GridConnectivity", "9513", "async_with_result","ExecuteProcess",1169)
    obj.poll()  
    print obj.pbsid_status      
        
        
        
              
