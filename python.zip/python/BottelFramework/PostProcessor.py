#!/boeing/sw/ecfd/bin/python2.7
"""PostProcessor is mainly used to update ResultJson in the transaction collection when the JobStatus is completed. """
__author__ = "Sreevatsa Beleyur Devappa"
__copyright__ = ""
__credits__ =["Sreevatsa Beleyur Devappa , Venkata Harish Nagamangalam,Ritesh Kumar Srivastava, Neeharika Pittu"]
__license__ = ""
__version__ = "1.0"
__maintainer__ = "Sreevatsa Beleyur Devappa"
__email__ = "sreevatsa.b@hcl.com"
__status__ = "Code Generator"
__lastupdatedon__= "16/10/2014" #dd/mm/yyyy


from EcfdConfig import EcfdConfig
import sys
config_data = EcfdConfig()
template_script_path = config_data.templatescript_path
sys.path.append(template_script_path)
from template import Template
from BottleAppLogger import BottleAppLogger
from EcfdCaller import EcfdCaller
from Retriever import Retriever
from DatabaseWrapper import eCFDdb
import json
from JsonHelper import jsonify
import traceback
from DataMapper import DataMapper

class PostProcessor:
    """Contains all the necessary functions to perform the PostProcessor class.It updates ResultJson in the transaction 
    collection when the JobStatus is completed.""" 
    
    def __init__(self, transaction_id, stepname, username, hpcserver, runDir, pbsid,process_type,caseId):
        """Initializer for the Retriever class.It internally calls classes like BottleAppLogger,EcfdConfig,eCFDdb,Retriever.
        Bemsid will be retrieved from the transaction collection.
        
        Args:
            transaction_id:Object id of the document on which post processor action has to be performed,
            step name:Respective name of the step on which post processor action has to be performed,
            user name:username of the person who is launching the respective step,
            hpc server:server name by which scripts are going to be executed,
            runDir:Directory where the scripts has to be executed,
            pbsid:pbsid value on which post processor action has to be performed
        
        Example:
        PostProcessor("5565621936246c15bf5bb343","OverflowSolution","ox967d","pluto.ca.boeing.com","/home/ox967d/ecfdtest","2344")
        
        """
        self.BottleLog = BottleAppLogger('PostProcessor')
        self.config_data = EcfdConfig()
        self.transaction_id = transaction_id
        self.stepname = stepname
        self.username = username
        self.hpcserver = hpcserver
        self.pbsid = pbsid
        self.runDir = runDir
        self.code = None
        self.error = None
        self.status = None
        self.db = eCFDdb()
        self.db.connect(self.config_data.DatabaseName)
        self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection, self.transaction_id, "MetaData", "CurrentOwner")
        self.bemsid = self.db.db_output
        self.postprocessor_error = None
        self.postprocessor_output = None
        self.process_type=process_type
        self.caseId=caseId
        self.retrieve_obj = Retriever(self.transaction_id, self.stepname,self.process_type,caseId=self.caseId)
        
    def script_execution(self, InputJson, RunDir, DISPLAY=None):
        """ Initializes the class EcfdCaller with the received inputs like user name,bemsid,hpc server,display variable,inputJson.
        Returns output as boolean value TRUE in case of success or error code and error message in case of failure.
        Args:
            InputJson:Result json for the script execution.
            RunDir:Directory for the execution of scripts.
            DISPLAY:Dispaly variable
        Returns:
            Returns output as boolean value TRUE in case of success or error code and error message in case of failure.
        """
        try:
            self.BottleLog.logger.info('%s:script execution initiated in PostProcessor'%(self.transaction_id))
            caller = EcfdCaller(self.username, self.bemsid, InputJson, RunDir, self.hpcserver,self.transaction_id, DISPLAY)
            self.BottleLog.logger.debug("%s:result from caller is : %s" %(self.transaction_id,caller.result))
            if caller.result=="TRUE":
                self.BottleLog.logger.info('%s:RunTask launched successfully'%(self.transaction_id))
                return caller.output
            else:
                self.code = caller.code
                self.error = caller.error
                self.db.update_error_details(self.transaction_id, self.stepname,self.process_type, "System","Failed in hpc while processing the resultjson",self.code,caseId=self.caseId)
                self.BottleLog.logger.error('%s:Error in EcfdCaller and return code is %s:' %(self.transaction_id,caller.code))
                return False         
        except:
            self.BottleLog.logger.error("%s:Failed in script execution in postprocessor.%s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
            return False
    
    def data_map_before_script_call(self):
        try:
            self.BottleLog.logger.info("%s:Started datamapping for getting Result"%(self.transaction_id))  
            datamapper_obj = DataMapper(self.transaction_id, self.stepname,"ResultJson",process_type=self.process_type,caseId=self.caseId,pbsid=self.pbsid)
            datamapper_obj.perform_data_map()
            if datamapper_obj.map_notfound == None :
                if datamapper_obj.error != None:
                    self.code="PYT257"
                    self.BottleLog.logger.info("%s:Error in performing datamap on ResultJSON before calling HPC"%(self.transaction_id))
                    self.error = "Error in performing datamap on ResultJSON before calling HPC"
                    self.db.update_error_details(self.transaction_id, self.stepname,self.process_type, "System",self.error,"Failure",caseId=self.caseId)
                else:
                    self.BottleLog.logger.info("%s:datamapping completed for getting Result"%(self.transaction_id))  
            else:
                self.BottleLog.logger.info("%s:No datamap available for resultjson"%(self.transaction_id))  
        except:
            self.error = traceback.format_exc().splitlines()[-1]
            self.BottleLog.logger.error("%s:Failed in script execution in postprocessor.%s"\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
        return        
              
    def postprocessor_caller(self):
        """Retrieves the ResultJson,updates the step name in it and sends it to hpc for script execution.In case of success 
        from hpc side it retrieves the  value of RunStatus and ExitCode from output and updates in Result block of Runs in 
        transaction collection.Also updates the hpc output as result json in transaction collection.Otherwise it returns the
        respective error message.
        Returns:
            Returns the respective output or error messages.
        """
        try:
            self.BottleLog.logger.info("%s:Started post processor"%(self.transaction_id))
            self.db.get(self.config_data.eCFD_Transaction_Collection, self.transaction_id)
            if self.db.db_error==None:
                self.retrieve_obj.extract_step_block_on_name()
                if self.retrieve_obj.retriever_error==None:
                    #self.result_json = self.retrieve_obj.extract_json_block_of_step(self.retrieve_obj.retriever_output, 'Runs', self.pbsid)
                    #template_name = self.result_json['json']['Template'][0]
                    #tpl=Template(template_name)
                    #tpl.json_restore(self.result_json['json'])
                    #tpl.set_value(template_name, "Cycle", "ProcessStep", self.stepname)
                    #result_json_ser = tpl.json_serialize()
                    #self.BottleLog.logger.debug("%s:Result json after setting step name %s"%(self.transaction_id,result_json_ser))
                    self.data_map_before_script_call()
                    if self.error == None:
                        self.result_json = self.retrieve_obj.extract_json_block_of_step(self.retrieve_obj.retriever_output, 'Runs', self.pbsid)
                        template_name = self.result_json['json']['Template'][0]
                        #script_output = self.script_execution(result_json_ser, self.runDir)
                        script_output = self.script_execution(self.result_json['json'], self.runDir)
                        if script_output!=False:
                            tpl=Template(template_name)
                            tpl.json_restore(json.loads(script_output))
                            RunStatus = tpl.get_value(template_name, "Application", "RunStatus")
                            try:
                                self.retrieve_obj.get_publish_data("EntityType")
                                if self.retrieve_obj.retriever_error == None:   
                                    entity_type = self.retrieve_obj.req_out_json['EntityType']
                                    if entity_type.lower() == "solution":
                                        self.db.get_content_of_case(self.config_data.eCFD_Transaction_Collection,self.transaction_id,self.process_type)
                                        if self.db.db_error == None or self.db.db_error == "None" or self.db.db_error== "null" or self.db.db_error == "" :
                                            block = self.db.db_output                                    
                                            step_block = block["Steps"]
                                            for i in range(len(step_block)):                                        
                                                if step_block[i]['Name']==self.stepname:
                                                    inside_block = step_block[i]["Param"]["Runs"]                                            
                                                    for j in range(len(inside_block)):
                                                        if inside_block[j]['Pbsid']==self.pbsid:                                                    
                                                            Job_detail_value = inside_block[j]['JobDetail']           
                                                            result_details = ""
                                                            for key,value in Job_detail_value.iteritems():
                                                                if key.lower() != "conditionmatrixid":
                                                                    result_details = result_details + str(key) + " : " + str(value)+","
                                                            result_details = "For ConditionMatrix : " + "(" +result_details[:-1] + ") ," +"     Message :" + RunStatus                                 
                                                            #result_details = jsonify(Job_detail_value) + ":" + RunStatus
                                                            break
                                        else:
                                            self.BottleLog.logger.error("%s:query to retrieve job details  failed.Error is %s"%(self.transaction_id,self.db.db_error))                            
                                            result_details = RunStatus
                                            self.db.db_error = None
                                    else:
                                        self.BottleLog.logger.info("%s:As the Current Step is not solution so updating the result details as Runs Status "%(self.transaction_id))                          
                                        result_details = RunStatus 
                                        
                                else:
                                    self.BottleLog.logger.error("%s:query to retrieve job details  failed.Error is %s"%(self.transaction_id,self.retriever_obj.retriever_error))                            
                                    result_details = RunStatus 
                                    self.retriever_obj.retriever_error = None                                                                    
                            except:
                                self.BottleLog.logger.error("%s:query to retrieve job details  failed.Error is %s "%(self.transaction_id,traceback.format_exc().splitlines()[-3:]))                            
                                result_details = RunStatus 
                                self.db.db_error = None    
                            
                            ExitCode= tpl.get_value(template_name, "Application", "ExitCode")
                            self.db.update_error_details(self.transaction_id, self.stepname ,self.process_type, "Result", result_details,ExitCode,caseId=self.caseId)
                            if self.db.db_error==None:
                                self.BottleLog.logger.info("%s:Result Run Status Updated Successfully"%(self.transaction_id))
                            else:
                                self.BottleLog.logger.error("%s:Result Run Status Updation failed"%(self.transaction_id))
                                self.postprocessor_error = self.db.db_error                                                
                            if ExitCode == 0:                         
                                self.retrieve_obj.retrieve_caller(["Runs"])
                                update_data = self.retrieve_obj.req_out_json['Runs']
                                for i in range(len(update_data)):
                                    if update_data[i]["Pbsid"] == self.pbsid:
                                        mongo_id = update_data[i]["ResultJson"]["MongoRefId"]
                                        break
                                        #update_data[i]["ResultJson"]["json"] = json.loads(script_output)
                                data = json.loads(script_output)
                                if "_id" in data.keys():
                                    del data['_id']
                                query = {}
                                query["_id"] = mongo_id
                                self.db.update_data(self.config_data.eCFD_Transaction_Collection, query, data) 
        #                         data = {}
        #                         data["_id"] = self.transaction_id
        #                         data["stepname"] = self.stepname
        #                         data["block"] = 'Runs'
        #                         data['status_details'] = update_data
        #                         self.db.update_partdata_onid(self.config_data.eCFD_Transaction_Collection, data)
                                if self.db.db_error==None:
                                    self.postprocessor_output = jsonify({"Success":"Result json Updated successfully"})
                                    self.BottleLog.logger.info("%s:Result json Updated successfully"%(self.transaction_id)) 
                                else:
                                    self.postprocessor_error = self.db.db_error
                                    self.BottleLog.logger.error("%s:Error in updating result json"%(self.transaction_id)) 
                            else:
                                self.postprocessor_error = jsonify({"error":"Error in Script Execution in postprocessor.Error is %s"%(RunStatus)})
                                self.BottleLog.logger.error("%s:Error in Script Execution in postprocessor.Error is %s"%(self.transaction_id,RunStatus))  
                            
                        else:
                            self.postprocessor_error = jsonify({"error":"Error in Script Execution in postprocessor.Error is %s "%(self.error)})
                            self.BottleLog.logger.error("%s:Error in Script Execution in postprocessor.Error is %s"%(self.transaction_id,self.error))
                    else:
                        self.postprocessor_error = self.error
                        self.BottleLog.logger.error("%s:Error in data map of resultjson.Error is %s"%(self.transaction_id,self.error))                                
                            
                else:
                    self.postprocessor_error = self.retrieve_obj.retriever_error
                    self.BottleLog.logger.error("%s:Error in retrieving the steps block.Error is %s "\
                                                %(self.transaction_id,self.postprocessor_error))
            else:
                self.postprocessor_error = self.db.db_error
                self.BottleLog.logger.error("%s:Error in retrieving the respective transaction json.Error is %s "\
                                                %(self.transaction_id,self.postprocessor_error))
        except:
            self.BottleLog.logger.error('%s:Failed to get_result_json. Got error %s'\
                                        %(self.transaction_id,traceback.format_exc().splitlines()[-3:]))
            self.postprocessor_error = traceback.format_exc().splitlines()[-1]
        return 
    
if __name__ == "__main__":
    ppc = PostProcessor()
    ppc.postprocessor_caller()
            
                
                
        
        
        
        
        
        
        
        
        
        
        
